<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-08ffbd00.fda460a6.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-1886be60="" class="servicepage">
        <div data-v-1886be60="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='{{route('profile')}}'"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Service</div>
            </div>
        </div>
        <div data-v-1886be60="" class="helloi"><img data-v-1886be60="" src="{{asset('public')}}/NorthernStar/dist/img/2.7b0b190d.png" alt=""
                                                    class="imgi">
            <div data-v-1886be60="" class="canbean"><p data-v-1886be60="">Hello～All your questions </p>
                <p data-v-1886be60="">can be answered here</p></div>
        </div>
        <section data-v-1886be60="" class="section-box">
            <div data-v-1886be60="" class="onlinei">
                <div data-v-1886be60="" class="servicen"><img data-v-1886be60=""
                                                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAthJREFUSEu1lk1oE1EQx/+zNRpLreIH6FGsNCQq2ff0ol4UFcWPgwcVi+LFg6BYLfYkQj0Iitqr9Sh6aEGwhwoi2EIVxHTfbnOIFCK02JNSxPQj1pIdeSFbYrJJWrPOZZfdN//fzsybeUsoWCQS2dDY2HgNwHEiigEYtizrKAD21gRxJS0ipdwI4COAbcWizHxBKfU8CJCn4QF7AZwpFWbmiUwm05pOp+eDgpJpmrsNw/gEIA8vNdd1O2zbfhwYUEr5FMDlSoLM/IOZW23b/h4ElKSU6dLa+aS2Tyl1NhCgEGKeiFbWEGPXdbfatj1RL1RHmAGwpobQoGVZhwHk6gYKIT4Q0d4qQv0LCwttyWRytl6Y9tcRdgG44yfGzPeUUreDbH4N3Akg6bNRepVS54KIqljDa3wN1OBie2tZ1pH/AhRC3CCisubO5XInHMcZCBKajzAWi60Ph8OTAFaXiH+ZmpraMT4+/iso6OI4E0LcJ6JOn1p2K6VuBg6Mx+PrGhoaPgPYXCzOrHvePe04Tn8Q0L8Gtmmap4joFRGVDvJp13UP2rY9Ui+07IQQQnQTUbuP8FQulzvmOE6iGjQajTaFQqHto6Ojtt+6MqCUMsTMr4nokE89Z5j5km3bL/3EpJRbAAwCaAUwYBjGlUQi8bWsD0udpZRrAQwBiPtAmYieZLPZzlQqNeO9b2lpWdXc3DxMRHu8Z8w8y8yP5ubmHo6NjU3nR1ul9JimuYmIhogoWmHNJDN3KKX6ABhCiGdE1FZhRH4DcFcp1VMRqB011DCMN/q2St3038JvAPtrbShmfl8VqAUK6dVRBDHmsjWBha9eIYR4AKDdp2VqBbb4nplHlgrMOwkhThJRDwC9G5dtzNy1LKCXYma+BeA6ETUtlcrMKdd19y0b6AEKtb0I4JIOvgqYmfkFEV21LOvnPwOLAVLKCIDzAA4A2MXMYSLSp88713V7ikfiH+4ZGi8Zy3rmAAAAAElFTkSuQmCC"
                                                              alt="">
                    <p data-v-1886be60="">Online service</p></div>
                <p data-v-1886be60="" class="hourice">24-hour service</p><img data-v-1886be60=""
                                                                              src="{{asset('public')}}/NorthernStar/dist/img/1.9f09af36.png"
                                                                              alt="" class="imgice"><i
                    data-v-1886be60="" class="arroit van-icon van-icon-arrow"></i></div>
            <div data-v-1886be60="" class="whatapps">
                <div data-v-1886be60="" class="topwha flex"><p data-v-1886be60="">Telegram</p><i data-v-1886be60=""
                                                                                                 class="van-icon van-icon-arrow">
                        </i></div>
                <div data-v-1886be60="" class="contact"><img data-v-1886be60=""
                                                             src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAABzNJREFUaEPdW3ls01Uc/7weY93Rtd1Yd7ubMTECg8gVxIk6TgNBEDEiGkRGIAKLInggEQ3GI0LWbVkQvAiHQmRAIJIYCCAOPJiToB072djZdRc72vWZ99tB23Vtf7+2bOn79/e9Pn3vfa/3LYG7V951qcqomGoidBoBHiVAIgWiCKCigC9TR4AuCugIcIcCJRS4IaLkqk6iv4Z1UwzuNIm4RVjedanCpFgoMtHnAWSAQC5ILkUrgLMmETmsF+lPuQOsSwCVebeD0GvaQEA2AjRMEKhhmUgtBd0HsSi7eV1Ci1DZwgAeKPNVdRrfpMBmAiiEKneGjwJ6Anyhk0k+wZq4Lmd4zGl4A1Rq/lsAkL0EiOerzBV6CpQCdFNzZvJpPnKcB7izzFcZavycAK/3+YkRWZQS5DTXSbZip3O76ZShqnxtFDWggAATRwSWlVIK/EWkWKRbm3THkT0OAQbs1ab6SHAWQLQjYQ/4e1WPERntm5Ju2tNrFyADJ5XQiwQk+AEb75Q6CtpkMJLZ9kAOC1CVXRINQi+Pwp2zBl8FKWYMd1xtA+xzKL+OljvnaDvZnWyul0y35XhsAlRqtBoCrHckeDR9p0BOc2ZSprVNQwCyOEdACkYwFAj93SgFXWQdJy0BHijzVXYa/3nQQVwoIms+lgw0yyQPm2c8FgBVGu17AD5wl8IRkvO+LjNp14DuQYD9iXO5p3NLT4NmuSvEotiBBP0+QI12OwF2e9oAPvKZcWH+Ytzt6OXDBgrsaM5M+ogx9QFkRWqvotL9JQ8vuwaJIwMkWDkuEC+kyPGQXIq8Ij22X27kIYzU6sT6GFZPcgAVOSVLRJQe5yHB7aQ+IoJ5cf5YlSLHnGgZxOS+eyhu7Mbjx6p46TQRslS/PvEEJ0WVrT0CguW8JLiJOFXlg1Xj5XguORDBvmKbUk+VtmP1uVp+GimO6jYkrSDc8TQGNQpuM/BTy1HLfURYmhiAF8fLMSmUa9PYXbuuNuLLP/WOyCy/U7TqJC0hRJVdMqM/5+QngCc1OyozI2RYlRKIRQkBkElEFhIoBX663Y4QmRizImUW3549WY1L1Z08NQKgZCZRaLRbRMBn/Lmd4wj3F2PlODnnMOKCpDaZKloNyLrYgDFigvyn1BbgeylF/P5StBuocwrNqEzAVqLUaL8mwEu8ue0wSEVARmyfw0iP9oNYZDunN5gocm7o8cl1HZYlBeLT2WMhsaK9pevBzCOVgsyjwDdEpdGykmiGIAlWTCnMYaQEYnmynDtq9tbvdV3YcqEexU09yEpTYtvUYJg5zkHWQ7dasfGXeqHmXWE7WEGAGKESAqUiLOl3GJPVvg6bNW09JuwubML+4r5O4J5ZIXhlwvCNua0X6nHwJmuX8l8UqGQ72AYggC/79HBfzgsujg+AHzuTTqzTpe3YdqkBNR293H3LfVKNxQn2VT9xrApFjd1OSLdJ0s520EgA++epn5fhWPuIAi+nypGg8HFaaU27EW9dasCZsg6Oh4WJbzPCMCvSz66MTqMJsftLYTQ5rcqCkAK9vAC+PVWFrCkqp7UxD/hVcQs+/K1p0Auq/cQ4uiACE0LGOJRTWNuJeSeqHdINR0ABI68jGhMoQVaaikupVMNkHQPKWHq1+UI9/qi/f7wSgqT4YWEEYuS2w4W1oczDvnOFTw46BCp3RHk7GTEBpoX7Yn5sAAeWJcQD657BxLl9ZpzRLHRNCh2Dw/MjHHpXcxPX/lyL4yXtruwg52RcDhMTgn0wP84f8UE++LiwCRVtRguj0qNlOPhMOPyddEYDzGnfV6C81aXXNC5MuD3Qm6NjSfS+OaGQsm3nsZo6e5F8sIwHx1BSLtB7MlVbnSrnshORrQjuwPTzFR1YceauSwC5VM2TyfaRBeGYG+MvyMg913TcXXZpsWTbk+XSuaVRmKJ2XA7ZArHidA3OV94Tjm+gXGISPFXwFq6MsUgIWHItHSbxNkdCKeXun65LYIRnwgYLXg+2LLRr4gbjZWmLAcsKqrn07o3JSrv3srzFgLRDFcJ3D4BFy8ITTSfmM+vWJXCl0r+6HiwpqEbdvb7u2OxIGXLnqqH2k9gE8aO2Da+dr3MBoFXTiUlSurltGOQjQumr8fi7sRvLCmrQ2GXZ+hsrE0OTrkZ6zNB8dMflBuQWCZ47sNE2ZAD7Jibc1vgN8xPj3WnBXLuvpdv2XWK7vHGiAtsfC7a4mxnH7+BaHe95A27Hh238cs5mhFr3zNPmz1VzOerdDiMmflcuuIIAYLt1z8EfwccXPwnB07H+KGroBnNIQpbDx5e+u+jNz2f9P5tXP4ByGL39CZtzOPnaKBhwxTuHEPqPqlePkQx4Ma8eBBoAyWZmKKEnR8tYCTfKRcli3YZEh29qzpfZo2UYD8htrpdsceswnnnQ9d5xSnOU3jwQa7GbXjvSbJ0oeutQus2E2P7fCrinWwJ0Pqi/FfwPmmXlDuspWvMAAAAASUVORK5CYII="
                                                             alt="">
                    <p data-v-1886be60="">Please contact us</p></div>
            </div>
            <div data-v-1886be60="" class="whatapps">
                <div data-v-1886be60="" class="topwha flex"><p data-v-1886be60="">Northern Star group</p><i
                        data-v-1886be60="" class="van-icon van-icon-arrow"></i></div>
                <div data-v-1886be60="" class="contact"><img data-v-1886be60=""
                                                             src="{{asset('public')}}/NorthernStar/dist/img/logo.3b8d8b63.png" alt=""
                                                             class="imgui">
                    <p data-v-1886be60="">Interact with friends in the group </p></div>
            </div>
            <div data-v-1886be60="" class="whatapps">
                <div data-v-1886be60="" class="topwha flex"><p data-v-1886be60="">Northern Star channel</p><i
                        data-v-1886be60="" class="van-icon van-icon-arrow"></i></div>
                <div data-v-1886be60="" class="contact"><img data-v-1886be60=""
                                                             src="{{asset('public')}}/NorthernStar/dist/img/logo.3b8d8b63.png" alt=""
                                                             class="imgui">
                    <p data-v-1886be60="">Don’t miss the latest news, click to join now</p></div>
            </div></section>
    </div>
</div>
</body>
</html>
