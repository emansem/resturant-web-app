<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-3cade526.7c0d8bb4.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-25561eec.1bdf73df.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-57221a82.4c1adb14.css">
</head>

<body class="">
    <div id="app">
        <div id="nava"></div>
        <div data-v-7501b02e="" class="productpage">
            <div data-v-7501b02e="" class="navboxi van-nav-bar van-hairline--bottom">
                <div class="van-nav-bar__content">
                    <div class="van-nav-bar__title van-ellipsis">Investasi anda</div>
                </div>
            </div>
            <section data-v-7501b02e="" class="section-box">
                @foreach(\App\Models\Purchase::with('package')->where('status', 'active')->where('user_id',
                auth()->id())->orderByDesc('id')->get() as $element)
                <div data-v-7501b02e="" class="listpro">
                    <div data-v-7501b02e="" class="topcent">
                        <div data-v-7501b02e="" class="topi">
                            <p data-v-7501b02e="" class="namei">{{$element->package->name}}</p>
                            <div data-v-7501b02e="" class="pricei flex">
                                <p data-v-7501b02e="">Price：<span
                                        data-v-7501b02e="">$ {{number_format($element->package->price)}}</span>
                                </p><img data-v-7501b02e="" src="{{asset('public')}}/vip.PNG" alt="" class="imgti">
                            </div>
                            <img data-v-7501b02e="" src="{{asset($element->package->photo)}}" alt="" class="imgpro">
                        </div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Daily income:</div>
                        <div>$ {{number_format($element->package->commission_with_avg_amount / $element->package->validity)}}
                        </div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Purchase Validity:</div>
                        <div>{{$element->package->validity}} day</div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Commission</div>
                        <div>{{price($element->package->commission_with_avg_amount)}}</div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Started</div>
                        <div>{{$element->created_at}}</div>
                    </div>
                    
                    
                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>End</div>
                        <div>{{$element->validity}}</div>
                    </div>
                    
                </div>
                @endforeach
            </section>
            @include('app.layout.manu')
        </div>
    </div>

</body>

</html>