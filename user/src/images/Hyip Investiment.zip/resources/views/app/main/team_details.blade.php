<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-34e68869.14dd12fd.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-34788738="" class="rulepage">
        <div data-v-34788738="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='{{route('team')}}'"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">My {{$level}}-level team</div>
            </div>
        </div>
        <div data-v-34788738="" class="tabs-box van-tabs van-tabs--line">

            @if($users->count() > 0)

                @foreach($users as $user)
                <div data-v-d0c1a326="" role="feed" class="van-list">
                    <div data-v-d0c1a326="" class="listbox">
                        <div data-v-d0c1a326="" class="right">
                            <div data-v-d0c1a326="" class="typeti flex"><p data-v-d0c1a326="">{{$user->ref_id}}</p><span
                                    data-v-d0c1a326="">{{'Status'}}</span></div>
                            <div data-v-d0c1a326="" class="timetype flex">
                                <p data-v-d0c1a326="">{{$user->created_at}}</p>
                                <p data-v-d0c1a326=""><strong style="text-transform: capitalize;">{{$user->investor == 1 ? 'Active' : 'In-Active'}}</strong></p>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                @endforeach
            @else
            <div class="van-tabs__content">
                <div data-v-34788738="" role="tabpanel" class="van-tab__pane" style="">
                    <div data-v-34788738="" class="listrecore">
                        <div data-v-34788738="" role="feed" class="van-list">
                            <div data-v-35a7c3a5="" data-v-34788738="" class="empty-wrap" style="margin-top: 10px;"><img
                                    data-v-35a7c3a5=""
                                    src="{{asset('public')}}/NorthernStar/dist/img/empty.923d3703.png" alt=""
                                    class="empty">
                                <p data-v-35a7c3a5="" class="text">Nothing found!</p></div>
                            <div class="van-list__finished-text"></div>
                            <div class="van-list__placeholder"></div>
                        </div>
                    </div>
                </div>
                <div data-v-34788738="" role="tabpanel" class="van-tab__pane" style="display: none;"></div>
            </div>
           @endif
        </div>
    </div>
</div>
</body>
</html>
