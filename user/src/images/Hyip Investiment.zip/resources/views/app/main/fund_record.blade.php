<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-677042b6.61f781d3.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-12e45e87="" class="financepage">
        <div data-v-12e45e87="" class="titleance"><p data-v-12e45e87="" class="namece">My Financial</p><span
                onclick="window.location.href='{{route('fund')}}'"
                data-v-12e45e87="" class="cordui">Fund</span></div>
        <section data-v-12e45e87="" class="section-box">

            <?php
            $myFundIds = \App\Models\FundInvest::where('user_id', auth()->id())->where('status', 'active')->pluck('fund_id');
            ?>
            @foreach(\App\Models\Fund::whereIn('id', $myFundIds)->get() as $element)
                <?php
                $package = \App\Models\Package::where('id', $element->package_id)->first();
                $myFund = \App\Models\FundInvest::where('user_id', auth()->id())->where('fund_id', $element->id)->where('status', 'active')->first();
                ?>
                @if($package)
                <div data-v-12e45e87="" class="listy">
                    <div data-v-12e45e87="" class="topu flex"><span data-v-12e45e87="">{{$element->name}}</span>
                        @if($myFund)
                            <p data-v-12e45e87="" style="background: #000 !important;">INVESTED/{{price($element->minimum_invest)}}</p>
                        @else
                            <p data-v-12e45e87="" onclick="buyFund('{{$element->id}}')">BUY/{{price($element->minimum_invest)}}</p>
                        @endif
                    </div>
                    <div data-v-12e45e87="" class="ratebox"><img data-v-12e45e87=""
                                                                 src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA8CAYAAAAt3km7AAAAAXNSR0IArs4c6QAAB5xJREFUaEPdmXtwVPUVxz9nd0M2L8QYwVSKFYoDGmttp4U+gBF1rHVwSjHZJJTXxNjCMFrbmk5RRgYq2pfY1tgKU5SqIQFKW6XF4lCZDDHQUMBQzAQKxJQkpFAgYkIgu/e0+0h2s5vL3U02dWd/f957fr9zvuec7znnd6+QREvzsWOjCtgtSYQLLWIJBuVkj61IGmBaRA4GjTgzR1KwckPyAHOxDniQO0rc3PSlVxIemM4jgw5s8joXzGij+XweG7VcN8Hga084sJHYEdMiJmHwJkinVOktAwFTsOFiD8JnyV9lkDPOAfLbhI2YupiKsg3hGh8gG3mykcPh4LSAUoS15N15mRkLR/hl5dWEBKaF3IfBJhwp6dwyXanfKdgdy6XC/cNQYJpPNjYaSc0Yxfw1DpwZva8Tryqqi0Uoa3FmOJj1PRg9HtaWghr7pML9uX7AXLwALGZmqZu8mQ7Q3teVCRUxLeT7GDxNVrYwexlkj/Ub+sZP4fg+xUaubKTd+0gLuR2ljjHjFddTDiQEilCVMMB0Lrfi5l2yr4fZjwtZOcHgHH4b3voVONOXyoaucgXBxW6EqRQ+7WHMhJR+3BPZnDjAetMqfyWMvbl/jejqgLUPgt3+przmvleLWIDBy+TNvMTdS1IHqJa/Swhgej9ZOGkh5+NZLHguxM4Q8yqXwamjPdg9N9DDAVLTsin5tQNnVohQH8d+nxjAXCwByrmrVPn0VyVYA0Iw1m2F6lfA5mjAcE/mrm/2cNtX+qdgr7jIH4YNmC7E6dUjL9NtNWiri3pSnLey+CVITQ8pboGd6oEtK+BkA3h64OqP9VBSnoLY/AJ9gQrI23h9+IAVUoeS+b/JYapspsN0HCpkGko1t90D9ywdWKyxBvZshmf2Q+M78OxseLgSxO6Xj0SxbViAqQtvv/lbwMptVHG/RPrV7+xCKlCKWPRLGH1jYEuYWe+9DQe2+4Gd2A8rpsOjW8DuCHNEX+j+PFzA/I0zdyK0HfUqXylVPBkeDp3NaEbQzPWTU5n3M/OMdV+G18qg8xxcvABfLoYpD1wpw7fHHZiPW120kTN2FIuehw3fhtNNBvB1qeKPodZoAT9AWM2sxyDvzitT0fBA2xFIv8rLsSvLCn+JP7ACihAquKMEvuCC862wfil0f+jl2bcQuvqsUn5B2sgbeLgC7P75NS5LeGs4gO3AZrvbZ2ymfzDneB1UPg4aXr6AL7pgZmmguoW/DzdvgP2+4hGQC56/M67ANJ9x2DjBJ6fYKFoddL7XnuZ34WxL/4DYU2DSNBjh6wzRLyv8yF9NgWkhD2DQJpuoiSB9AXNQWmUztWGceQJhFfkrYPKMSEN7DYqrOwfwh8iuAVVosWMlHvdywEB4hlM8Kbtwe4/QAsp8z+Ak7Yzve+4fTI+SNnIC390K3mh8dKs6ApgWOX6E4S5jzHhv8irtx7wy72CnGIO5KE9hcyiGWxDypZItPsD5zMDGLqbMgXsfCUCKkiMRDjDbZxXqQEqI9P+uqMWO5/C4HyH3JnzDaIoTdjyv7N3qba8XEdK59hMwZzm8+JCint1SxXQfsEJeQlnoG4uum2hVjgPFYphCKtT4XOC73xTby/F4FvuuDPPXgDMrqLWxWtm6WrhqNCz4OWReDZuWK4d2Cga3c4ljpNFK7sRMFm+ItLbX0SZFLWZ4VucJtRIAtQ6Pp4RxnwqA6vt2ENTZ0+3njS0wn71fD+se8rpkPVCD8hvue9Tfu3qXFRAzA60yztoTe0WL7evxeBZx42dg3rMwIi24LfS67XsasLTX4BfmK62N3un9BCI3U/YGjLzWWq1ZdYwo4yZci9gf7iGpEy25xiB3ovCNn/g5Fc3qPbh2o/KnNcK0edB8CDJGwdwfR3PC0GSs28Y+0SO16kuxiOhEobu2CpoOwLId3tstfGcSrNoTTNcojhgWEWG/6IkDVkww133i7/DqY1D6IjRUw8Ht/uvER78OijYdjAHYAGyv2Qh7t/i5NasMf//rXVblK1YPWFWbvhytF22u1wG/MYTqjLXPWuEZ7HnRVlubHBJt/of2Xa3NYmdWfs2GUashNdp94YEPD7CpHjksevI9Dd7ah95AYk0uv7x1mYvx3AbRloYrcCzanLHKvRjNiuCoVQ5G9LFG0dbGGIrHYA38v+87Itp2NPmAifxT9NSxEI5ZsdUsJYbKTatqE3XVCAjqcdH249FHrG86CZsZTctqWO4PlYpR65cm0dNNwT42VMfH6tjwBIiXfpH3Rc80R0Ys1syItTZYVfeh6hf5l+h/Tg6CY7EisZIfKpKI81tEz7ZEzzEr+xLmvbSJnmtLPmAip0TPtychMP4t2nHanGOmw2+YL8IvqVauiij7JhwbrH70jOgHZyLNiFfZNetv0QIfNGflrOiHZ4evj0VrmFX5j/ac4PB8TrTzvJX/Yj42ATZ0iHZ9MIg+ZubiWJ8Pdva01HNB9OKF5IuYSKdod2fw00Cs97l45Vy877MiXaKXLloDi7ighiGK9RtGuEOsgMWq3ybdoj2XYudY+C/XiD5m0eciIh3jrGilHy6Lui8nH8cQt6jHnXzARDyihpGMwDRuw1O8CmS8zvkvDeWk4qtLjEAAAAAASUVORK5CYII="
                                                                 alt="" class="imguit">
                        <div data-v-12e45e87="" class="raternt"><p data-v-12e45e87="">{{$element->commission}}%</p><span
                                data-v-12e45e87="">Rate of return</span>
                        </div>
                        <p data-v-12e45e87="" class="line"></p>
                        <div data-v-12e45e87="" class="termdue"><p data-v-12e45e87="">The term: <span
                                    data-v-12e45e87="">{{$element->validity}} days</span>
                            </p>
                            <p data-v-12e45e87="">Income due: <span data-v-12e45e87="">{{price(($element->minimum_invest * $element->commission / 100) + $element->minimum_invest)}}</span></p></div>
                    </div>
                    <div data-v-12e45e87="" class="limit flex">
                        <div data-v-12e45e87="" class="purments"><img data-v-12e45e87=""
                                                                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAAXNSR0IArs4c6QAAAi9JREFUSEut1UuIjXEYx/HP38ItlylsjEaKYUXZyGJmYyMrRViIFUWxkAWFMSwUpciGFWPBQiEryoaULNyWjNyihFwaxcbrfea87zhznPecEf/V2/85/+95br/nSSpORgfWYxWWYBbG4R0e4DouJj43Q6TGy4wJ2ItdmFrYP+BN8d2JmcX3EI7jSOJ7PWsUOKML17AY73PAKVxIPK1/lLEAG7CjiOQRVidelL8bARfQO5iDAexMfKlKVdxnTMNJbMZr9CRehm0YnDE+z+W9Ipf9+eXBJim6WTxY0cTWl9/Fm8dYFmkpwaVhINX+/Y+T8S0cSUyusJ8tPD+U6EtF9V/lBfuB+VXhjwEcaRnERHQFeCtO5xnpSxxq0X4tPS5Suj9vyWBsC/DlqGhe/YWJJ/8Ijm4JxtUAP49+Tb97sym7XSrKR1mtTYcCHCEOppq6Ks9fgB+iO8Chnmf/GbwowFHJjjGkomz8uW0iG0nFJawZQ/FmFwJ526LAZfGuhMdbcCaUk+hv5U07W8aBXETB2B7g6WrD4yfmJb5WKOt2qD/RW2EPTqR1EjpLSe/D4XzGLk/crXh4q5B0T4X9HDaFxzFrSnAM8JBzpUDaFCwGUMybaLVwrjaE6k/GFKwdVg+f2gAj/Bib4WmMzd5yJjcDb8R5NeiJYtCPiiSju27QxzapHvR1kozZvCeX5e661fSxYTXNKH4f4jqKYy1XU0NKYpmuw0osbVim93GjiKbplvkFsyKjCM1pNMAAAAAASUVORK5CYII="
                                                                      alt="">
                            <p data-v-12e45e87="">Purchase requirements: <span data-v-12e45e87="">{{$package ? $package->name : '--'}}</span></p></div>
                        <p data-v-12e45e87="" class="mituis">Limit: <span data-v-12e45e87="">1</span></p></div>
                </div>
                @endif
            @endforeach

        @include('app.layout.manu')
    </div>
</div>
<div class="loader" style="
    position: fixed;
    display: none;
    top: 50%;
    z-index: 99;
    width: 143px;
    border-radius: 15px;
    overflow: hidden;
    left: 50%;
    transform: translate(-50%, -50%);
">
    <img src="{{asset('public/loader.webp')}}" style="width: 100%;" alt="">
</div>
@include('alert-message')
<script>
    function buyFund(id){
        document.querySelector('.loader').style.display='block';
        window.location.href= '{{url('purchase/confirmation')}}'+"/"+id+"/"+"fund";
    }
</script>
</body>
</html>
