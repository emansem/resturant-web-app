<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5d16cdcf.a146121c.css">
    <style>
        * {
            width: 100%;
        }
    </style>
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-1806362b="" class="aboutus">
        <div data-v-1806362b="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">About us</div>
            </div>
        </div>
        <img data-v-1806362b="" src="{{asset('public')}}/NorthernStar/dist/img/2.621377ac.jpg" alt="">
        <img data-v-1806362b="" src="{{asset('public')}}/NorthernStar/dist/img/3.545c9801.jpg" alt="">
    </div>
</div>
</body>
</html>
