<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-3cade526.7c0d8bb4.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css">
    <style>
        .homepage .nav-top[data-v-d2cdda40] {
            width: 100vw;
            height: 33.666667vw;
            background-size: cover;
            padding: 3.333333vw 4vw 0;
            position: relative;
        }
        .homepage .section-box .invitei .topi[data-v-d2cdda40] {
            background: #a8a8a8;
            border-radius: 2.666667vw;
            padding: 3.333333vw 0 1.733333vw;
            text-align: left;
            position: relative;
        }
    </style>
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-d2cdda40="" class="homepage">
        <div data-v-d2cdda40="" class="nav-top">
            <div data-v-d2cdda40="" class="navboxi van-nav-bar van-hairline--bottom">
                <div class="van-nav-bar__content">

                    <div class="van-nav-bar__title van-ellipsis">Invite</div>
                    <div class="van-nav-bar__left">
                        <img onclick="window.location.href='{{route('dashboard')}}'" style="width: 30px;" src="https://img.icons8.com/parakeet/48/chevron-left.png" alt="">
                    </div>
                </div>
            </div>
            <div data-v-d2cdda40="" class="mybalance">
                <div data-v-d2cdda40="" class="leftit">
                    <div data-v-d2cdda40="" class="numberanm"><p
                            data-v-d2cdda40="">{{price(auth()->user()->balance)}}</p><img data-v-d2cdda40=""
                                                                                          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGqADAAQAAAABAAAAGgAAAABMybYKAAADYElEQVRIDb2Wv2tTURTH89JUqM1gBknNUOpiQFGEIoq4RKlZSlPakLb/gIODFsR0q9hJAoJdOrn3tzSlSyw24CCKFERRrINIhzalQxxSCzZt/Hyf74U0fS82Fb3wuPeeH9/vPe+ce94zPH8YExMTZwzD6C6VSh2YtvKELJc15lV0i+jm+vv7v1hyx8lwlCKcmppq393dTbG87mZTJV9qaGhIJhKJ5Sq5uT1AlM1mfblc7gknvc1JmYxNLJ/xpBsbGz9Bvi5PQE8Vi8Vz2HSx7WE+iS1TaaylpWUwEokUZWePfUQLCwuBQqEwi3EEgy0cU4FA4HE0Gt2yHZzmTCbTnM/n7+GXRN+MX9bv9/d2dnbmbfsykSLZ2Nh4LhIMv/l8vlg8Hn9vGx5mnpmZuUCUaTDaRBYMBm/akXltAL0um6SpqelKvSTCkY98dVBhCdPGNyNS4vf29t6i/EEerh6FxAbUrMh2dnZeQXjc6/VeUoGYEam6IEFupP6WRETCEJYwrcr1GEQTZvMZxSaJP+2WeO7TUzCuYXerr6/vpQBrDXD9vKWvkKkaw14WMTkwz7qRSI/xGjZhnLOTk5OPADomudvgdRXQ6VrIt1tEuvHazGt2G0QxjE2C5ztkQzxvIDvrZi+5jSkO5UhtxaPLqLnWoM1MU1XnsVHbucgrXya6O6zL16TSnyvy0dq3isjsXTiZN77S0Gkdi8XWIIxSTXelJ7JRIlOrOjA4VM4ShsyqO2BRp8AtIrpMyYIqiUhd2OxdlrDmlE6nQ1RgRpHIkDwMkr/7Tk7qh5Z8XUSr2nDBaiZWNryi+Pb29geWHRC8A6id1zjK2j65zMpDTdfarHoxWrQ2ZpmXraoWJH2EPE7zmk7gkyJHlynhmgWErTq7ol4UUdrC7FEXrsIvb3EKYbsCQYQohiD5WVY6LCysHqnwnTPLcnx8/AX76wA9AGTEwa9uEXkchuAhjksDAwM3lCMVQhIS5KWkGmLdqFUOwhCWMIUttUmk7opijH2zvieMYJXvobfyFYawhClsOZtEWujzywmyKNuorNdHiUw+8hWGsIQpbI19reO/fMp/83o8Tj8nnHCWE85X/5zo7qHrQtfLfPifE5tMM5fz3/5uVZJZhGFOG+Nx/YEkojRJX6n2rdz/AvNq5/pJi9qPAAAAAElFTkSuQmCC"
                                                                                          alt=""></div>
                    <p data-v-d2cdda40="" class="mybalanci">My balance</p></div>
                <p data-v-d2cdda40="" class="lineu"></p>
                <div data-v-d2cdda40="" class="leftit">
                    <div data-v-d2cdda40="" class="numberanm"><p data-v-d2cdda40="">
                            <?php
                            $dailyIncome = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'daily_income')->sum('amount');
                            $commission = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'commission')->sum('amount');
                            $reword = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'reword')->sum('amount');
                            ?>
                            {{price($dailyIncome+$commission+$reword)}}
                        </p><img data-v-d2cdda40=""
                                 src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGqADAAQAAAABAAAAGgAAAABMybYKAAADYElEQVRIDb2Wv2tTURTH89JUqM1gBknNUOpiQFGEIoq4RKlZSlPakLb/gIODFsR0q9hJAoJdOrn3tzSlSyw24CCKFERRrINIhzalQxxSCzZt/Hyf74U0fS82Fb3wuPeeH9/vPe+ce94zPH8YExMTZwzD6C6VSh2YtvKELJc15lV0i+jm+vv7v1hyx8lwlCKcmppq393dTbG87mZTJV9qaGhIJhKJ5Sq5uT1AlM1mfblc7gknvc1JmYxNLJ/xpBsbGz9Bvi5PQE8Vi8Vz2HSx7WE+iS1TaaylpWUwEokUZWePfUQLCwuBQqEwi3EEgy0cU4FA4HE0Gt2yHZzmTCbTnM/n7+GXRN+MX9bv9/d2dnbmbfsykSLZ2Nh4LhIMv/l8vlg8Hn9vGx5mnpmZuUCUaTDaRBYMBm/akXltAL0um6SpqelKvSTCkY98dVBhCdPGNyNS4vf29t6i/EEerh6FxAbUrMh2dnZeQXjc6/VeUoGYEam6IEFupP6WRETCEJYwrcr1GEQTZvMZxSaJP+2WeO7TUzCuYXerr6/vpQBrDXD9vKWvkKkaw14WMTkwz7qRSI/xGjZhnLOTk5OPADomudvgdRXQ6VrIt1tEuvHazGt2G0QxjE2C5ztkQzxvIDvrZi+5jSkO5UhtxaPLqLnWoM1MU1XnsVHbucgrXya6O6zL16TSnyvy0dq3isjsXTiZN77S0Gkdi8XWIIxSTXelJ7JRIlOrOjA4VM4ShsyqO2BRp8AtIrpMyYIqiUhd2OxdlrDmlE6nQ1RgRpHIkDwMkr/7Tk7qh5Z8XUSr2nDBaiZWNryi+Pb29geWHRC8A6id1zjK2j65zMpDTdfarHoxWrQ2ZpmXraoWJH2EPE7zmk7gkyJHlynhmgWErTq7ol4UUdrC7FEXrsIvb3EKYbsCQYQohiD5WVY6LCysHqnwnTPLcnx8/AX76wA9AGTEwa9uEXkchuAhjksDAwM3lCMVQhIS5KWkGmLdqFUOwhCWMIUttUmk7opijH2zvieMYJXvobfyFYawhClsOZtEWujzywmyKNuorNdHiUw+8hWGsIQpbI19reO/fMp/83o8Tj8nnHCWE85X/5zo7qHrQtfLfPifE5tMM5fz3/5uVZJZhGFOG+Nx/YEkojRJX6n2rdz/AvNq5/pJi9qPAAAAAElFTkSuQmCC"
                                 alt=""></div>
                    <p data-v-d2cdda40="" class="mybalanci">Total income</p></div>
            </div>
        </div>
        <section data-v-d2cdda40="" class="section-box">
            <div data-v-d2cdda40="" class="invitei">
                <div data-v-d2cdda40="" class="topi" style="text-align: center;">
                    <img src="{{asset('public/qr.png')}}" style="width: 50%;border-radius: 5px;box-shadow: 0px 1px 57px #ffffff9e;" alt="">
                </div>
                <div data-v-d2cdda40="" class="peoplebox">
                    <div data-v-d2cdda40="" class="people"><span data-v-d2cdda40=""><strong
                                data-v-d2cdda40="">{{\App\Models\User::where('ref_by', auth()->user()->ref_id)->count()}}</strong>/{{setting('total_member_register_reword')}}</span>
                        <p data-v-d2cdda40="">Invite people(lv1)</p></div>
                    <div data-v-d2cdda40="" class="people"><span
                            data-v-d2cdda40="">{{price(auth()->user()->reward)}}</span>
                        <p data-v-d2cdda40="">Cumulative rewards</p></div>
                    @if(\App\Models\User::where('ref_by', auth()->user()->ref_id)->count() >= setting('total_member_register_reword') && auth()->user()->reward_received == 'false')
                        <button data-v-d2cdda40="" class="notbnt" onclick="receivedReward(true)"
                                style="background: #ffc402;">Receive
                        </button>
                    @else
                        <button data-v-d2cdda40="" class="notbnt" onclick="receivedReward(false)">Receive</button>
                    @endif
                </div>


                <div data-v-d2cdda40="" class="codebox">
                    <div data-v-d2cdda40="" class="topcode flex">
                        <div data-v-d2cdda40="" class="invitel"><img data-v-d2cdda40=""
                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAABBCAYAAACO98lFAAAAAXNSR0IArs4c6QAACChJREFUeF7tXHt8zWUY/z4/2WZLxpZFc0vKtbJ0oZSmXCZK6NMoQ58kmVqfQqpVLq0ICbWWyqVoKqqRjOkqKpJKKrFEdmnW2NaZ4ff0ed+f5Zzt/G5n5+zCef87O8/7vs/zfZ/7e94Ryg3O2XgpoI4GUzRYbQWiwPI0te4z81GQkgnijYCSQhHRO5xloLIPvHNFAMIbzQFjDACl1glqnWEVhGTk5SdQh9tLxTQJggQgLOwjgHtaX6u2U1IGDh2KEUBoIORsWADG2Noulm3+CS9RxI33k/QBrH53mpuAHj4qSImiM1YLymAR2sDZGbsAbmtblU6bCfQLcdb6ktMiDHp6KMxHibM3sKfzT5d5fhBEnuDXBB+AwAU5wI714N1fA3/vA46VAMGhQLN2oM59QW2uAuj/RLVGWJTXNIGPHQU2vg7+9kPgxHF94dp1B906ARQQVCMAkGmzN8yBC7LByxOB3Exrgp3fDjR0Gij4HGv0PqaqNAi8fxc4NREoLrDHalgz0J1JoNAIe/N8QF0pEPinT8EfzASOy2LM/qgfBhr2DCjiAvtzvTjDMxCYwV8sA3+ySJ+VphcBgSFA5nZjdgNDQHdMAbW8xIti2VvKIxA4/RXw5nd1d6LrhoF6xMkowJ+9Cf50sTFXdeqCbnsU1L67Pe69RG0bBP4+XTMBd0OpA7r5QVDnPi7f8pdvgzNeM2aZCNQ3HnRFfy+JZn0ZWyCwoxD84nCgpKjiDoHBoCFPglpHud2dN78HTk825cxZi0yJvURgD4RNqeANCytuHdIQdNdzoIhWhmzxNx+A1843ZV0mVTc/ACh1TGm9QWALBPW18cCBXRX2pV5jQF0HWeKHt60Br5kLsHHdRu2vBw2eDJDv2532QEgaAJQ6Kgrb+nIoQ6cbnhzn/wUKPU/SSL/y4SyAVUPg6KbRoG5DLIFbGSJ7IEztA6gn3O5HUf00FXZTF3DmdnDqU6A2V4MGTtCA+CED/P4MYyCCQkAJy0EB9Sojo+lceyDMiwPyD+qHxh7DQdff5RoZREIlhD1xTP6dOkafAmLnZ+CVSbrASvohTwDNOgCOQlDjlqYCeUJgD4R1LwNbVhqrsIj3naIlDW9ZqUWEcvbvAsQvm8DvTANU90UXdR8Kih4JdekkyMjRopMnchrzbKeA4sJD4Jfvkafidogwec8CUFgk+PO3DDNKAZSoJoVpqEJTdqx3b2ZXDQT1GSvX4q/eAQ2aDGp7jVeBsKUJ8nT3bAMve8ytCstE6fJ+kDXFe9ON0b+sN6h/gvQJ6sJ4IHuPexBuGCE1gL9bC06bLaMFxYwHdennNSBsgyCB2LYavHquKxPhLaCMTQGXFIPnjQAcR/R9R9fBEJ5f9CB4xdPAnq36tMOSQBd2AX+ZCs44laMI3yP9jxcaNB6BIIFIT4bIAssG9R0HuvIWqJ+/BRgUVtRzFOjaWLCjCLz8cWD/Tv0TDQmFkrAMqFMX6pJHgMzvXWiF1lFMfKWTKo9BgKpCTX0K+G2z5vXHLwE1bAJ1/ijg0H73qh0jaoMB4KJ88JuPAjl7jU2m9xjQ1YPAWbvBKTq3hG27gW6bDKrr+eW55yAIbSh1gN94SNqzkrgO7DgCnjnYvWDnCnPR1FlUoKISNRzNO0KJe17eGatvJAAHftYnb94RFDsNFBTikZ+oFAhSoCN54IXxUOIXg/P26Z+Y6BuMXQg6J1yGTP74JfA377tnunFLUNzzoOAGMiLw+hRz4SLbQ4mbCZwVYE5bjqLSIEggsnZruQAp4JT79JkQwo2YDapXXwMibTZ4+8eu9E3aaG234Aaa1uTsBS+daKl9R12HgHqNrh4Q5K7Hj2nefsZAYyZEk3X4DK3brKrgVUkypMoR2R40bDoo6GyXNfjvfeAlE4CifOO1lbNA8Yts9y29ognOnKmvjgMO/mrMrCi4YqdKry/a8+qKKUDpv6DYqbp1AucdAIsIUZhn7EyvuxN0Q5wtbfA6CLIwWvWsKROyVB40GVAU2ahlZlMPz/kHNSAO5+qvH9kOyt0vmu7vTOB1EIStqyKj/P1bU0ZknO/nvvLUm8xZvxv7ncAQKJN0HK7Oot4HQTizkiKwaMDkuc8XXE7h2liIBMrqkEmWkd8hgpKYbnU5SecTEKRX/ydLhk78e9iUIcvNE5GgiWLrxwz9NYPOhjJxlemevjUHp9X5z580r36yl2DEGQ14GNS5tz6JiCRps2RXynCIJGvknJoDgtQIi45SVoe3J7ovk60CIFT7ZNVpBwWfmYMzE+LyRVzCmA5xCSPyhFadT5HaAECEXHpgKah+mOlWVWYO/28kssOVIin6xJy5gHqg4TNB51+sJVNWTODkqmVdKPNNXCmqRBPklsdLoS5+xLgQKuMtMBjo1FOrMo1KbWdZmnXQageRgNkcVQeC8A/FBVrEKMi2yaYJecQFWsElahIPRpWCIB1l7h/g1x8EjhZ7wK6bKeHNQSNmgUJCPV6vykGQQOzZCl72uGGr3ZJEjZpqValNR1h+7WoBQQKxNQ28xl6O78J8gwjQyNmgBo0t4WVEVG0gSCDWJYO3nOpTWpamfrgGQMMmlqfUWBBEu53TXgBvX2tdmIZNtaZLo6bW55hQVqsmSN5EDrF1tfYjDiNnKVrr4q6i170Vmi6VRaP6QTgpgfgBCMRt9W9bgNy9gKMIqBsEhEcCraJkXSFutnwxagwIvhDO6pp+EHzZT7B6CjWBzq8JUhP8L1/Eyxf/Gyj/azj5Gs7/LjLK/0JWvJCVmav/rbQWqc/4V/POCcuZ+P8T/gMdWrq1AB4F/QAAAABJRU5ErkJggg=="
                                                                     alt="" class="imgi">
                            <div data-v-d2cdda40="" class="codete"><p data-v-d2cdda40="">Invite code</p><span
                                    data-v-d2cdda40="">{{auth()->user()->ref_id}}</span></div>
                        </div>
                        <img onclick="copyLink('{{auth()->user()->ref_id}}')" data-v-d2cdda40="" src="{{asset('public')}}/NorthernStar/dist/img/copy.8f614e0d.png" alt="" class="copyimg"></div>
                    <p data-v-d2cdda40="" class="line"></p>
                    <div data-v-d2cdda40="" class="topcode flex">
                        <div data-v-d2cdda40="" class="invitel"><img data-v-d2cdda40=""
                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAABBCAYAAACO98lFAAAAAXNSR0IArs4c6QAACChJREFUeF7tXHt8zWUY/z4/2WZLxpZFc0vKtbJ0oZSmXCZK6NMoQ58kmVqfQqpVLq0ICbWWyqVoKqqRjOkqKpJKKrFEdmnW2NaZ4ff0ed+f5Zzt/G5n5+zCef87O8/7vs/zfZ/7e94Ryg3O2XgpoI4GUzRYbQWiwPI0te4z81GQkgnijYCSQhHRO5xloLIPvHNFAMIbzQFjDACl1glqnWEVhGTk5SdQh9tLxTQJggQgLOwjgHtaX6u2U1IGDh2KEUBoIORsWADG2Noulm3+CS9RxI33k/QBrH53mpuAHj4qSImiM1YLymAR2sDZGbsAbmtblU6bCfQLcdb6ktMiDHp6KMxHibM3sKfzT5d5fhBEnuDXBB+AwAU5wI714N1fA3/vA46VAMGhQLN2oM59QW2uAuj/RLVGWJTXNIGPHQU2vg7+9kPgxHF94dp1B906ARQQVCMAkGmzN8yBC7LByxOB3Exrgp3fDjR0Gij4HGv0PqaqNAi8fxc4NREoLrDHalgz0J1JoNAIe/N8QF0pEPinT8EfzASOy2LM/qgfBhr2DCjiAvtzvTjDMxCYwV8sA3+ySJ+VphcBgSFA5nZjdgNDQHdMAbW8xIti2VvKIxA4/RXw5nd1d6LrhoF6xMkowJ+9Cf50sTFXdeqCbnsU1L67Pe69RG0bBP4+XTMBd0OpA7r5QVDnPi7f8pdvgzNeM2aZCNQ3HnRFfy+JZn0ZWyCwoxD84nCgpKjiDoHBoCFPglpHud2dN78HTk825cxZi0yJvURgD4RNqeANCytuHdIQdNdzoIhWhmzxNx+A1843ZV0mVTc/ACh1TGm9QWALBPW18cCBXRX2pV5jQF0HWeKHt60Br5kLsHHdRu2vBw2eDJDv2532QEgaAJQ6Kgrb+nIoQ6cbnhzn/wUKPU/SSL/y4SyAVUPg6KbRoG5DLIFbGSJ7IEztA6gn3O5HUf00FXZTF3DmdnDqU6A2V4MGTtCA+CED/P4MYyCCQkAJy0EB9Sojo+lceyDMiwPyD+qHxh7DQdff5RoZREIlhD1xTP6dOkafAmLnZ+CVSbrASvohTwDNOgCOQlDjlqYCeUJgD4R1LwNbVhqrsIj3naIlDW9ZqUWEcvbvAsQvm8DvTANU90UXdR8Kih4JdekkyMjRopMnchrzbKeA4sJD4Jfvkafidogwec8CUFgk+PO3DDNKAZSoJoVpqEJTdqx3b2ZXDQT1GSvX4q/eAQ2aDGp7jVeBsKUJ8nT3bAMve8ytCstE6fJ+kDXFe9ON0b+sN6h/gvQJ6sJ4IHuPexBuGCE1gL9bC06bLaMFxYwHdennNSBsgyCB2LYavHquKxPhLaCMTQGXFIPnjQAcR/R9R9fBEJ5f9CB4xdPAnq36tMOSQBd2AX+ZCs44laMI3yP9jxcaNB6BIIFIT4bIAssG9R0HuvIWqJ+/BRgUVtRzFOjaWLCjCLz8cWD/Tv0TDQmFkrAMqFMX6pJHgMzvXWiF1lFMfKWTKo9BgKpCTX0K+G2z5vXHLwE1bAJ1/ijg0H73qh0jaoMB4KJ88JuPAjl7jU2m9xjQ1YPAWbvBKTq3hG27gW6bDKrr+eW55yAIbSh1gN94SNqzkrgO7DgCnjnYvWDnCnPR1FlUoKISNRzNO0KJe17eGatvJAAHftYnb94RFDsNFBTikZ+oFAhSoCN54IXxUOIXg/P26Z+Y6BuMXQg6J1yGTP74JfA377tnunFLUNzzoOAGMiLw+hRz4SLbQ4mbCZwVYE5bjqLSIEggsnZruQAp4JT79JkQwo2YDapXXwMibTZ4+8eu9E3aaG234Aaa1uTsBS+daKl9R12HgHqNrh4Q5K7Hj2nefsZAYyZEk3X4DK3brKrgVUkypMoR2R40bDoo6GyXNfjvfeAlE4CifOO1lbNA8Yts9y29ognOnKmvjgMO/mrMrCi4YqdKry/a8+qKKUDpv6DYqbp1AucdAIsIUZhn7EyvuxN0Q5wtbfA6CLIwWvWsKROyVB40GVAU2ahlZlMPz/kHNSAO5+qvH9kOyt0vmu7vTOB1EIStqyKj/P1bU0ZknO/nvvLUm8xZvxv7ncAQKJN0HK7Oot4HQTizkiKwaMDkuc8XXE7h2liIBMrqkEmWkd8hgpKYbnU5SecTEKRX/ydLhk78e9iUIcvNE5GgiWLrxwz9NYPOhjJxlemevjUHp9X5z580r36yl2DEGQ14GNS5tz6JiCRps2RXynCIJGvknJoDgtQIi45SVoe3J7ovk60CIFT7ZNVpBwWfmYMzE+LyRVzCmA5xCSPyhFadT5HaAECEXHpgKah+mOlWVWYO/28kssOVIin6xJy5gHqg4TNB51+sJVNWTODkqmVdKPNNXCmqRBPklsdLoS5+xLgQKuMtMBjo1FOrMo1KbWdZmnXQageRgNkcVQeC8A/FBVrEKMi2yaYJecQFWsElahIPRpWCIB1l7h/g1x8EjhZ7wK6bKeHNQSNmgUJCPV6vykGQQOzZCl72uGGr3ZJEjZpqValNR1h+7WoBQQKxNQ28xl6O78J8gwjQyNmgBo0t4WVEVG0gSCDWJYO3nOpTWpamfrgGQMMmlqfUWBBEu53TXgBvX2tdmIZNtaZLo6bW55hQVqsmSN5EDrF1tfYjDiNnKVrr4q6i170Vmi6VRaP6QTgpgfgBCMRt9W9bgNy9gKMIqBsEhEcCraJkXSFutnwxagwIvhDO6pp+EHzZT7B6CjWBzq8JUhP8L1/Eyxf/Gyj/azj5Gs7/LjLK/0JWvJCVmav/rbQWqc/4V/POCcuZ+P8T/gMdWrq1AB4F/QAAAABJRU5ErkJggg=="
                                                                     alt="" class="imgi">
                            <div data-v-d2cdda40="" class="codete"><p data-v-d2cdda40="">Invite link</p><span
                                    data-v-d2cdda40="" class="ellipsis-1">{{url('member/register').'?member='.auth()->user()->ref_id}}</span>
                            </div>
                        </div>
                        <img onclick="copyLink('{{url('member/register').'?member='.auth()->user()->ref_id}}')" data-v-d2cdda40="" src="{{asset('public')}}/NorthernStar/dist/img/copy.8f614e0d.png" alt="" class="copyimg"></div>
                </div>
            </div>
        </section>

    </div>
</div>

@include('alert-message')
<script>
    function copyLink(text) {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();
        message('Copied success..')
    }


    function receivedReward(condition) {
        if (condition == true) {
            window.location.href = '{{route('user.received.reward')}}';
        } else {
            message('Target not eligible.')
        }
    }
</script>
</body>
</html>
