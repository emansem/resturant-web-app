<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-947ff9a0.19b6028a.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-38e6878b="" class="bankpage">
        <div data-v-38e6878b="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='{{route('dashboard')}}'"><i
                        class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Bank Account</div>
            </div>
        </div>
        <section data-v-38e6878b="" class="section-box">
            <form action="{{route('setup.gateway.submit')}}" method="post">
                @csrf
                <p data-v-38e6878b="" class="bankaccti">Name of holder</p>
                <div data-v-38e6878b="" class="input-box van-cell van-field">
                    <div class="van-cell__value van-cell__value--alone van-field__value">
                        <div class="van-field__body"><input type="text" placeholder="Please enter the name of the holder"
                                                            name="name"
                                                            class="van-field__control"></div>
                    </div>
                </div>
                <p data-v-38e6878b="" class="bankaccti">Account type</p>
                <div data-v-38e6878b="" class="downlisti van-dropdown-menu">
                    <div class="van-dropdown-menu__bar" onclick="showPayMethod()">
                        <div role="button" tabindex="0" class="van-dropdown-menu__item"><span
                                class="van-dropdown-menu__title"><div class="van-ellipsis showMethod">Select a payment channel</div></span></div>
                    </div>
                    <div data-v-38e6878b="">
                        <div class="van-overlay oovv" onclick="hidePayMethod()" style="z-index: 2002; position: absolute; animation-duration: 0.2s;display: none;"></div>
                        <div class="van-popup oovvBox van-popup--top van-dropdown-item__content" style="transition-duration: 0.2s; z-index: 2003; display: none;">
                            @foreach(\App\Models\PaymentMethod::get() as $el)
                            <div role="button" tabindex="0" onclick="getPaymentMethod('{{$el->name}}')"
                                 class="van-cell van-cell--clickable van-dropdown-item__option van-dropdown-item__option--active">
                                <div class="van-cell__title"><span>{{$el->name}}</span></div>
                                <div class="van-cell__value"><i class="van-icon van-icon-success van-dropdown-item__icon">
                                    </i></div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <input type="hidden" name="gateway_method">

                <p data-v-38e6878b="" class="bankaccti">Account number</p>
                <div data-v-38e6878b="" class="input-box van-cell van-field">
                    <div class="van-cell__value van-cell__value--alone van-field__value">
                        <div class="van-field__body"><input type="tel" inputmode="numeric"
                                                            name="gateway_number"
                                                            placeholder="Please enter bank account"
                                                            class="van-field__control"></div>
                    </div>
                </div>

                <button data-v-38e6878b="" class="btncon">Confirm</button>
                <p data-v-38e6878b="" class="methodi">Rules</p>
                <p data-v-38e6878b="" class="textui">Please input your bank account information accurately, and your
                    earnings will be transferred to the provided bank account.</p>
            </form>
        </section>
    </div>
</div>
@include('alert-message')
<script>
    function showPayMethod(){
        let oovv = document.querySelector('.oovv');
        let oovvBox = document.querySelector('.oovvBox');
        oovv.style.display='block';
        oovvBox.style.display='block';
    }
    function hidePayMethod(){
        let oovv = document.querySelector('.oovv');
        let oovvBox = document.querySelector('.oovvBox');
        oovv.style.display='none';
        oovvBox.style.display='none';
    }

    function getPaymentMethod(method){
        document.querySelector('.showMethod').innerHTML = method;
        document.querySelector('input[name="gateway_method"]').value = method;
        hidePayMethod()
    }
</script>


</body>
</html>
