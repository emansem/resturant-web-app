<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-27b6d639.8c682f3e.css">
    <style>
        .van-image__error, .van-image__img, .van-image__loading {
            display: block;
            width: 100%;
            height: 312px;
        }
    </style>
</head>

<body class="">

<div id="app">
    <div id="nava"></div>
    <div data-v-6d8fe585="" class="detailpage">
        <div data-v-6d8fe585="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='{{route('vip')}}'"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Production Details</div>
            </div>
        </div>
        <div data-v-6d8fe585="" class="imgi">
            <div data-v-6d8fe585="" class="imgtop van-image"><img
                    src="{{asset($package->photo)}}" class="van-image__img">
            </div>
            <div data-v-6d8fe585="" class="boxing"><img data-v-6d8fe585=""
                                                        src="{{asset('public')}}/NorthernStar/dist/img/00.5499421e.png"
                                                        alt="" class="imgti">
                <p data-v-6d8fe585="" class="operati">{{$package->name}}</p>
                <p data-v-6d8fe585="" class="producti">
                    {{$package->description}}
                </p></div>
        </div>
        <section data-v-6d8fe585="" class="section-box">
            <div data-v-6d8fe585="" class="pricei flex">
                <div data-v-6d8fe585="" class="lefti"><img data-v-6d8fe585=""
                                                           src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAAA7CAYAAAAkTufiAAAAAXNSR0IArs4c6QAABH5JREFUaEPtm01MVFcUx3/nMQPIgAiUDzEUbYONrf3ApDQEiLHaha3dotVF08Y0TRdd6KZLl93oooumaUyTLrSUbW1dVGuMEFKaSD9sTTWtUiMKFBCZQWCGd5rHDAwwM/BGBmbo3Jvc1bsf5/7fvffd+3vnCClO2k4p09QB27GsGpQtoNVAOVCMsgmRQsAbyR4gBARnsqof4QEwCgyC9CHcxbbvADfI4aa0MpxKs2UljekZSrBowbJeQbUe2AVSuZI23dXVfuAqIj3Y9o/YXJEjjLirG1sqKRH0BBY7aEStA6D7UXkewXrczlNWT7ER/Q3kPGKf4zpdcgLbbfuuRNA2diLW26geBnGmdoYn7UPkLGp/KYe4tpyxS4qg7byByjFU9gCuBMPKB9/WSK6F/CrIr4S8cvBuBE8ReIvA8oJ4wllD4WwHITgGoTEIPoTJQZjoh4n7EOiFwO1wtieWG9fsc0X0EqKnpJVvE1WKOzD9miaQU6g0LN2bBRt3QFkDbKqH4meh8CmQHLdGJl9Op8H/N4z+AQ96YKgbHl6H5Wa/aDfoMTlI5+JOF4ig31CA3zqJ8B4kWOueQqjcB5V7oXw35BYnP5BU15gahcHL0H8R+i9AyJ+oBxvlcwrt4/Im47OF5kTQr6hB5BzIC3FbKGuE2sNQ9RrkbEj1MFLX3vQjuP899J6Foa4E7eqvqB6Qt3A+u+F1ru1swZYOkK0xtTbvh7oPw1N9vSVnydz8BO6dj2O53sbSZmnlrmg7OahcQaVxQUnf0/Dix+H1vt6Ts2/88hEE/lo4EtEuRFtE23gHrC8WPN38Orx0EjwF6334UftD4/Dzcbj33aIx2e+Kts0sg6a5JxWvQsPp1d3h0yWt82XpPgoDP8yzQDtF26wAEH3lezugoCZdZq5+v+N34GLz/H7GjQjgiGCWg9kYcTZG84lsMYcl57A0u026OzYfgap96+DYfAF6zyR3bJ4TItsvUPM/nFl9lZ6bEa55QpyzTWZBlaiBKeUJq3+mW80eUsQTHEw2cBkGLsHYn85FfDWNdtm2QNEzULEHKnaHsdya8YSpERj+CUZ6YPR3GL0GU0MuDV9BsdwyKN4Jxc9BST2Uvgy5JbENpo0nOML4b0HgFjzqC0PSyX6YHI4C1FAANAh2BLA6sNVyoKsXPL4okM0rhbzKMKzdUA2+bVC4Lf6Al9LU8ISIOoYnRIQwPCEihOEJQHwRDE8wPMHwhAhyd7aLrP/5YnjCot/tWf9D1vCEOOduVYR261OU95O66mQiTxA+o9X+QCT+lXeFThpJyZPewimFKo6TxhNNYfeZTOMJvlr4t3ONnTQykSdkhJNGJvGEtEGV9K78+L0bqGKgysKZYaCKgSrRGWGgSkKfJeO9Zpw0HD9GA1WMk0bUt9k4acRjCa79E/6H8Q6L9cjqyJcYMbI5BipGjGyOhkt0O9bTlOKjeSYu0tZdCPVrFhep9GDJ1Zm4yAAdcvTxA0bdRbglwQhmImQt6giyHbGeBKpXHCELfaj9D15uYKc+QvY/MvDN3ek9pZkAAAAASUVORK5CYII="
                                                           alt="">
                    <p data-v-6d8fe585="" class="numbei">Price: <span
                            data-v-6d8fe585="">{{price($package->price)}}</span></p></div>
                <div data-v-6d8fe585="" class="pruchase"><p data-v-6d8fe585="">Purchase limit</p><span
                        data-v-6d8fe585="">1</span></div>
            </div>
            <div data-v-6d8fe585="" class="boxincome">
                <div data-v-6d8fe585="" class="hourly">
                    <div data-v-6d8fe585="" class="listi"><p data-v-6d8fe585=""
                                                             class="incomei">{{price(($package->commission_with_avg_amount / $package->validity) / 24)}}</p>
                        <div data-v-6d8fe585="" class="include"><img data-v-6d8fe585=""
                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAABf9JREFUWEfVmWmMHMUVx3//2jXr7QmHhEPEF5NwBCInikEhUjyztkAy5hBYWLCHI0NQhFFwOL4iAkgkhq9AwBxCCHHtgTCwAQLGCOGd9ScLkyBkc9hCUaLA4ijyMbNee6ce6p7xbPdM786MvSBNfeyuevXrV/9673WVOIFmfyOgmOnB2wocSzD9FLEI7OSyWR3E2IfsMzyf4PQBQWFMV1M83ml1PAPtpczlOH6H7BpQd2s2bBLTKJ5ntbbwdmtjoSVgG+m+FnQvpqWtTpTaX/YR2P3qnXy1WXtNAdtQ1zm4zk0YlzVruKV+Ygt++lb1T+1pNK4hsI1092HuKeCUVGNme4F3MOXBdtFV/BfTHIz6dnIyU8Fi0M+Q5YBVSGfPAnUA+fXqnRyeC3pOYBsO/gy6O9w9SSNWAo3g/aMamNzeyCvx9zbYvQzn/gjWC+qoGWtgG9VXvGc2m7MC23DwGOjWlIHvounb1Dv1aSugtX1tpOt8rPOvwMp6O7ZJfcUNafZTgSue/VONVycx7lR/MZTHvDUbCtYjHqqPNvaXNE/XAVc0O5iQgZigZFdpoLhj3khjhmww+BUdehPjjPhj5AdqNZ0AjqKBOj9MbLAQlunlJyqBRh8aSYTObTXQB7Dpi+LRIwk8knknGbpsEs/y78qzdboOPe3YlpCH2KLewqpjfavAUVIwtzlhxOyW+dZsQ09HmtaTiX7ya44llxhwsLMmg72rvkJdojBDbGcl5lZgYd3AIZz/GM/r6uH/aUD2Pj9mIeemvPuPfsOuOk8PZ7YkoofsI/UWLwz7RcBRbdDB32cGWgmVltTq1nZwKlMaxbQ8JRQdwmyDeniuDiCvV0BrUoCfVs7fnB7yOj5JxOkSV4S1Rxl4KDOE6IsNHFRfYW2doXG9jOm6OZbVY36Veth6rI/9gwwH3QQQNAscMQ1nXgIGqmOMYfUX+mXPkaEr+CYhdO+ztRnMxliM3JfVcCfbj6wP79YBv42tzphyVl0By9MLbrZ0m+rhCLicEcdjdieZKv5QNpwJd+BMmWe2V/3Fc+q8O8bVyI3OfLFtVY+ttG2swrl4mXiUrO+SsGjicTeCcX1lXPgsHplmBS6vfLCnpva4XDYYPIDTXTGQx9VfrEvJNs46zMX0aaPK2Wob5ybMPRP7wGmyfqFEyXYQcDiSQwbZv0GnYIkiqhHwJqQ/VG17e1A2HLwOuiY24Vr1FcJMl2g2xg04F+b+Y+0tZf2A5fUW6IrY0n2pnP0k8tA2rsO5l6N3xvM4VrcEPJhZi+PFmO1R2VBmF+KC2FdcpIHizjk21sxi5FkC7p+Ai/V/QjkfecXybggqm1n+JnAPtwYcXIhTmHnLzdgdavgbiOJpuS0oLNIa/tccsF4DrU70LfmsVrDdttNNSRNIPyhP5s/CuY9bAt7M6RzN7IvZ3xdK4jCoq/pQhS71cqQRsI1zKebC8BXbRPa2chbJw8a4FlUyp+wLZe08G3f7WwIe4SQsMxWTxNRxAdv7dHKSPsT0i9iHHcH5X2oZuytyCLVXjuXiKWX9LfME3LokbJzbMfdwYhXERmV9VEPb53TxtSaiqBA27we0nKGWgVMl0eKms638iIXaDTottlSfctSW6hIOl73LleDenNksfgOOiUpYnDkWMHuPDntIy3gjTYI2mLrpmgtr1Y2ad88CN8YmCNPxCvWQr/YZYx2Kx+w5d8RXyvkz04HTwlqTiaPiuR5wH9T8jTyirL8jPqHNF/BQkJY4mkzN4UZboJ2gn8ek8F+wSyjFjp4WUAB+jdd9dV4zXYyI/SlbmAV3KGdXpXo4NTU3W/zkwwQQJYJG7QXlfFgQ1fO2ENZSi5+guKjp8tLyHb8He7oRLTA/wLOVl5E2myjgv0/g8pnFHAV8BD3S3C9SEx4+4S7W6BepDNxmP6Fl6Db6zY+A2+0gpSKN8Hi1PY6qqqm1fMzaHoeBMej2OW6t8XR7HGhXoZu9MpDG8LY79crA6QLMer7zK4MqdDtdyiTKxna59qrNtW1zsVgHHpWmmVxLV7dThbxuiGrm42rfArz4c4r5qJTzAAAAAElFTkSuQmCC"
                                                                     alt="">
                            <p data-v-6d8fe585="">Hourly income</p></div>
                    </div>
                </div>
                <div data-v-6d8fe585="" class="hourly">
                    <div data-v-6d8fe585="" class="listi"><p data-v-6d8fe585=""
                                                             class="incomei">{{price(($package->commission_with_avg_amount / $package->validity))}}</p>
                        <div data-v-6d8fe585="" class="include"><img data-v-6d8fe585=""
                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAoCAYAAACSN4jeAAAAAXNSR0IArs4c6QAABA9JREFUWEftmF1sFFUUx39ntlXQPhAf/AAS28iTYMT4gYQHE018JCI7swml3VZMeEADfqar0Ww0WqKCEPGBROxuCySdWT/Co4kmPhBEITYRfcK0Jgvqi/GhCtruHDPL7jq7ndnO7LZNY5zHufec+7v33HvuPX+hjS+LGussNs+6bBGDtZ4rdSl2GJy+aHMmi7itupdWDD2gbpNBEV4GekJ8TKryxpTDSCuAscE+NPWhBBxC2BhpUspECfY94ciXkfpXOkUGO/G43j7bwdsoSYTIduVxFEUodMzyQu/H8lMUwHkHGH1Ub3RXMSTwHLAywOkVEQqucs5rM4T71IMP6atwwPid/f2fyR/NAJuAqYwl2eEK+5FrG7vh8zb2SZShtCOX/G15U9fg2cEOj3WOpVI0lKG+AidBNAgwEOx4Su8vKYeBzYGzUr52DfYOjstXzWY9ktIHDZfDCA+E9DuTEPbuHJdvGtvrwGxTE1dgGOFZINHYWeFywiWzs8CYhMx0ro3K8SR9JYNhgdUBgCWUgyshYzlSqrbXwLwU0GMyjpT3R+N3VeHdG5Q3LUemo2zexj62qV1/Ci8JPAOsCAhvYdIhVU0tNbC8pa8Br9QZeKcJPhF4vt+RyVaAGm1GTe1ReAfYFnC6X0/b8qpnUwYbM3WdK/wAdPocTanLkwMF+XwhgBp95JL6iBh8AHT72mYM5c4+Ry6WwXJJPSIGe2odlOLsX2zadUouLwZU1eexrbq643rO1p165UjakafLYHlLi8CaqoFCasAWu12onKlbRTjq+VFl94Ajp+asnKWWwLjv/6W0LWtldJverJ386muYvvojN+0+LzPtguUt/Rm4teLnl7QttzX6PHqvdq64g9+ArtqJnOEWyW3X9ZLggs/gQtqWu9qFqkSiLnmmbQnMm3lLvwM21CJWYoOMpfRuV5nwgUykbbknDlhYyPKWRgX7Fv59FBjCxgUBCwvZcgALXJklA4sbsiUDixuypQSLFbL/wcJWIO7/xlSUt7S9dBEX4L8ZyjhX0iKu2NwrKc4l3iRdBF7WbV3icZ49YQk27n//5s+FPXvKYKa+h/DUsnsohj2tRdnV78gXcV4aUfuOmvqwCseaPq0r4Vx+xYgHNl/5BhycVob3tFi+vW9qV5eQgXLNGr188+CiFLy4ZNIxC958kj5aLXj9eyOCRHDWNdgXUSLwJKtNIXsvmkRQb6yS306vJBhWQkQV5QSQCRRVrkkNvUGiikBRS2TSH3n2MUQVP6AnQ7GKIV0gGUrgAO3JUPXrN/KYdhvX8VY7wp37Ny8OfipTUVLKvMJdo5Oy1Ckc8lc18ww0UdJFlDr9g2ezanR/H1EcXs9INhtfvY69YnWAVTkdtkjlgCgUO2hfTv8HvT66IWvzsosAAAAASUVORK5CYII="
                                                                     alt="">
                            <p data-v-6d8fe585="">Daily income</p></div>
                    </div>
                </div>
                <div data-v-6d8fe585="" class="hourly">
                    <div data-v-6d8fe585="" class="listi"><p data-v-6d8fe585="" class="incomei">{{$package->validity}}
                            days</p>
                        <div data-v-6d8fe585="" class="include"><img data-v-6d8fe585=""
                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAABO1JREFUWEfVmU9oHFUcx7+/mSXRyHoxFUUQsaCVHrRBUPxT9aBtkQYSqJnM24CnFmsLBfFQ/HPwXy4ihdqInoTsm0wsGkxR2/SibRUF0V5Ka8EiQlFqvGQxMWFnfvJmJ9s3s7PZmdnxsO84ee/3PvvN7997j9DF4N27B1AuPw6iJwBsBfM9IBoEczkwS1QD8yKILgO4AOZvUKudpRMnlvNuS3kW8vj4ThjG8wCGAdyY0cYKgHn4/sc0M3My41pkAmYhRgC8DuCBrBu1mX8ewBsk5Vxae6mAeWxsM0qlKQDPpDWccd4C6vX9NDv7a6d1HYFZiDEAHwG4uY2xK2A+BaJz8LyLWF39HaVSLZhbr5fR338nTPM+MD8Goh0A7m5jZwnAXpJydiPoDYFZiDcBvKLCJ2KE2QPRJ/C898l1v+ukiv53tqxHYJoHwPwciMzYWgbwNkn5WjubbYFZiGMA9rcsZD4NwzhI1eovWUDjc7lSuRe+fxRETyfYmSIpX0yynwgcKvtqTFUV3YfIcZR7FDbYtvcCOAKieLZ5K0npFuDQZ2dibnANnvcsue6PnUi5UhkG84fBPKJ9VK3Od1xjWQ/CNL8AcKs2V7nHeNynI8BhNvgpFmDXQLQ9rQuwEH8AuC3c+E+S8vZOwOrvgYswn4lBL6FeH9KzRxRYiFOR1MW8At/fnkbZdSgWQinTHCRlx0zUXKuUNowzMfdYIClVdmn807SNVFH4LOa3+7L6bDfAgdLKp4kaLnV9jK4XFx3450gFYz5NjpO5UHQLHEIvxLLHeZJyW1PhsDf4qvmDVJ41jK1p/VaXohDgRsq7EMnTvr9L9R6BwiyEC0BVtPUxQ1LaaYIlPqcI4JDJUVlCsz9LUlrEExM3wff/inRdnvdo1gqmxULuoIv8pxoV8Vvt2woMYxOxbe8Akd7mXSEpN+dRN1SmEODQlmqGrvcezDuJhXgHwGHNfz8gx2ktySl/QVEuEQbfFIhe0LaeVMCfh4144zuRTdWqqnS5RqHAQqg4khrIvHKJiyDa0vzoeUPkuirF5RqFAlvWNpimqryNwXxJKawCbrD5cXl5kObm/s5F28g4ER+G5z1Frvt1Hns8MnILBgYWtbWLSuF/QdTf/Li21k/Hj6/l2SAMFL2XUKowiD6F571MrvtbFru8Z08f+vpWNYVXiwe27XigrO+n2tP3YBiTND39TxrwZOCiXWJ4uIxy+SiACQBGAthVMB+G41QJiLpPbHI7lyg06JrxYVkPwTSPAHi4jZrfw/MOkev+0E5tbhN0haY1fXNW3aBtV0A0CeCOBDAfwDRqtYM0P984uGqDE9NawYUjSa2w/Kvi9BKAGxLmHCMpD7QAt8bDZOGleaNgYsu6C4bxLoBREOmN/UmScleCwgmlueDmJ1X0VypPgln59/1gVmlrlBzny4g7JDU/S0uDhbeXaYCDfK0yiGUNoVS6StWqyt1x/01uL4PFjcu9Qhr4tMAbuk6nBj6AFqKQI1IhwLa98REpBC7kENotcOpDaAjd9TG/G2DOcswPgBvXql1dpOQFznWREqqsDqO5r6ryAAfK5rmqWt+spy4DNejeuW6NKd0bF9oadLonA8M4i3r9UuKTQam0Bb6vnsf+3yeDJnQvPcpEGpJeefZqaUx65WGxBVy1pp6nnrPSP92a5rm0h9CknP4fjM++km2AI7QAAAAASUVORK5CYII="
                                                                     alt="">
                            <p data-v-6d8fe585="">Cycle</p></div>
                    </div>
                </div>
                <div data-v-6d8fe585="" class="hourly">
                    <div data-v-6d8fe585="" class="listi"><p data-v-6d8fe585=""
                                                             class="incomei">{{price(($package->commission_with_avg_amount))}}</p>
                        <div data-v-6d8fe585="" class="include"><img data-v-6d8fe585=""
                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAABf5JREFUWEfVmVmMVFUQhr+6Mz0wChoFNxSE20RUHkA0mCguMYgohqCJIxAVpxtEcH1wiXGJ+xIeNKLo6PQd1ChKjAqiLPoijPqiIg+KGvuyqLgAIbI4a3eZ03SPZ+7c7r6NoOl6u+dU1flP3Tq1nCP8CxrSpIfVxTjPgQsERiucIjAYGJhXu0dhh8APCt9k4ZPOLtZtmyt/HeiyciCC8WadjMP1ClMF6ivRodAmsJwsi9OzZVUlsoa3IsDxlF6hDg+IMrbShcL4VfhasjycTsq7UfVFAjyySePZOhaJMimq4kr4VFjjdDL/x7mSLidXFnDc06uBl4AjiijzFVaTpTUDG7tjbD2ynj2G9882BtZ2MawGTsNhgsAlgFtEz27ghnRC3ioFuiTguKePAPcGXUchAyzNwHNbEvJZOavY8yd7ek4N3Aw0CNQEZBV4LJ2Q+4vpLArYTenzIswPCip8pMotm5LyfSVAg7wjUjpKhIUCF/dZQ1nkJ+WmMP2hgPOWvc8WyJ/u29MJMe5x0Cju6Q0Kz4REm0fDLN0HcN5nlwTc4A9VpvhJ+eKgIbUUuSk9S4QPgGOtYeMeM4I+3QuwiQYa46vAAfsjq5z/b12g3EaNizjC2gDo3dLFODt69ALstuhqO3QZN0A5/1BZNrgJY2mEtbZ7mJDnN4qJLjnqAWySAsI7ASVzD7bP2vpPWqr1/fZynRnrGMCrPzdIm/FpoKkXDuXKQnLpAey26Ho7g5lo4CfkkCSKHJgH1XGHslKkJxktSydkmplyPV1jRw+TEf1GOaPHwvnaYGVhVybOqjL6UPqt26J3i/JkjyWVjnRS+pvvfMj7plecznKpqT1yFo57+iZgMlqOFJb4CZlZ7qAc6PyIZh3vCK0IMWvN9/2ETC18u56+ITDDWuOtdEKmy3EL9PDDB7HddvRuOLfSDBYV/KiUDuwW1hs7WTLbu2OM2XKt/FoYMxmxFj61NtS2byfHyHBPL6kBu8zz0wmxlUXFEonP9fQ1gWssICbeTvUTsiKoIO6pKYZ6ao8MTBbX08cF7rEUvOAnpE9KjoSmDNOIZr3WcXg1wPZsOiG3hYm6ni4SmGdhe0Lini4zO7QGZ/oJMZnuoNLIxRrXbM4VCt2IOSsbnL2c/eOt0hEKuFlnisPr1txyY+GNAqcWBruzjNsyW4ziUDJtUX2MN9hfKq7uaqdx63zZVXJ3TRpz62gVZbxlmL8yGc7aMkc2FpM9uVnPqHVymTdHCt8ZC29nfx+Wo/YaBv8yS3YWUxJPaROCCe4FLRsznVy2eZ5sLibjNutT4nBXYL5sUjrxFR3UP8MOS26HAdwO9CsM9htAv28bpDNs8XiLTkNz2bBXSlf4TRwuT18vXwblXE8noqwWwbEs9bafkKtK/hXg9KVa17EX2106IgMemtIhdcIG+28EFtyrWab7s8VUXTka6ekxWWWDCCdYvFu72hlb1o1KAC7vEqritmDS5URrYROOepenSrfCLX5SXjR8bkpXiDDFkunOZrho0xxZV866Zj7UJaIcurindwALei0i3KVwtCh3B4CrCk+R5XcRnrZlVHnIT8qDUcAanmKHrmRYywt9bvu5wsd+I5MQUTelNwosRKjtBQ5UrD+g0OoP4EIaxPSDkcgtEtaKJg4TwvrH+NIOe8COTmXMT0nZVljVbdYp4mDqkQFhSFTZRS1j/VmyNRLSPFNo4iiVmuOezgVy/pgnRbgy3SjvBReOL9YzNcsKgeMDc5qFhk0JebsSsIY3NDWXKn76AFZeSifFbCKUhr+gw2vq+BDhNGuLL6eT8k/cjog6rPhp72JwyfIy3xEsQZmMsKqti5nlLvKGLdKjYv1pKWTCKDJheyhaXuZMv/9y7z8t4EsZumwBb4T/8xapBOKyLVLOyv9DExqGOXITmrdy9bT5BnDVXaTkY59pRqvjqqrgU1V1GdiTbqvpujVg6eq40LZAR3sygHWZLN+FPhk4uZ7xvEP+ZFAAXVWPMnZwr5pnrz6lZLU8LAaBm9K0fhATKnm6bdtJ6+93yr6IVWYftr8BG40TKKNoo7wAAAAASUVORK5CYII="
                                                                     alt="">
                            <p data-v-6d8fe585="">Total revenue</p></div>
                    </div>
                </div>
            </div>
            <?php
            $myPackage = \App\Models\Purchase::where('user_id', auth()->id())->where('package_id', $package->id)->where('status', 'active')->first();
            ?>
            @if(!$myPackage)
                <button data-v-6d8fe585="" class="btybuy" onclick="buyPackage('{{$package->id}}')">BUY</button>
            @endif
        </section>
    </div>
</div>

<div class="loader" style="
    position: fixed;
    display: none;
    top: 50%;
    z-index: 99;
    width: 143px;
    border-radius: 15px;
    overflow: hidden;
    left: 50%;
    transform: translate(-50%, -50%);
">
    <img src="{{asset('public/loader.webp')}}" style="width: 100%;" alt="">
</div>
@include('alert-message')
<script>
    function buyPackage(id){
        document.querySelector('.loader').style.display='block';
        window.location.href= '{{url('purchase/confirmation')}}'+"/"+id+"/"+"package";
    }
</script>
</body>
</html>
