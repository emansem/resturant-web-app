<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-bca3726e.75819045.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-d0c1a326="" class="rulepage">
        <div data-v-d0c1a326="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='{{route('user.deposit')}}'"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Deposits Record</div>
            </div>
        </div>
        <section data-v-d0c1a326="" class="section-box">
            <div data-v-d0c1a326="" role="feed" class="van-list">

                @foreach(\App\Models\Deposit::where('user_id', auth()->id())->orderByDesc('id')->get() as $element)
                    <div data-v-d0c1a326="" class="listbox">
                        <div data-v-d0c1a326="" class="right">
                            <div data-v-d0c1a326="" class="typeti flex"><p data-v-d0c1a326="">Deposit Item</p><span
                                    data-v-d0c1a326="">{{price($element->amount)}}</span></div>
                            <div data-v-d0c1a326="" class="timetype flex">
                                <p data-v-d0c1a326="">{{$element->created_at}}</p>
                                <p data-v-d0c1a326=""><strong style="text-transform: capitalize;">{{$element->status}}</strong></p>
                            </div>
                        </div>
                    </div>
                @endforeach
                <div class="van-list__finished-text"></div>
                <div class="van-list__placeholder"></div>
            </div>
        </section>
    </div>
</div>
</body>
</html>
