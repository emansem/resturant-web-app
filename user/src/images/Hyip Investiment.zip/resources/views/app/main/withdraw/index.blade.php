<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-34efe55e.35185f70.css">
</head>
<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-116c4ab6="" class="rechargepage">
        <div data-v-116c4ab6="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='{{route('dashboard')}}'"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"><!----></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Withdraw</div>
            </div>
        </div>
        <section data-v-116c4ab6="" class="section-box">
            <form action="{{route('user.withdraw.request')}}" method="post">
                @csrf
                <div data-v-116c4ab6="" class="topbalace flex">
                    <div data-v-116c4ab6="" class="lefti"><span data-v-116c4ab6="">Total balance</span>
                        <p data-v-116c4ab6="">{{price(auth()->user()->balance)}}</p></div>
                    <div data-v-116c4ab6="" class="righti"><img data-v-116c4ab6=""
                                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAAA6CAYAAAA9Qj4fAAAAAXNSR0IArs4c6QAABiFJREFUeF7tnFuIVWUUx39rHzQ1TSksp+zGdHuYXqSHoAhMk3rooQcfAoUaH5Iw3yqjTESiO4QM4Uv24ECYD1EJimmCcyYMxILmISsZR52LjtpxvMzlOHvFt8/FOcc5c779nb1nC+0PztNe67/W/p+11/d967sIMTQ9yCxm0IJkWkCbURYjuhC824BbiiZHwR9CZRDhNMhxdLyLPF2ylJEo3FKYBbQUf83AYmAhUOUHQ8AgGD84DnSZnxCNHxPfRaJ4MYOhWeahLEe8ZSBLQGe6YcsY6FHUP4CwX57mUhgchXnAcmAZsARw9IMx4ChwANgvhPOjls8NE66dNON7q0BWIFqK3jAc1ZZVGQXdh+e3y1NB5NVsCiaCVwErJnxF0fgBo8A+oF0KX4BzcyZcD9GE561HZBmqnrMHNooiPqoH8P2t8gz9E1UUmoD1xYiO1w/wixG/Vaj0w+Y1jExowvUIMxjOrEb8VhCTI6ex6QjqbWf2+A6eCMyuBlop5OrpbKaP2Q7sEMiHMRyKcD3MYq55HwGPhTESuewYx1njQ3eQRpJsfwIbpNDZWjVrwjXLUkQ2oTLXCjkuoSvM5TxNDCts1346uRyXKUtcY3+zwEEbeSvC9ZfMSnzehJhzdT2Ph1jAv9yFFlOhouzUM+zWXD3VmJ+b3P6pwK56duoSrtnMGmAtaF3ZesYaep7jDnLBGLqyKbBbB9mp5xvCb1zZeLJN4KupoKYksRjZbyVOtonsCyyq+SLmVXfqwE0Q6caTT6aK9JqEBzmbzMeJpxGTs89xTzmN1GLdpJdtfu9NkNNNenm7Vk6flPBgNDIu7Yl3kNeYQR8P4JOx+uJHdZz39QS94YZqVtjhhExHumqy0csNhAfj7BHv68SHfqZj7Od+xkKOsU/rCBu1hzzm806ymSHjq9Xj9BsJ78i0Ivp6kp4Gtmt1kjaO/aCDfJt4J2o8/VIKE6RyqyC8MF2XXdM/g6xi0aSSXh5EcZuq59Vng3ZzJvHUYmakKyeWASoJz3ofAs/ZBFGsMme5m6tBCdW9/aZDfK597gCRaf4k8E4JrUx4UPUj803shah675FnJn1BdDc67lc2+t10B2XWJJsZtbxcqjJeJ7zD24TwYpKeBbbPsYjLLIjEj8Oao00HIsFqDORHgc0GIiC8sHiQ2Rt5PTuskz4ep3jIOXdX28vj84b/D5eDsmqSzdTTnzeLGAXCO3gJ8d5N0qPA9iXmB4WpKFu7389eLkYJ6Yj1gcB3xQj32oAnHYGiUxvgXka4NTpA4JheYYueihTTDeywwDopLPhmfnZfg3SzfoOW6SRP8nBk6aRk4Bo+r/l/M5r4RMh03s+KZs3aibctItrcYYaZwxnucweYQvMz/yS/czUW7HCga0U7M6+gui6cXgzSOW4nx50xIMP3epZdeiEW7HCgbaKd3haUF8LpxSA9SBNXmB8DMhzRi3yhFYvPsdipD7pHNBsUqh6vLxuzRF9QqJodi5UTOsx72hMLdjjQP0Q7ZTcqtYv74QDdpU/TjKmhxNFymmedNrSfJCK3BkSzmQ7QeCIrjJc9PBL5CKVkfwyfVv+vMO7EJDtsOs1fUbUr8MfkRQDbw6MR1E8m99CsBq32j8XpviX2eEq4JVMRiQWEH0J1TkSA7jD/j5RyNe003UPERdN0mumw0IU5Rx0zLEwnPo7kuajtSaf2LrS567SlxSt38lw016blWRfa3HQK5Vmjq9l0AcKNw1BahQWIgPB0iS0Uc47CE5fY0kVkRxJt1SoXkQtRnm6TsGXPQa5ym0RAeLoRyIFHK5XJNwIVO890q5sVh6GEJt/qFhCebuYMxaSF8NSbOQu5PN2ubEGkrcjU25UDwtMN+bZk1pOz25AfkJ4eOalHZr3n9kdOSkjpoap6nNZ8Hv5QVZn0woHY9NigPffuxwavR3p6MNaS78YPxlZFenr0uzbz0R39rsjp6eUGk1Ee/eUGZdLT6zuqCY/v+o4y6ekFNYaK6bmgZuLfm17BNE1XMFV/U+klY5ZjmKJYo2chy9bSa/TsiI+M8Ip0U+uiSPXmI8V7BJUxxL+Y0EWRZuN/6T5Ds7hrTrlNy0WR/wEBuClTcvDPSwAAAABJRU5ErkJggg=="
                                                                alt="" class="imgui">
                        <div data-v-116c4ab6="" class="recordi" onclick="window.location.href='{{route('withdraw.history')}}'"><p data-v-116c4ab6="">Record</p><img data-v-116c4ab6=""
                                                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAAQCAYAAADwMZRfAAAAAXNSR0IArs4c6QAAAR5JREFUOE+11E9LV0EUxvHPsy4kQkICSSIQkkBo0ULQyqQ27VtFb8gX4ZuQEPMPBC2CIFCEoE0EEiIR4vrI/LjF9bq8dnYz55nvPGfOzKSqdnELr5L8MoiqWscbvE7yZZhv41TVARZwiGdJTvrCqtrAW5xiNcnXIahB7mEPc2iCJmwLJlFVN7CJZbQNnidpG/+LdML7HWgWzfKLJL97oJt4jyW0kpvjo7/5CaQDPcA+7uIz1pL86eWnsIUnOMbTJN8mZzKof75zNINPeJnkrAdqDdjGY/zsQN8vQTpHD9E6dgcfu66d90C38QGL+IGVK5AO9Ag7mMZGkncDx22+5Zvu4P9AqmpcOVU17mCralyLq2rcZbuWa39dD3D0V3ABy3+16wVi4e4AAAAASUVORK5CYII="
                                                                                                     alt=""></div>
                    </div>
                </div>
                <div data-v-116c4ab6="" class="input-box van-cell van-field">
                    <div class="van-field__left-icon">
                        <div data-v-116c4ab6="" class="leftount"><p data-v-116c4ab6="">{{currency()}}.</p><span
                                data-v-116c4ab6=""></span></div>
                    </div>
                    <div class="van-cell__value van-cell__value--alone van-field__value">
                        <div class="van-field__body"><input type="tel" inputmode="numeric"
                                                            name="amount"
                                                            placeholder="Please enter the withdraw amount"
                                                            class="van-field__control"></div>
                    </div>
                </div>
                <br>
                <br>
                <div data-v-116c4ab6="" class="input-box traninput van-cell van-field">
                    <div class="van-cell__value van-cell__value--alone van-field__value">
                        <div class="van-field__body"><input type="password" placeholder="Please enter transaction password"
                                                            name="password"
                                                            class="van-field__control">
                            <div class="van-field__right-icon"><img data-v-116c4ab6=""
                                                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAbCAYAAAD/G5bjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAJ6ADAAQAAAABAAAAGwAAAABa5ZcvAAADAElEQVRYCe2VTUhUURTHfTMxYAgaCkXYQnCVmyiIIgj6oF3RygghoslxZhMYtKkIIUmj6JOYEXVZkRVCy6AWQWVBqygoCoJECppCkBbCOP3+t3eGyzgzOVjjIh+cOeeer///nnvfm7q65Wd5AkswgXw+HxkaGtqIrFwC+AKk8MVDfOR0PzhG5ubmXuF8aYFCRY0M4QpfPMSnQA5jqxYEO4aHh9tl1/oRrvBDXMfHTQ7HRyNDwnqza6mLcB0fRy4IgvcekV2eXTMTcrs9sHeyjdw9C3DmcUa82ta10MKD3BHDikQi92U7colE4hnTexEG63O53DVLrIUO8eqFJR7iI9uRk8EzTiAvg110ptPpU7L/9SMc4QknxB83zEBGJpM5gLpJUtQCoT6XTCZPG+mi2KKWYAXg9tPkpN8IrBzrLnDvBJz3Tsb6sAQxq3kQi8VS8Xh8yhyL1aOjo2tnZ2fT9NlXqpcIRqPRPWJ/C2IHLSlk/hTfdvOhZ/D3I9d7enp+ev6qTP0DUHCMl05XpsGK6fsEe5s/IHy3defeeklupBDYQfAi4u4g8QYKB5EpNnODaW/CdlfCastp5SlfdaqH2ID6KV/9hSM8ll3YwncPuW+CsbGxWDabPUGgg1GOdHd3P7YEmm7hyNMkbjCfp39Q8xzRX84Xar8Rm0YaqWnhc7CGus2IvvarvDpnUveVmv3gTVgsvGJHRay5ufnCH3fPUfQCfska/E3NBnqZ2pVyPSuSg1gLu/iANHoNJth1K75Wz1fRJH+S/EfoLPq4JbOeRtohqKnPe/zv3LwgjTqRAjE1Y7d7ec3XkdzGsRxCn8WfQfwXZUb+MN6m/FQqdZicAfUwIPUWhq2L9Ypih7+GyHfuT8FF4z7bJWCfCEjcw8c0aTa6gfgZb+1M1XIafRC6bDFhmF2sK06uqanpLgWDkHqNnOdv5Wpxg2rX6qFe6qneIUbJNhXvXMmKMk4+FZ+ZiLuHAE+GR18me2HuipNbWIvfWRxPQqQksqupXc79rybwCyR7Y+KXnDpPAAAAAElFTkSuQmCC"
                                                                    alt="" class="eyeimg"></div>
                        </div>
                    </div>
                </div>
                <button data-v-116c4ab6="" class="btnrech" type="button" onclick="Withdraw()">Withdraw</button>

                <p data-v-116c4ab6="" class="methodi">Withdraw rules</p>
                <p data-v-116c4ab6="" class="textui">1. Withdrawal time is from 9:00 am to 17:00 pm.<br><br> 2. The minimum
                    withdrawal amount is {{price(setting('minimum_withdraw'))}}<br><br> 3. Withdrawal tax {{setting('withdraw_charge')}}%.<br><br> 4. Withdrawal will arrive in your
                    account within 1 hour to 12 hours.<br><br> 5. Please enter valid withdrawal account information to
                    withdraw funds. If the information is entered incorrectly, the withdrawal will fail. After the
                    withdrawal fails, you can apply for withdrawal again.<br></p>
            </form>
        </section>
    </div>
</div>
<div class="loader" style="
    position: fixed;
    display: none;
    top: 50%;
    z-index: 99;
    width: 143px;
    border-radius: 15px;
    overflow: hidden;
    left: 50%;
    transform: translate(-50%, -50%);
">
    <img src="{{asset('public/loader.webp')}}" style="width: 100%;" alt="">
</div>
@include('alert-message')
<script>
    function Withdraw(){
        document.querySelector('.loader').style.display='block';
        document.querySelector('form').submit();
    }
</script>

</body>
</html>
