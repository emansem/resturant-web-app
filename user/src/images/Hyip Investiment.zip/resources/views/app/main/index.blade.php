<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-3cade526.7c0d8bb4.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css">
    
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick.css">
        
            <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick-theme.css">
    <style>
        marquee {
            background: hsla(0,0%,100%,.18);
            padding: 15px 21px;
            color: #fff;
            border-radius: 50px;
        }
        
        
        .carousel__slide__inner {
	 overflow: hidden;
	 position: relative;
}
 .doAnimation .slick-active .carousel__slide__inner .carousel__image {
	 animation: scale-out 0.875s cubic-bezier(0.7, 0, 0.3, 1) 0.375s both;
	 transform: scale(1.3);
}
 .carousel__slide__overlay {
	 background-color: transparent;
	 background-size: 100%;
	 height: 100%;
	 left: 0;
	 opacity: 0.5;
	 position: absolute;
	 top: 0;
	 width: 100%;
	 z-index: 2;
}
 .slick-active .carousel__slide__overlay {
	 animation: scale-in-hor-left 1.375s cubic-bezier(0.645, 0.045, 0.355, 1) 0.25s reverse both;
}
 .carousel__image {
	 height: 100%;
	 object-fit: cover;
	 position: relative;
	 transform: scale(1);
	 width: 100%;
	 z-index: 1;
}
 @keyframes scale-out {
	 0% {
		 transform: scale(1.3);
	}
	 100% {
		 transform: scale(1);
	}
}
 @keyframes scale-in-hor-left {
	 0% {
		 -webkit-transform: translateX(-100%) scaleX(0);
		 transform: translateX(-100%) scaleX(0);
		 -webkit-transform-origin: 0% 0%;
		 transform-origin: 0% 0%;
		 opacity: 1;
	}
	 50% {
		 -webkit-transform: translateX(-50%) scaleX(0.5);
		 transform: translateX(-50%) scaleX(0.5);
		 -webkit-transform-origin: 0% 0%;
		 transform-origin: 0% 0%;
		 opacity: 1;
	}
	 100% {
		 -webkit-transform: translateX(0) scaleX(1);
		 transform: translateX(0) scaleX(1);
		 -webkit-transform-origin: 0% 0%;
		 transform-origin: 0% 0%;
		 opacity: 1;
	}
}
 

.slick-slide img {
    display: block;
    width: 100%;
    border-radius: 8px;
    height: 214px;
}
.slick-dots {
    position: absolute;
    bottom: -25px;
    display: block;
    width: 100%;
    padding: 0;
    margin: 0;
    list-style: none;
    text-align: center;
    display: none;
}
.slick-dotted.slick-slider {
    margin-bottom: 0;
}
div.carousel__slide {
    height: 214px;
}
.homepage .nav-top .itembox[data-v-d2cdda40] {
    margin-top: 4vw;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-pack: distribute;
    justify-content: space-around;
    background: #ff8f00;
    padding: 14px 0;
    border-radius: 5px;
}
.carouselsnsjnfc {
    width: 97%;
    margin: auto;
    border-radius: 10px;
    overflow: hidden;
}
.homepage .nav-top .itembox[data-v-d2cdda40] {
    margin-top: 4vw;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-pack: distribute;
    justify-content: space-around;
    background: linear-gradient(to right, #260764, #2a053f);
    padding: 14px 0;
    border-radius: 5px;
    width: 93%;
    margin: 12px auto;
}
    </style>
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-d2cdda40="" class="homepage">
        <div data-v-d2cdda40="" class="nav-top">
            <div data-v-d2cdda40="" class="navboxi van-nav-bar van-hairline--bottom">
                <div class="van-nav-bar__content">
                    <div class="van-nav-bar__title van-ellipsis">Home</div>
                    <div class="van-nav-bar__right">
                        <div data-v-d2cdda40="" 
                            <img data-v-d2cdda40="" src="" alt="" class="
                            <p data-v-d2cdda40=""></p><span data-v-d2cdda40=""></span>
                        </div>
                    </div>
                </div>
            </div>

           

            
            <div class="carouselsnsjnfc">
                <div class="carousel">

@foreach(\App\Models\VipSlider::get() as $el)
<div class="carousel__slide">
                <div class="carousel__slide__inner">
                  <img class="carousel__image" src="{{$el->photo}}" alt="Image">
                  <div class="carousel__slide__overlay"></div>
                </div>
              </div>
@endforeach
              
            
              
            </div>
                 </div>
            
            
            
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
            <script>
                // find elements
                var carousel = $(".carousel");
                
                var options = {
                  adaptiveHeight: true,
                  arrows: false,
                  dots: true,
                  fade: true,
                  infinite: false,
                  mobileFirst: true,
                  rows: 0,
                  slidesToScroll: 1,
                  slidesToShow: 1,
                  speed: 0,
                  zIndex: 75,
                  autoplay:true
                };
                
                var addAnimationClass = true;
                
                carousel.on('beforeChange', function(e, slick, current, next) {
                  var current = carousel.find('.slick-slide')[current];
                  var next = carousel.find('.slick-slide')[next];
                  var src = $(current).find('.carousel__image').attr('src');
                
                  $(next).find('.carousel__slide__overlay').css('background-image', 'url("' + src + '")');
                  
                  
                  if(addAnimationClass) {
                    carousel.addClass('doAnimation');
                    
                    // so that adding the class only happens once
                    addAnimationClass = false;
                  }
                });
                
                carousel.not('.slick-initialized').slick(options);


            </script>  

            
            
            
            <div data-v-d2cdda40="" class="itembox">
                <div data-v-d2cdda40="" class="listit" onclick="window.location.href='{{route('user.deposit')}}'"><img data-v-d2cdda40=""
                                                            src="{{asset('public')}}/NorthernStar/icon/20240626_024331.png"
                                                            alt="">
                    <p data-v-d2cdda40="">Recharge</p></div>
                <div data-v-d2cdda40="" class="listit" onclick="window.location.href='{{route('user.withdraw')}}'"><img data-v-d2cdda40=""
                                                            src="{{asset('public')}}/NorthernStar/icon/20240626_024411.png"
                                                            alt="">
                    <p data-v-d2cdda40="">Withdraw</p></div>
                <div data-v-d2cdda40="" class="listit" onclick="window.location.href='{{route('user.bank')}}'"><img data-v-d2cdda40=""
                                                            src="{{asset('public')}}/NorthernStar/icon/20240626_024451.png"
                                                            alt="">
                    <p data-v-d2cdda40="">Account</p></div>
                <div data-v-d2cdda40="" class="listit" onclick="openCheckIn()"><img data-v-d2cdda40=""
                                                            src="{{asset('public')}}/NorthernStar/icon/20240626_025011.png"
                                                            alt="">
                    <p data-v-d2cdda40="">Gift Code</p></div>
            </div>
            
            
            
                <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
                <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
                <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
                <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-25561eec.1bdf73df.css">
                <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-57221a82.4c1adb14.css">
                
                <style>
                    .homepage .nav-top[data-v-d2cdda40] {
                    width: 100vw;
                    height: unset !important;
                    background: no-repeat;
                    background-size: cover;
                    padding: 3.333333vw 4vw 0;
                    position: relative;
                }
                .homepage .nav-top[data-v-d2cdda40] {
    width: 100vw;
    height: unset !important;
    background: no-repeat;
    background-size: cover;
    padding: 0;
    position: relative;
}
                </style>
            
            
            
           <div data-v-7501b02e="" class="productpage">
       
        <section data-v-7501b02e="" class="section-box">
            @foreach(\App\Models\Package::where('status', 'active')->get() as $element)
            <div data-v-7501b02e="" class="listpro">
                <div data-v-7501b02e="" class="topcent">
                    <div data-v-7501b02e="" class="topi"><p data-v-7501b02e="" class="namei">{{$element->name}}</p>
                        <div data-v-7501b02e="" class="pricei flex"><p data-v-7501b02e="">Price：<span
                                    data-v-7501b02e="">{{price($element->price)}}</span></p><img data-v-7501b02e=""
                                                                              src="{{asset('public')}}/NorthernStar/icon/1.png"
                                                                              alt="" class="imgti"></div>
                        <img data-v-7501b02e=""
                             src="{{asset($element->photo)}}" alt=""
                             class="imgpro"></div>
                    <div data-v-7501b02e="" class="dailyings">
                        <div data-v-7501b02e="" class="ingsi firstis"><span data-v-7501b02e="">Daily earnings</span>
                            <p data-v-7501b02e="">{{price($element->commission_with_avg_amount / $element->validity)}}</p></div>
                        <div data-v-7501b02e="" class="ingsi"><span data-v-7501b02e="">Resources income</span>
                            <p data-v-7501b02e="">{{price($element->commission_with_avg_amount)}}</p></div>
                    </div>
                </div>
                <p data-v-7501b02e="" class="limiti">
                    Purchase Validity: <span data-v-7501b02e="">{{$element->validity}} days</span>
                </p>
                <img onclick="window.location.href='{{route('vip.details', $element->id)}}'"  data-v-7501b02e="" src="{{asset('public')}}/NorthernStar/icon/2.png" alt="" class="imgri">
            </div>
            @endforeach
            </section>
    </div>
            
            
            
            
            
            
            <div data-v-d2cdda40="" class="mybalance" style="display:none">
                <div data-v-d2cdda40="" class="leftit">
                    <div data-v-d2cdda40="" class="numberanm"><p data-v-d2cdda40="">{{price(auth()->user()->balance)}}</p><img data-v-d2cdda40=""
                                                                                                     src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGqADAAQAAAABAAAAGgAAAABMybYKAAADYElEQVRIDb2Wv2tTURTH89JUqM1gBknNUOpiQFGEIoq4RKlZSlPakLb/gIODFsR0q9hJAoJdOrn3tzSlSyw24CCKFERRrINIhzalQxxSCzZt/Hyf74U0fS82Fb3wuPeeH9/vPe+ce94zPH8YExMTZwzD6C6VSh2YtvKELJc15lV0i+jm+vv7v1hyx8lwlCKcmppq393dTbG87mZTJV9qaGhIJhKJ5Sq5uT1AlM1mfblc7gknvc1JmYxNLJ/xpBsbGz9Bvi5PQE8Vi8Vz2HSx7WE+iS1TaaylpWUwEokUZWePfUQLCwuBQqEwi3EEgy0cU4FA4HE0Gt2yHZzmTCbTnM/n7+GXRN+MX9bv9/d2dnbmbfsykSLZ2Nh4LhIMv/l8vlg8Hn9vGx5mnpmZuUCUaTDaRBYMBm/akXltAL0um6SpqelKvSTCkY98dVBhCdPGNyNS4vf29t6i/EEerh6FxAbUrMh2dnZeQXjc6/VeUoGYEam6IEFupP6WRETCEJYwrcr1GEQTZvMZxSaJP+2WeO7TUzCuYXerr6/vpQBrDXD9vKWvkKkaw14WMTkwz7qRSI/xGjZhnLOTk5OPADomudvgdRXQ6VrIt1tEuvHazGt2G0QxjE2C5ztkQzxvIDvrZi+5jSkO5UhtxaPLqLnWoM1MU1XnsVHbucgrXya6O6zL16TSnyvy0dq3isjsXTiZN77S0Gkdi8XWIIxSTXelJ7JRIlOrOjA4VM4ShsyqO2BRp8AtIrpMyYIqiUhd2OxdlrDmlE6nQ1RgRpHIkDwMkr/7Tk7qh5Z8XUSr2nDBaiZWNryi+Pb29geWHRC8A6id1zjK2j65zMpDTdfarHoxWrQ2ZpmXraoWJH2EPE7zmk7gkyJHlynhmgWErTq7ol4UUdrC7FEXrsIvb3EKYbsCQYQohiD5WVY6LCysHqnwnTPLcnx8/AX76wA9AGTEwa9uEXkchuAhjksDAwM3lCMVQhIS5KWkGmLdqFUOwhCWMIUttUmk7opijH2zvieMYJXvobfyFYawhClsOZtEWujzywmyKNuorNdHiUw+8hWGsIQpbI19reO/fMp/83o8Tj8nnHCWE85X/5zo7qHrQtfLfPifE5tMM5fz3/5uVZJZhGFOG+Nx/YEkojRJX6n2rdz/AvNq5/pJi9qPAAAAAElFTkSuQmCC"
                                                                                                     alt=""></div>
                    <p data-v-d2cdda40="" class="mybalanci">My balance</p></div>
                <p data-v-d2cdda40="" class="lineu"></p>
                <div data-v-d2cdda40="" class="leftit">
                    <div data-v-d2cdda40="" class="numberanm"><p data-v-d2cdda40="">
                            <?php
                                $dailyIncome = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'daily_income')->sum('amount');
                                $commission = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'commission')->sum('amount');
                                $reword = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'reword')->sum('amount');
                            ?>
                            {{price($dailyIncome+$commission+$reword)}}
                        </p><img data-v-d2cdda40=""
                                                                                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGqADAAQAAAABAAAAGgAAAABMybYKAAADYElEQVRIDb2Wv2tTURTH89JUqM1gBknNUOpiQFGEIoq4RKlZSlPakLb/gIODFsR0q9hJAoJdOrn3tzSlSyw24CCKFERRrINIhzalQxxSCzZt/Hyf74U0fS82Fb3wuPeeH9/vPe+ce94zPH8YExMTZwzD6C6VSh2YtvKELJc15lV0i+jm+vv7v1hyx8lwlCKcmppq393dTbG87mZTJV9qaGhIJhKJ5Sq5uT1AlM1mfblc7gknvc1JmYxNLJ/xpBsbGz9Bvi5PQE8Vi8Vz2HSx7WE+iS1TaaylpWUwEokUZWePfUQLCwuBQqEwi3EEgy0cU4FA4HE0Gt2yHZzmTCbTnM/n7+GXRN+MX9bv9/d2dnbmbfsykSLZ2Nh4LhIMv/l8vlg8Hn9vGx5mnpmZuUCUaTDaRBYMBm/akXltAL0um6SpqelKvSTCkY98dVBhCdPGNyNS4vf29t6i/EEerh6FxAbUrMh2dnZeQXjc6/VeUoGYEam6IEFupP6WRETCEJYwrcr1GEQTZvMZxSaJP+2WeO7TUzCuYXerr6/vpQBrDXD9vKWvkKkaw14WMTkwz7qRSI/xGjZhnLOTk5OPADomudvgdRXQ6VrIt1tEuvHazGt2G0QxjE2C5ztkQzxvIDvrZi+5jSkO5UhtxaPLqLnWoM1MU1XnsVHbucgrXya6O6zL16TSnyvy0dq3isjsXTiZN77S0Gkdi8XWIIxSTXelJ7JRIlOrOjA4VM4ShsyqO2BRp8AtIrpMyYIqiUhd2OxdlrDmlE6nQ1RgRpHIkDwMkr/7Tk7qh5Z8XUSr2nDBaiZWNryi+Pb29geWHRC8A6id1zjK2j65zMpDTdfarHoxWrQ2ZpmXraoWJH2EPE7zmk7gkyJHlynhmgWErTq7ol4UUdrC7FEXrsIvb3EKYbsCQYQohiD5WVY6LCysHqnwnTPLcnx8/AX76wA9AGTEwa9uEXkchuAhjksDAwM3lCMVQhIS5KWkGmLdqFUOwhCWMIUttUmk7opijH2zvieMYJXvobfyFYawhClsOZtEWujzywmyKNuorNdHiUw+8hWGsIQpbI19reO/fMp/83o8Tj8nnHCWE85X/5zo7qHrQtfLfPifE5tMM5fz3/5uVZJZhGFOG+Nx/YEkojRJX6n2rdz/AvNq5/pJi9qPAAAAAElFTkSuQmCC"
                                                                                                    alt=""></div>
                    <p data-v-d2cdda40="" class="mybalanci">Total income</p></div>
            </div>
        </div>
        <section data-v-d2cdda40="" class="section-box" style="display:none">
            <div data-v-d2cdda40="" class="invitei">
                <div data-v-d2cdda40="" class="topi" onclick="window.location.href='{{route('user.invite')}}'"><p data-v-d2cdda40="" class="rewardsi">Invite rewards</p>
                    <p data-v-d2cdda40="" class="personi">Invite one person to successfully register and receive a
                        reward of <span data-v-d2cdda40="">{{price(setting('total_member_register_reword_amount'))}}</span></p><img data-v-d2cdda40=""
                                                                               src="{{asset('public')}}/NorthernStar/dist/img/4.1d68cd68.png"
                                                                               alt="">
                </div>
                <div data-v-d2cdda40="" class="peoplebox">
                    <div data-v-d2cdda40="" class="people"><span data-v-d2cdda40=""><strong
                                data-v-d2cdda40="">{{\App\Models\User::where('ref_by', auth()->user()->ref_id)->count()}}</strong>/{{setting('total_member_register_reword')}}</span>
                        <p data-v-d2cdda40="">Invite people(lv1)</p></div>
                    <div data-v-d2cdda40="" class="people"><span data-v-d2cdda40="">{{price(auth()->user()->reward)}}</span>
                        <p data-v-d2cdda40="">Cumulative rewards</p></div>
                    @if(\App\Models\User::where('ref_by', auth()->user()->ref_id)->count() >= setting('total_member_register_reword') && auth()->user()->reward_received == 'false')
                        <button data-v-d2cdda40="" class="notbnt" onclick="receivedReward(true)" style="background: #ffc402;">Receive</button>
                    @else
                        <button data-v-d2cdda40="" class="notbnt" onclick="receivedReward(false)">Receive</button>
                    @endif
                </div>
            </div>
            <div data-v-d2cdda40="" class="codebox">
                <div data-v-d2cdda40="" class="topcode flex">
                    <div data-v-d2cdda40="" class="invitel"><img data-v-d2cdda40=""
                                                                 src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAABBCAYAAACO98lFAAAAAXNSR0IArs4c6QAACChJREFUeF7tXHt8zWUY/z4/2WZLxpZFc0vKtbJ0oZSmXCZK6NMoQ58kmVqfQqpVLq0ICbWWyqVoKqqRjOkqKpJKKrFEdmnW2NaZ4ff0ed+f5Zzt/G5n5+zCef87O8/7vs/zfZ/7e94Ryg3O2XgpoI4GUzRYbQWiwPI0te4z81GQkgnijYCSQhHRO5xloLIPvHNFAMIbzQFjDACl1glqnWEVhGTk5SdQh9tLxTQJggQgLOwjgHtaX6u2U1IGDh2KEUBoIORsWADG2Noulm3+CS9RxI33k/QBrH53mpuAHj4qSImiM1YLymAR2sDZGbsAbmtblU6bCfQLcdb6ktMiDHp6KMxHibM3sKfzT5d5fhBEnuDXBB+AwAU5wI714N1fA3/vA46VAMGhQLN2oM59QW2uAuj/RLVGWJTXNIGPHQU2vg7+9kPgxHF94dp1B906ARQQVCMAkGmzN8yBC7LByxOB3Exrgp3fDjR0Gij4HGv0PqaqNAi8fxc4NREoLrDHalgz0J1JoNAIe/N8QF0pEPinT8EfzASOy2LM/qgfBhr2DCjiAvtzvTjDMxCYwV8sA3+ySJ+VphcBgSFA5nZjdgNDQHdMAbW8xIti2VvKIxA4/RXw5nd1d6LrhoF6xMkowJ+9Cf50sTFXdeqCbnsU1L67Pe69RG0bBP4+XTMBd0OpA7r5QVDnPi7f8pdvgzNeM2aZCNQ3HnRFfy+JZn0ZWyCwoxD84nCgpKjiDoHBoCFPglpHud2dN78HTk825cxZi0yJvURgD4RNqeANCytuHdIQdNdzoIhWhmzxNx+A1843ZV0mVTc/ACh1TGm9QWALBPW18cCBXRX2pV5jQF0HWeKHt60Br5kLsHHdRu2vBw2eDJDv2532QEgaAJQ6Kgrb+nIoQ6cbnhzn/wUKPU/SSL/y4SyAVUPg6KbRoG5DLIFbGSJ7IEztA6gn3O5HUf00FXZTF3DmdnDqU6A2V4MGTtCA+CED/P4MYyCCQkAJy0EB9Sojo+lceyDMiwPyD+qHxh7DQdff5RoZREIlhD1xTP6dOkafAmLnZ+CVSbrASvohTwDNOgCOQlDjlqYCeUJgD4R1LwNbVhqrsIj3naIlDW9ZqUWEcvbvAsQvm8DvTANU90UXdR8Kih4JdekkyMjRopMnchrzbKeA4sJD4Jfvkafidogwec8CUFgk+PO3DDNKAZSoJoVpqEJTdqx3b2ZXDQT1GSvX4q/eAQ2aDGp7jVeBsKUJ8nT3bAMve8ytCstE6fJ+kDXFe9ON0b+sN6h/gvQJ6sJ4IHuPexBuGCE1gL9bC06bLaMFxYwHdennNSBsgyCB2LYavHquKxPhLaCMTQGXFIPnjQAcR/R9R9fBEJ5f9CB4xdPAnq36tMOSQBd2AX+ZCs44laMI3yP9jxcaNB6BIIFIT4bIAssG9R0HuvIWqJ+/BRgUVtRzFOjaWLCjCLz8cWD/Tv0TDQmFkrAMqFMX6pJHgMzvXWiF1lFMfKWTKo9BgKpCTX0K+G2z5vXHLwE1bAJ1/ijg0H73qh0jaoMB4KJ88JuPAjl7jU2m9xjQ1YPAWbvBKTq3hG27gW6bDKrr+eW55yAIbSh1gN94SNqzkrgO7DgCnjnYvWDnCnPR1FlUoKISNRzNO0KJe17eGatvJAAHftYnb94RFDsNFBTikZ+oFAhSoCN54IXxUOIXg/P26Z+Y6BuMXQg6J1yGTP74JfA377tnunFLUNzzoOAGMiLw+hRz4SLbQ4mbCZwVYE5bjqLSIEggsnZruQAp4JT79JkQwo2YDapXXwMibTZ4+8eu9E3aaG234Aaa1uTsBS+daKl9R12HgHqNrh4Q5K7Hj2nefsZAYyZEk3X4DK3brKrgVUkypMoR2R40bDoo6GyXNfjvfeAlE4CifOO1lbNA8Yts9y29ognOnKmvjgMO/mrMrCi4YqdKry/a8+qKKUDpv6DYqbp1AucdAIsIUZhn7EyvuxN0Q5wtbfA6CLIwWvWsKROyVB40GVAU2ahlZlMPz/kHNSAO5+qvH9kOyt0vmu7vTOB1EIStqyKj/P1bU0ZknO/nvvLUm8xZvxv7ncAQKJN0HK7Oot4HQTizkiKwaMDkuc8XXE7h2liIBMrqkEmWkd8hgpKYbnU5SecTEKRX/ydLhk78e9iUIcvNE5GgiWLrxwz9NYPOhjJxlemevjUHp9X5z580r36yl2DEGQ14GNS5tz6JiCRps2RXynCIJGvknJoDgtQIi45SVoe3J7ovk60CIFT7ZNVpBwWfmYMzE+LyRVzCmA5xCSPyhFadT5HaAECEXHpgKah+mOlWVWYO/28kssOVIin6xJy5gHqg4TNB51+sJVNWTODkqmVdKPNNXCmqRBPklsdLoS5+xLgQKuMtMBjo1FOrMo1KbWdZmnXQageRgNkcVQeC8A/FBVrEKMi2yaYJecQFWsElahIPRpWCIB1l7h/g1x8EjhZ7wK6bKeHNQSNmgUJCPV6vykGQQOzZCl72uGGr3ZJEjZpqValNR1h+7WoBQQKxNQ28xl6O78J8gwjQyNmgBo0t4WVEVG0gSCDWJYO3nOpTWpamfrgGQMMmlqfUWBBEu53TXgBvX2tdmIZNtaZLo6bW55hQVqsmSN5EDrF1tfYjDiNnKVrr4q6i170Vmi6VRaP6QTgpgfgBCMRt9W9bgNy9gKMIqBsEhEcCraJkXSFutnwxagwIvhDO6pp+EHzZT7B6CjWBzq8JUhP8L1/Eyxf/Gyj/azj5Gs7/LjLK/0JWvJCVmav/rbQWqc/4V/POCcuZ+P8T/gMdWrq1AB4F/QAAAABJRU5ErkJggg=="
                                                                 alt="" class="imgi">
                        <div data-v-d2cdda40="" class="codete"><p data-v-d2cdda40="">Invite code</p><span
                                data-v-d2cdda40="">{{auth()->user()->ref_id}}</span></div>
                    </div>
                    <img onclick="copyLink('{{auth()->user()->ref_id}}')" data-v-d2cdda40="" src="{{asset('public')}}/NorthernStar/dist/img/copy.8f614e0d.png" alt="" class="copyimg"></div>
                <p data-v-d2cdda40="" class="line"></p>
                <div data-v-d2cdda40="" class="topcode flex">
                    <div data-v-d2cdda40="" class="invitel"><img data-v-d2cdda40=""
                                                                 src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAABBCAYAAACO98lFAAAAAXNSR0IArs4c6QAACChJREFUeF7tXHt8zWUY/z4/2WZLxpZFc0vKtbJ0oZSmXCZK6NMoQ58kmVqfQqpVLq0ICbWWyqVoKqqRjOkqKpJKKrFEdmnW2NaZ4ff0ed+f5Zzt/G5n5+zCef87O8/7vs/zfZ/7e94Ryg3O2XgpoI4GUzRYbQWiwPI0te4z81GQkgnijYCSQhHRO5xloLIPvHNFAMIbzQFjDACl1glqnWEVhGTk5SdQh9tLxTQJggQgLOwjgHtaX6u2U1IGDh2KEUBoIORsWADG2Noulm3+CS9RxI33k/QBrH53mpuAHj4qSImiM1YLymAR2sDZGbsAbmtblU6bCfQLcdb6ktMiDHp6KMxHibM3sKfzT5d5fhBEnuDXBB+AwAU5wI714N1fA3/vA46VAMGhQLN2oM59QW2uAuj/RLVGWJTXNIGPHQU2vg7+9kPgxHF94dp1B906ARQQVCMAkGmzN8yBC7LByxOB3Exrgp3fDjR0Gij4HGv0PqaqNAi8fxc4NREoLrDHalgz0J1JoNAIe/N8QF0pEPinT8EfzASOy2LM/qgfBhr2DCjiAvtzvTjDMxCYwV8sA3+ySJ+VphcBgSFA5nZjdgNDQHdMAbW8xIti2VvKIxA4/RXw5nd1d6LrhoF6xMkowJ+9Cf50sTFXdeqCbnsU1L67Pe69RG0bBP4+XTMBd0OpA7r5QVDnPi7f8pdvgzNeM2aZCNQ3HnRFfy+JZn0ZWyCwoxD84nCgpKjiDoHBoCFPglpHud2dN78HTk825cxZi0yJvURgD4RNqeANCytuHdIQdNdzoIhWhmzxNx+A1843ZV0mVTc/ACh1TGm9QWALBPW18cCBXRX2pV5jQF0HWeKHt60Br5kLsHHdRu2vBw2eDJDv2532QEgaAJQ6Kgrb+nIoQ6cbnhzn/wUKPU/SSL/y4SyAVUPg6KbRoG5DLIFbGSJ7IEztA6gn3O5HUf00FXZTF3DmdnDqU6A2V4MGTtCA+CED/P4MYyCCQkAJy0EB9Sojo+lceyDMiwPyD+qHxh7DQdff5RoZREIlhD1xTP6dOkafAmLnZ+CVSbrASvohTwDNOgCOQlDjlqYCeUJgD4R1LwNbVhqrsIj3naIlDW9ZqUWEcvbvAsQvm8DvTANU90UXdR8Kih4JdekkyMjRopMnchrzbKeA4sJD4Jfvkafidogwec8CUFgk+PO3DDNKAZSoJoVpqEJTdqx3b2ZXDQT1GSvX4q/eAQ2aDGp7jVeBsKUJ8nT3bAMve8ytCstE6fJ+kDXFe9ON0b+sN6h/gvQJ6sJ4IHuPexBuGCE1gL9bC06bLaMFxYwHdennNSBsgyCB2LYavHquKxPhLaCMTQGXFIPnjQAcR/R9R9fBEJ5f9CB4xdPAnq36tMOSQBd2AX+ZCs44laMI3yP9jxcaNB6BIIFIT4bIAssG9R0HuvIWqJ+/BRgUVtRzFOjaWLCjCLz8cWD/Tv0TDQmFkrAMqFMX6pJHgMzvXWiF1lFMfKWTKo9BgKpCTX0K+G2z5vXHLwE1bAJ1/ijg0H73qh0jaoMB4KJ88JuPAjl7jU2m9xjQ1YPAWbvBKTq3hG27gW6bDKrr+eW55yAIbSh1gN94SNqzkrgO7DgCnjnYvWDnCnPR1FlUoKISNRzNO0KJe17eGatvJAAHftYnb94RFDsNFBTikZ+oFAhSoCN54IXxUOIXg/P26Z+Y6BuMXQg6J1yGTP74JfA377tnunFLUNzzoOAGMiLw+hRz4SLbQ4mbCZwVYE5bjqLSIEggsnZruQAp4JT79JkQwo2YDapXXwMibTZ4+8eu9E3aaG234Aaa1uTsBS+daKl9R12HgHqNrh4Q5K7Hj2nefsZAYyZEk3X4DK3brKrgVUkypMoR2R40bDoo6GyXNfjvfeAlE4CifOO1lbNA8Yts9y29ognOnKmvjgMO/mrMrCi4YqdKry/a8+qKKUDpv6DYqbp1AucdAIsIUZhn7EyvuxN0Q5wtbfA6CLIwWvWsKROyVB40GVAU2ahlZlMPz/kHNSAO5+qvH9kOyt0vmu7vTOB1EIStqyKj/P1bU0ZknO/nvvLUm8xZvxv7ncAQKJN0HK7Oot4HQTizkiKwaMDkuc8XXE7h2liIBMrqkEmWkd8hgpKYbnU5SecTEKRX/ydLhk78e9iUIcvNE5GgiWLrxwz9NYPOhjJxlemevjUHp9X5z580r36yl2DEGQ14GNS5tz6JiCRps2RXynCIJGvknJoDgtQIi45SVoe3J7ovk60CIFT7ZNVpBwWfmYMzE+LyRVzCmA5xCSPyhFadT5HaAECEXHpgKah+mOlWVWYO/28kssOVIin6xJy5gHqg4TNB51+sJVNWTODkqmVdKPNNXCmqRBPklsdLoS5+xLgQKuMtMBjo1FOrMo1KbWdZmnXQageRgNkcVQeC8A/FBVrEKMi2yaYJecQFWsElahIPRpWCIB1l7h/g1x8EjhZ7wK6bKeHNQSNmgUJCPV6vykGQQOzZCl72uGGr3ZJEjZpqValNR1h+7WoBQQKxNQ28xl6O78J8gwjQyNmgBo0t4WVEVG0gSCDWJYO3nOpTWpamfrgGQMMmlqfUWBBEu53TXgBvX2tdmIZNtaZLo6bW55hQVqsmSN5EDrF1tfYjDiNnKVrr4q6i170Vmi6VRaP6QTgpgfgBCMRt9W9bgNy9gKMIqBsEhEcCraJkXSFutnwxagwIvhDO6pp+EHzZT7B6CjWBzq8JUhP8L1/Eyxf/Gyj/azj5Gs7/LjLK/0JWvJCVmav/rbQWqc/4V/POCcuZ+P8T/gMdWrq1AB4F/QAAAABJRU5ErkJggg=="
                                                                 alt="" class="imgi">
                        <div data-v-d2cdda40="" class="codete"><p data-v-d2cdda40="">Invite link</p><span
                                data-v-d2cdda40="" class="ellipsis-1">{{url('member/register').'?member='.auth()->user()->ref_id}}</span>
                        </div>
                    </div>
                    <img onclick="copyLink('{{url('member/register').'?member='.auth()->user()->ref_id}}')" data-v-d2cdda40="" src="{{asset('public')}}/NorthernStar/dist/img/copy.8f614e0d.png" alt="" class="copyimg"></div>
            </div>
            <div data-v-d2cdda40="" class="titlemis"><img data-v-d2cdda40=""
                                                          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAlCAYAAAAnQjt6AAAAAXNSR0IArs4c6QAAAcJJREFUWEftWL8vBEEYfW8TNEioKHQKiVYiZAkVDXqFQqPX8QfQ6TUSCj0aKsI6kWglEjqFq0iOwpHMk11u3e6R293LucnFlrPfjzfv+zEzH/HDp1NMwXHmQY1C7APQ9pNcirUiqHuIORizy3EcxXVZvqBjDKCFWwBHUjjJIKoLvGuRk7gpKYdAdIYJONyD2JnBcnoVqgCjOY7hxFcOgARMtPLyz0CENKiANw37zHwC8ZirDIcOIG2gG1ccxEv6LX9r6BrteMQQyGWAM1FbuqCrUX4l5mHM0Spds16L89905TkrANYi/42ZpjxnG8BCGf4DupqtB4iSTXncjzGzQ53zFmJ/6FhmspRA9QITFAad49A+decz8hrpE12mo9acqLaBIGeenOcyuaIPROWKdE2kt1QzmvV/hd9/IPFIVGNEHmYhboLsyRQGKQ9qiS72I8dJaiBnfMgMIqxX5Tmm3iYBYktoMuVFAqX/8o2T1ByMJO4pv/SOmso3opymp6iydzQhkKQ9pd6hSdAeEos0R9Uk3m4CQasZseTOatEt3pJ3zecIovEvPT/BrXj7BkBsmQYEYGyYj4SXbRsmRpEjugEztA800oBXrxN3EAAAAABJRU5ErkJggg=="
                                                          alt="">
                <p data-v-d2cdda40="">Mission Task</p></div>

            @foreach(\App\Models\Task::get() as $element)
                <?php
                $apply = \App\Models\TaskRequest::where('task_id', $element->id)->where('user_id', auth()->id())->where('status', '!=', 'rejected')->first();
                ?>
                <div data-v-d2cdda40="" class="invitelist">
                    <div data-v-d2cdda40="" class="personi"><img data-v-d2cdda40=""
                                                                 src="{{asset('public')}}/NorthernStar/dist/img/6.a5744651.png" alt="">
                        <p data-v-d2cdda40="">Invite {{$element->team_size}} people to recharge and get a reward of {{price($element->bonus)}} | Required Deposit Money of {{price($element->invest)}} </p></div>
                    <div data-v-d2cdda40="" class="invide flex"><p data-v-d2cdda40="">Deposit <span
                                data-v-d2cdda40="">{{price($teamDeposit)}}<strong data-v-d2cdda40="">/{{price($element->invest)}}</strong></span></p>
                        @if($apply)
                            <button data-v-d2cdda40="" class="canbtni">Received</button>
                        @else
                            <button data-v-d2cdda40="" class="canbtni" onclick="getDeposirreward('{{url('apply-for-task-commission'.'/'. $element->id)}}')">Get</button>
                        @endif
                    </div>
                </div>
            @endforeach

            <p data-v-d2cdda40="" class="northrn">© {{env('APP_NAME')}} Resources Limited.</p></section>
        <div data-v-d2cdda40="" class="servioni">
            <div data-v-d2cdda40="" class="seruiimg" onclick="window.location.href='{{route('user.service')}}'"><img data-v-d2cdda40="" src="{{asset('public')}}/NorthernStar/dist/img/2.9f09af36.png"
                                                          alt="" class=""></div>
            <div data-v-d2cdda40="" class="bubble animate__animated" style="display: none;">
                <div data-v-d2cdda40="" class="listiuy"><img data-v-d2cdda40=""
                                                             src="{{asset('public')}}/NorthernStar/dist/img/3.89b72830.png" alt=""></div>
                <div data-v-d2cdda40="" class="listiuy"><img data-v-d2cdda40=""
                                                             src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAADexJREFUeF7tXWl0FFUW/l5VJ52E7CEJSyBbJxAWdVC2GRhGRRhmEFEIKMsICAmIIMoSF+TMAcFElnFEBRQjI6CQgDKKI4dlVIijbAoGSIDOAgQIBMhGlu501ZvzOiQHQne6ulPVS+j61ef0fXf7qt5y3333Ecj0RJ2c1E7FqwdQkfYmhCSAIhoC7Ugo/ECgkkmMY9lQGChBJXhyEQQFlNIcwpHDBkGXVdh9Q7EcypGWMInVTg+DgImcQBOpQB8iAN8Sfq7algIC4ckRkSeZ4LExT7P2qq222ARITM60eJ7yKaDiOIjwslV4q2zHoRaE+0wgQlp+wkdnrLXRKkCiCuYEeuhrFsNAkyHC01ph9xQ9Bz1UZF2dp25RYfSGMqm2SwYk9vSMYZxBWA8RHaQyd9MB4HBJVPFT87qs+VaKPywDkpHIa3oGL4FAUwgFJ4Wpm+ZOD1ACETxJ02bfeANjMoXm/NMsIBo6S01ydZthwCi3k2XwAIfttJt6vJas1pnjZhYQBgZy9TuIgf5ZBlXcLG55gKrILqg8R2rjTINiGpCMRD6uZ9BW95eh0HvEYfvZk6VjTXVfJgHR5CQvIwb6qkLquNkCoCryljZh3WtNnXEXIGw2ReqEne4BXNn3hg301IMf3nT2dQcgUQWTAj2qPU+6p7bKgtHIncOlOh9999vXKXcAEpeT/C4MdJad1HGLYR5QkdVnE9bNbnBGIyAxeclxfA09CQoPt6fs6AGCOsGbdM+PXXeWSW0ERHMyKZ2ImGxHVdyiGqbCPNK13T58rhGQ6Oyp4SqOK3QHCh30jnCoFdVcJIsSG7+Q2NPT53J6cYWD1HGLBSCquHl5CWtXGgGJO5X0MwT0dXvGgR7gcfBstw/7EeNOn+hZdK9uLjkQgjtEs00ug68+gmhyk0eTOprpLIpJ1aMN54VQVQACeR94kvqJoZ7WoUyoRomhHFVirVRWzkOn5kaT2FNJaZyABc6j1d2a+HJe6N+mKx5so0EP70jEqTsgkG8DQkyH4iilKBOqcFZ3CSdqzuFolRY/VeXippODJPJ4m2hykr8iBvq4swHiTTwxLOAhDA/ojX6+XaAiLduuN1ABP988jZ3lh/Ft+RHUUL2zmcziW18TzankbCLQHs6iXbgqEJPaDsaYoAHw470VUatSqEFmaRY+ubYXVwySd1cV0eV2ppQnJ4gmO+kGAYIUl2ZBgB/njZmhf8X4kD9BzdknWKAT67D5+vd4v+QbVIo1jnYBKFBK4n5LqnN03hTrll5vNwYhHv4Occr1ugosLc4wdmcOfSgMJC47iTpKCR9OjcUdJmBEYB9HqXCH3K/LDuGNS5tQLZrdYVVcT4cBolG3x/udpyNa3U5xI60RUKC7gpnn10Kru2RNM9loHQLIgz6xWBs5EwF8G9kMkZNRuVCN6efex9FqrZxsJfGyOyCDfHtgdedkeHHOnWdXK+ox6/w6/HDzhCRHykVkV0DYl/FJ1BynB6PBuQyUyYXv4Gh1nlz+tsjHboCwMePzmPlO202Z8xTrvp7JX263McUugLDZ1JexrzndAG7xdb1FUKArxpN5y+wy+7ILICsipmBEoGtH978qO4h5RelSMbSZTnFA2KJvVaepNivoTA1fvrBe8cWjooCwcMjuuMVWr8DZwqzUcBNexANBKj9wZqK69gaLreiHnF2kaJhFUUBSwkfhudAhkv2WU3MBSy9vxZFqLUQW2QHQwysSW2IWwJNzjlNx6SV7kHplm2SbrCVUDBAWtd0b/6bkQOHJmvOYWLDS5J7F0g4TkRg8wFrbFKFnAcnBZxYqFiVWDJCUdqPxXNvHJDmlQqjG49rFuFxXapK+u1dnfKl5XRIvexB9fG0P0oqV+UoUAYRtLmV1fVvyfsayyxnYcH1fs77MjEnB/T4x9vC3RRlsP2VA7gJFNrkUAeSpwP5IjZhk0TBGUC3o0D93nkXjRgb2w9sRzpPH90rRBnxR9pMkG60hUgSQ9MgXMcCvmyQ9dpf/ihcurLVIqyYq7O+ShiCVr0VaexBkVZ7ClHP/lF2U7ICwhISDCavgIXEPfFXxDqy9Juk8JOaHP4VpoUNld4ItDNkefZ+cl2VPnJAdkMF+D+CDyBmSbXyt6FNsK/tREn2ERwj2xL8JnjjH2dPnz63B3spjknSXSiQ7IK+0G40pEmdXTMn5F9Lx7/KDUvXFlugF6NUmVjK9koTp1/YgVebZluyAbIyei75t4iX7IfVyJtKv75VE70lU2Be/FOEegZLolSY6VHUGEwpWyipGdkAOdl1p1cC7s+wwXi5aL8mov7cfh3EhgyTR2oOIhXf65s6VVZSsgLD0zl8S3jGbUWhK85K6cgw8ndIYKjFn3YzQv+Cl8CdkNb6lzFiGZK+cObKmrcoKSJRnOHbHL7bazskF7+DHqhyz7Yb698K7nZKsAtpqJWxsMOTMIhTqr9jY+u5msgLygHc0MmJfsVq57yuykXT+PbPtlkdMwRNOup8yJi8Vx2oKrLbZXANZAenjE49NMdb3qezTT8xPxW81hSb1vM87CltjUpxmunu7khPyV+JQtdVVmMwCKCsgvX3isDlmnk1vyy9VeXimYDnorbB7UybWBCttUsDGRk4NCNu7+EJzV3ECyaYuubQFG298Z5KeTXkzYlLQzbuzZH72IEzMS8VxZ+2ybB3UGxzH0m6eylsGre6ySV928miLbbGvWjWtVhoUpx7UvYgnjnd7t0WzodyaIiTmvwUdNZj0Za9buV3eTpBoVz/tfRFVMuYCyzqGMA/+3HUFglV+LXoxt944YEx6Nvew01RrIp8HSy9y5OP0C0PmnH9FvYT+vl1b7KdFFzdhS+kBs3x6ekUaQQmTEEapEfVYeHEjzutLMNT/dxgb/EfJm2fNGXKw6oxx21nOR/YvZEH4KEy1IrHBnDEsvD2tcHWzC0Z26JPlfFl6ARYWbURGWVajKF/OG+ODB2FS20cRorL9TIpLBBcf8bvPmNkux1Ml1GJiwSqcqD1nft4OYnTunPAn4M/73EW3q/woZl/40GR7NuY9HTwQU9sOkfSlNWXiEuF31q8f6rpKtrSdMkMVni38B3JqLzSLcRDvi6S2Q43dkS9fX0o4r/ayccFp6fStmngYzzTOChuOQIk7knVUQF9X2KBijvg4cjYG+nWX4yMx8igXqjC1cLWk+T7bsRzm/6BxYrGt9EdcFyol6zEmaCDe7DhBEr3LbOEya0YE9MGKTsbiNrI9bGBmqZz7Ko/LxrMpoycD+yNNYnKGSyU5sDSgA13TTPbpLfGmSEWsvroTH5T8x2yIpSX8Z4c9jhfChltk4XJpQMyieeFPIilUmQqz/7uZA/aGFst8xvzTqJfQT8KU3eUS5RggbEr63/ilklNJLb6WTQhuCjVYdWUHPr+xHwJEa5vfRd9eFYR9XZZarBhRK9bhMVdMJWUWzw0fieTQYS12VnMM8mqL8d7Vr7Gr4hebgeHBGafqg/wsF7T4uGQ30q5sV8wm2ReGt2vKZjy745agrR0KAhTpr2HLjf3GbMJrhgrJDmNHJpZHTMYj/vdbbOPyxxGYhWz7lZ26tdfDVvhZN0/hm7LD+K4yGxVitUnRHkSFkQF98WL4CMmLQpc/sNPgiTWdZ+BR/wfshUmjHAZOds05HKvOBysIUC3WGss6sRJPg/x6WhXGbzVH2ph3NkXPRR8rcrXsjpwFga3q0CebbR3okgrOSdI/rQWbRQnqj0Wb3jSzlp8lekUHdSZ8QvDDWNThaUt6OOX/rbJwwOboeejdJs4pHd6cUq2ytEaYKgD7XbC7qi8+855dS2o0vByKdll/C34YC12su2IDeH15JvuMGU2/UkUB+Tx6vrGSqKs8X5UdwiKHFzBTqMQfOxb9g7G7Mn/v2DndVeyp+BUX9NcwM2w4wjwCHIKdU5X4U6oI5rMhj+D19mPvcDBLmzmtuwh2rpABwX43PCzMwjLcJ4Q8DHul+DhlEUylysQ2nHQSKcXxmvxbIBzD+bqSZr8Ctm6ZHDIYiUF/QIBKmYpzbD8jozQLG5yyTKwChZRDeX+kRUw2nr/bW3EMVw3lVndFbJOLxcGGB/bG730TLIbFLQlwmULKrlBqnB0EYsfkWDI3y+3t4tURLKmhdZYad9Fi/CyFp51HIFj4nNVvJCCtoxi/+7oKS52dff5vvK6CiXNf6GIfpzcrpeFCF0bkvvLI8YDcceWR+1IwBwPS9FIwpo772jzHgUKbXpvHVHFfLOkgQMxdLGkc3N1Xr9ofFXNXrzJN3JcT2xkPS5cT18+43Nd32wMWSdd3NyjivuBeeUgkX3BvVCUjkY/rGbQVBoxSXrV7UAKH7WdPlo7FmEyhqfVmd480dJYaufodxECVSWG/B3FgJlMV2QWV50ht3GqT9yqZ385jaxM6S01O6TZDdH8psrw/HLbTburxWmIaDCajWUAaui9Nz+AlEGgKoXCOYoeyeMd+TNgADp6kabNvvGGqm7pdE8uA3KJmsy/OIKyHiA72M6UVSOJwSVTxU/O6rJFUelUyII3rFL16MQw0GSKc+xIpR2PJQQ8VWVfnqVtUGL1B8nWiVgHSYGNMzrR4nvIpoOI4iKg/g+x+6j3AoRaE+0wgQlp+wkdWF9KyCZAG38dqp4dBwEROoIlUoA/dq3eys80lwpMjIk8ywWNjnmbtVVvfzxYBcrtQ484jrx5ARdqbEJIAimgItCOh8HP01a62OueudhQGSlAJnlwEQQGlNIdw5LBB0GUVdt9QLIec/wPp3tXifnQrXQAAAABJRU5ErkJggg=="
                                                             alt=""></div>
                <div data-v-d2cdda40="" class="listiuy lstit"><img data-v-d2cdda40=""
                                                                   src="{{asset('public')}}/NorthernStar/dist/img/1.56c1d544.png" alt=""
                                                                   class=""></div>
            </div>
        </div>
        <div class="van-overlay checkinOverLay" style="z-index: 2010; display: none;" onclick="closeCheckIn()"></div>
        <div data-v-d2cdda40="" class="sterboxi van-popup van-popup--center checkinOverBlock" style="z-index: 2011; display: none;">
            <p data-v-d2cdda40="" class="succi">Check in successfully</p>
            <p data-v-d2cdda40="" class="earni">Receive rewards</p>
            <p data-v-d2cdda40="" class="amounti">1-500$</p>
            <div>
                <input type="text" name="code" id="code" style="padding: 5px;text-align: center;" placeholder="Enter gift code">
            </div>
            <button data-v-d2cdda40="" onclick="checkin()">Confirm</button>
        </div>

        @include('app.layout.manu')
    </div>
</div>

<div class="loader" style="
    position: fixed;
    display: none;
    top: 50%;
    z-index: 99;
    width: 143px;
    border-radius: 15px;
    overflow: hidden;
    left: 50%;
    transform: translate(-50%, -50%);
">
    <img src="{{asset('public/loader.webp')}}" style="width: 100%;" alt="">
</div>

@include('alert-message')
<script>
    function copyLink(text)
    {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();
        message('Copied success..')
    }


    function receivedReward(condition){
        if (condition == true){
            window.location.href='{{route('user.received.reward')}}';
        }else {
            message('Target not eligible.')
        }
    }

    function closeCheckIn(){
        var checkinOverLay = document.querySelector('.checkinOverLay');
        var checkinOverBlock = document.querySelector('.checkinOverBlock');

        checkinOverLay.style.display = 'none';
        checkinOverBlock.style.display = 'none';
    }

    function openCheckIn(){
        var checkinOverLay = document.querySelector('.checkinOverLay');
        var checkinOverBlock = document.querySelector('.checkinOverBlock');

        checkinOverLay.style.display = 'block';
        checkinOverBlock.style.display = 'block';
    }

    function checkin(){
        closeCheckIn()
        var code = document.querySelector('input[name="code"]').value;
        window.location.href='{{url('submit-bonus-amount')}}'+"/"+code
    }


    function getDeposirreward(url){
        document.querySelector('.loader').style.display='block';
        window.location.href=url
    }
</script>
</body>
</html>
