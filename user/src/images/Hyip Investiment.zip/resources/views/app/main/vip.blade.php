<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-3cade526.7c0d8bb4.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-25561eec.1bdf73df.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-57221a82.4c1adb14.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-7501b02e="" class="productpage">
        <div data-v-7501b02e="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__title van-ellipsis">PRODUCTION</div>
                <div class="van-nav-bar__right"><img onclick="window.location.href='{{route('purchase.history')}}'" data-v-7501b02e="" src="{{asset('public')}}/NorthernStar/dist/img/1.69b62ac2.png"
                                                     alt=""></div>
            </div>
        </div>
        <section data-v-7501b02e="" class="section-box">
            @foreach(\App\Models\Package::where('status', 'active')->get() as $element)
            <div data-v-7501b02e="" class="listpro">
                <div data-v-7501b02e="" class="topcent">
                    <div data-v-7501b02e="" class="topi"><p data-v-7501b02e="" class="namei">{{$element->name}}</p>
                        <div data-v-7501b02e="" class="pricei flex"><p data-v-7501b02e="">Price：<span
                                    data-v-7501b02e="">{{price($element->price)}}</span></p><img data-v-7501b02e=""
                                                                              src="{{asset('public')}}/NorthernStar/icon/1.png"
                                                                              alt="" class="imgti"></div>
                        <img data-v-7501b02e=""
                             src="{{asset($element->photo)}}" alt=""
                             class="imgpro"></div>
                    <div data-v-7501b02e="" class="dailyings">
                        <div data-v-7501b02e="" class="ingsi firstis"><span data-v-7501b02e="">Daily earnings</span>
                            <p data-v-7501b02e="">{{price($element->commission_with_avg_amount / $element->validity)}}</p></div>
                        <div data-v-7501b02e="" class="ingsi"><span data-v-7501b02e="">Resources income</span>
                            <p data-v-7501b02e="">{{price($element->commission_with_avg_amount)}}</p></div>
                    </div>
                </div>
                <p data-v-7501b02e="" class="limiti">
                    Purchase Validity: <span data-v-7501b02e="">{{$element->validity}} days</span>
                </p>
                <img onclick="window.location.href='{{route('vip.details', $element->id)}}'"  data-v-7501b02e="" src="{{asset('public')}}/NorthernStar/icon/2.png" alt="" class="imgri">
            </div>
            @endforeach
            </section>
        @include('app.layout.manu')
    </div>
</div>

</body>
</html>
