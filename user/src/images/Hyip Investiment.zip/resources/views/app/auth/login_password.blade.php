<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">

    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-3331434e.15a7aec2.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-7de49710="" class="passwordpage">
        <div data-v-7de49710="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left"><i class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Security center</div>
            </div>
        </div>
        <section data-v-7de49710="" class="section-box">
            <div data-v-7de49710="" class="tabs-box van-tabs van-tabs--line">
                <div class="van-tabs__wrap">
                    <div role="tablist" class="van-tabs__nav van-tabs__nav--line">
                        <div role="tab" class="van-tab"
                             onclick="window.location.href='{{route('user.change.password')}}'"><span
                                class="van-tab__text van-tab__text--ellipsis">Transaction password</span>
                        </div>
                        <div role="tab" class="van-tab van-tab--active" aria-selected="true"><span
                                class="van-tab__text van-tab__text--ellipsis">Login password</span></div>
                        <div class="van-tabs__line"
                             style="transform: translateX(249px) translateX(-50%); transition-duration: 0.3s;"></div>
                    </div>
                </div>
                <div class="van-tabs__content">
                    <form action="{{route('user.change.password.confirmation')}}" method="post">
                        @csrf
                        <div data-v-7de49710="" role="tabpanel" class="van-tab__pane" style=""><p data-v-7de49710=""
                                                                                                  class="mobilei">Old login
                                Password</p>
                            <div data-v-7de49710="" class="input-box van-cell van-field">
                                <div class="van-cell__value van-cell__value--alone van-field__value">
                                    <div class="van-field__body"><input type="password"
                                                                        placeholder="Please enter old password"
                                                                        name="old_password"
                                                                        class="van-field__control">
                                        <div class="van-field__right-icon"><img data-v-7de49710=""
                                                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAbCAYAAAD/G5bjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAJ6ADAAQAAAABAAAAGwAAAABa5ZcvAAADAElEQVRYCe2VTUhUURTHfTMxYAgaCkXYQnCVmyiIIgj6oF3RygghoslxZhMYtKkIIUmj6JOYEXVZkRVCy6AWQWVBqygoCoJECppCkBbCOP3+t3eGyzgzOVjjIh+cOeeer///nnvfm7q65Wd5AkswgXw+HxkaGtqIrFwC+AKk8MVDfOR0PzhG5ubmXuF8aYFCRY0M4QpfPMSnQA5jqxYEO4aHh9tl1/oRrvBDXMfHTQ7HRyNDwnqza6mLcB0fRy4IgvcekV2eXTMTcrs9sHeyjdw9C3DmcUa82ta10MKD3BHDikQi92U7colE4hnTexEG63O53DVLrIUO8eqFJR7iI9uRk8EzTiAvg110ptPpU7L/9SMc4QknxB83zEBGJpM5gLpJUtQCoT6XTCZPG+mi2KKWYAXg9tPkpN8IrBzrLnDvBJz3Tsb6sAQxq3kQi8VS8Xh8yhyL1aOjo2tnZ2fT9NlXqpcIRqPRPWJ/C2IHLSlk/hTfdvOhZ/D3I9d7enp+ev6qTP0DUHCMl05XpsGK6fsEe5s/IHy3defeeklupBDYQfAi4u4g8QYKB5EpNnODaW/CdlfCastp5SlfdaqH2ID6KV/9hSM8ll3YwncPuW+CsbGxWDabPUGgg1GOdHd3P7YEmm7hyNMkbjCfp39Q8xzRX84Xar8Rm0YaqWnhc7CGus2IvvarvDpnUveVmv3gTVgsvGJHRay5ufnCH3fPUfQCfska/E3NBnqZ2pVyPSuSg1gLu/iANHoNJth1K75Wz1fRJH+S/EfoLPq4JbOeRtohqKnPe/zv3LwgjTqRAjE1Y7d7ec3XkdzGsRxCn8WfQfwXZUb+MN6m/FQqdZicAfUwIPUWhq2L9Ypih7+GyHfuT8FF4z7bJWCfCEjcw8c0aTa6gfgZb+1M1XIafRC6bDFhmF2sK06uqanpLgWDkHqNnOdv5Wpxg2rX6qFe6qneIUbJNhXvXMmKMk4+FZ+ZiLuHAE+GR18me2HuipNbWIvfWRxPQqQksqupXc79rybwCyR7Y+KXnDpPAAAAAElFTkSuQmCC"
                                                                                alt="" class="eyeimg"></div>
                                    </div>
                                </div>
                            </div>
                            <p data-v-7de49710="" class="mobilei">New login Password</p>
                            <div data-v-7de49710="" class="input-box van-cell van-field">
                                <div class="van-cell__value van-cell__value--alone van-field__value">
                                    <div class="van-field__body"><input type="password"
                                                                        placeholder="Please enter new password"
                                                                        name="new_password"
                                                                        class="van-field__control">
                                        <div class="van-field__right-icon"><img data-v-7de49710=""
                                                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAbCAYAAAD/G5bjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAJ6ADAAQAAAABAAAAGwAAAABa5ZcvAAADAElEQVRYCe2VTUhUURTHfTMxYAgaCkXYQnCVmyiIIgj6oF3RygghoslxZhMYtKkIIUmj6JOYEXVZkRVCy6AWQWVBqygoCoJECppCkBbCOP3+t3eGyzgzOVjjIh+cOeeer///nnvfm7q65Wd5AkswgXw+HxkaGtqIrFwC+AKk8MVDfOR0PzhG5ubmXuF8aYFCRY0M4QpfPMSnQA5jqxYEO4aHh9tl1/oRrvBDXMfHTQ7HRyNDwnqza6mLcB0fRy4IgvcekV2eXTMTcrs9sHeyjdw9C3DmcUa82ta10MKD3BHDikQi92U7colE4hnTexEG63O53DVLrIUO8eqFJR7iI9uRk8EzTiAvg110ptPpU7L/9SMc4QknxB83zEBGJpM5gLpJUtQCoT6XTCZPG+mi2KKWYAXg9tPkpN8IrBzrLnDvBJz3Tsb6sAQxq3kQi8VS8Xh8yhyL1aOjo2tnZ2fT9NlXqpcIRqPRPWJ/C2IHLSlk/hTfdvOhZ/D3I9d7enp+ev6qTP0DUHCMl05XpsGK6fsEe5s/IHy3defeeklupBDYQfAi4u4g8QYKB5EpNnODaW/CdlfCastp5SlfdaqH2ID6KV/9hSM8ll3YwncPuW+CsbGxWDabPUGgg1GOdHd3P7YEmm7hyNMkbjCfp39Q8xzRX84Xar8Rm0YaqWnhc7CGus2IvvarvDpnUveVmv3gTVgsvGJHRay5ufnCH3fPUfQCfska/E3NBnqZ2pVyPSuSg1gLu/iANHoNJth1K75Wz1fRJH+S/EfoLPq4JbOeRtohqKnPe/zv3LwgjTqRAjE1Y7d7ec3XkdzGsRxCn8WfQfwXZUb+MN6m/FQqdZicAfUwIPUWhq2L9Ypih7+GyHfuT8FF4z7bJWCfCEjcw8c0aTa6gfgZb+1M1XIafRC6bDFhmF2sK06uqanpLgWDkHqNnOdv5Wpxg2rX6qFe6qneIUbJNhXvXMmKMk4+FZ+ZiLuHAE+GR18me2HuipNbWIvfWRxPQqQksqupXc79rybwCyR7Y+KXnDpPAAAAAElFTkSuQmCC"
                                                                                alt="" class="eyeimg"></div>
                                    </div>
                                </div>
                            </div>
                            <p data-v-7de49710="" class="mobilei">Confirm login Password</p>
                            <div data-v-7de49710="" class="input-box van-cell van-field">
                                <div class="van-cell__value van-cell__value--alone van-field__value">
                                    <div class="van-field__body"><input type="password" placeholder="Confirm login password"
                                                                        name="confirm_password"
                                                                        class="van-field__control">
                                        <div class="van-field__right-icon"><img data-v-7de49710=""
                                                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAbCAYAAAD/G5bjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAJ6ADAAQAAAABAAAAGwAAAABa5ZcvAAADAElEQVRYCe2VTUhUURTHfTMxYAgaCkXYQnCVmyiIIgj6oF3RygghoslxZhMYtKkIIUmj6JOYEXVZkRVCy6AWQWVBqygoCoJECppCkBbCOP3+t3eGyzgzOVjjIh+cOeeer///nnvfm7q65Wd5AkswgXw+HxkaGtqIrFwC+AKk8MVDfOR0PzhG5ubmXuF8aYFCRY0M4QpfPMSnQA5jqxYEO4aHh9tl1/oRrvBDXMfHTQ7HRyNDwnqza6mLcB0fRy4IgvcekV2eXTMTcrs9sHeyjdw9C3DmcUa82ta10MKD3BHDikQi92U7colE4hnTexEG63O53DVLrIUO8eqFJR7iI9uRk8EzTiAvg110ptPpU7L/9SMc4QknxB83zEBGJpM5gLpJUtQCoT6XTCZPG+mi2KKWYAXg9tPkpN8IrBzrLnDvBJz3Tsb6sAQxq3kQi8VS8Xh8yhyL1aOjo2tnZ2fT9NlXqpcIRqPRPWJ/C2IHLSlk/hTfdvOhZ/D3I9d7enp+ev6qTP0DUHCMl05XpsGK6fsEe5s/IHy3defeeklupBDYQfAi4u4g8QYKB5EpNnODaW/CdlfCastp5SlfdaqH2ID6KV/9hSM8ll3YwncPuW+CsbGxWDabPUGgg1GOdHd3P7YEmm7hyNMkbjCfp39Q8xzRX84Xar8Rm0YaqWnhc7CGus2IvvarvDpnUveVmv3gTVgsvGJHRay5ufnCH3fPUfQCfska/E3NBnqZ2pVyPSuSg1gLu/iANHoNJth1K75Wz1fRJH+S/EfoLPq4JbOeRtohqKnPe/zv3LwgjTqRAjE1Y7d7ec3XkdzGsRxCn8WfQfwXZUb+MN6m/FQqdZicAfUwIPUWhq2L9Ypih7+GyHfuT8FF4z7bJWCfCEjcw8c0aTa6gfgZb+1M1XIafRC6bDFhmF2sK06uqanpLgWDkHqNnOdv5Wpxg2rX6qFe6qneIUbJNhXvXMmKMk4+FZ+ZiLuHAE+GR18me2HuipNbWIvfWRxPQqQksqupXc79rybwCyR7Y+KXnDpPAAAAAElFTkSuQmCC"
                                                                                alt="" class="eyeimg"></div>
                                    </div>
                                </div>
                            </div>
                            <button data-v-7de49710="" class="btncon">Confirm</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
@include('alert-message')
</body>
</html>
