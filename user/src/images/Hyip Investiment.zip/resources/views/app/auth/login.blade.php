<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="{{asset('public')}}/NorthernStar/favicon.ico">
    <title>{{env('APP_NAME')}}</title>
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="{{asset('public')}}/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="{{asset('public')}}/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css">
</head>

<body class="">

<div id="app">
    <form action="{{url('login')}}" method="post">
        @csrf
        <div id="nava"></div>
        <div data-v-e3ac078c="" class="loginpage">
            <div data-v-e3ac078c="" class="nav-top"><img data-v-e3ac078c=""
                                                         src="{{asset('public')}}/NorthernStar/dist/img/1.73c4a74e.png"
                                                         alt="" class="imgtop">
                <p data-v-e3ac078c="" class="northern">LOGIN </p>
                <p data-v-e3ac078c="" class="joinus">Join us to manage your investments and create superior returns
                    together</p></div>
            <div data-v-e3ac078c="" class="tabs-box van-tabs van-tabs--line">
                <div class="van-tabs__wrap">
                    <div role="tablist" class="van-tabs__nav van-tabs__nav--line">
                        <div role="tab" aria-selected="true" class="van-tab van-tab--active" onclick="window.location.href='{{url('login')}}'"><span
                                class="van-tab__text van-tab__text--ellipsis">Login</span></div>
                        <div role="tab" class="van-tab" onclick="window.location.href='{{url('member/register')}}'"><span
                                class="van-tab__text van-tab__text--ellipsis">Register</span>
                        </div>
                        <div class="van-tabs__line" style="transform: translateX(105px) translateX(-50%);"></div>
                    </div>
                </div>
                <div class="van-tabs__content">
                    <div data-v-e3ac078c="" role="tabpanel" class="van-tab__pane" style=""><p data-v-e3ac078c=""
                                                                                              class="mobilei">Mobile
                            phone
                            number</p>
                        <div data-v-e3ac078c="" class="input-box van-cell van-field">
                            <div class="van-field__left-icon">
                                <div data-v-e3ac078c="" class="phonen"><p data-v-e3ac078c="">+1</p><span
                                        data-v-e3ac078c=""></span></div>
                            </div>
                            <div class="van-cell__value van-cell__value--alone van-field__value">
                                <div class="van-field__body"><input type="tel" inputmode="numeric"
                                                                    name="phone"
                                                                    placeholder="Fill in mobile number"
                                                                    class="van-field__control"></div>
                            </div>
                        </div>
                        <p data-v-e3ac078c="" class="mobilei">Secure password</p>
                        <div data-v-e3ac078c="" class="input-box van-cell van-field">
                            <div class="van-cell__value van-cell__value--alone van-field__value">
                                <div class="van-field__body"><input type="password" placeholder="Fill in the password"
                                                                    name="password"
                                                                    class="van-field__control">
                                    <div class="van-field__right-icon"><img data-v-e3ac078c=""
                                                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAbCAYAAAD/G5bjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAJ6ADAAQAAAABAAAAGwAAAABa5ZcvAAADAElEQVRYCe2VTUhUURTHfTMxYAgaCkXYQnCVmyiIIgj6oF3RygghoslxZhMYtKkIIUmj6JOYEXVZkRVCy6AWQWVBqygoCoJECppCkBbCOP3+t3eGyzgzOVjjIh+cOeeer///nnvfm7q65Wd5AkswgXw+HxkaGtqIrFwC+AKk8MVDfOR0PzhG5ubmXuF8aYFCRY0M4QpfPMSnQA5jqxYEO4aHh9tl1/oRrvBDXMfHTQ7HRyNDwnqza6mLcB0fRy4IgvcekV2eXTMTcrs9sHeyjdw9C3DmcUa82ta10MKD3BHDikQi92U7colE4hnTexEG63O53DVLrIUO8eqFJR7iI9uRk8EzTiAvg110ptPpU7L/9SMc4QknxB83zEBGJpM5gLpJUtQCoT6XTCZPG+mi2KKWYAXg9tPkpN8IrBzrLnDvBJz3Tsb6sAQxq3kQi8VS8Xh8yhyL1aOjo2tnZ2fT9NlXqpcIRqPRPWJ/C2IHLSlk/hTfdvOhZ/D3I9d7enp+ev6qTP0DUHCMl05XpsGK6fsEe5s/IHy3defeeklupBDYQfAi4u4g8QYKB5EpNnODaW/CdlfCastp5SlfdaqH2ID6KV/9hSM8ll3YwncPuW+CsbGxWDabPUGgg1GOdHd3P7YEmm7hyNMkbjCfp39Q8xzRX84Xar8Rm0YaqWnhc7CGus2IvvarvDpnUveVmv3gTVgsvGJHRay5ufnCH3fPUfQCfska/E3NBnqZ2pVyPSuSg1gLu/iANHoNJth1K75Wz1fRJH+S/EfoLPq4JbOeRtohqKnPe/zv3LwgjTqRAjE1Y7d7ec3XkdzGsRxCn8WfQfwXZUb+MN6m/FQqdZicAfUwIPUWhq2L9Ypih7+GyHfuT8FF4z7bJWCfCEjcw8c0aTa6gfgZb+1M1XIafRC6bDFhmF2sK06uqanpLgWDkHqNnOdv5Wpxg2rX6qFe6qneIUbJNhXvXMmKMk4+FZ+ZiLuHAE+GR18me2HuipNbWIvfWRxPQqQksqupXc79rybwCyR7Y+KXnDpPAAAAAElFTkSuQmCC"
                                                                            alt="" class="eyeimg"></div>
                                </div>
                            </div>
                        </div>
                        <button data-v-e3ac078c="" class="btnlogin" type="button" onclick="login()">Login us</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="loader" style="
    position: fixed;
    display: none;
    top: 50%;
    z-index: 99;
    width: 143px;
    border-radius: 15px;
    overflow: hidden;
    left: 50%;
    transform: translate(-50%, -50%);
">
        <img src="{{asset('public/loader.webp')}}" style="width: 100%;" alt="">
    </div>
</div>
@include('alert-message')
<script>
    function login(){
        document.querySelector('.loader').style.display='block';
        document.querySelector('form').submit();
    }
</script>
</body>
</html>
