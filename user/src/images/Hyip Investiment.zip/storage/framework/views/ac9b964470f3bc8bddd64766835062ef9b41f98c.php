<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="<?php echo e(asset('public')); ?>/NorthernStar/favicon.ico">
    <title><?php echo e(env('APP_NAME')); ?></title>
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-3cade526.7c0d8bb4.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-25561eec.1bdf73df.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-57221a82.4c1adb14.css">
</head>

<body class="">
    <div id="app">
        <div id="nava"></div>
        <div data-v-7501b02e="" class="productpage">
            <div data-v-7501b02e="" class="navboxi van-nav-bar van-hairline--bottom">
                <div class="van-nav-bar__content">
                    <div class="van-nav-bar__title van-ellipsis">Investasi anda</div>
                </div>
            </div>
            <section data-v-7501b02e="" class="section-box">
                <?php $__currentLoopData = \App\Models\Purchase::with('package')->where('status', 'active')->where('user_id',
                auth()->id())->orderByDesc('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div data-v-7501b02e="" class="listpro">
                    <div data-v-7501b02e="" class="topcent">
                        <div data-v-7501b02e="" class="topi">
                            <p data-v-7501b02e="" class="namei"><?php echo e($element->package->name); ?></p>
                            <div data-v-7501b02e="" class="pricei flex">
                                <p data-v-7501b02e="">Price：<span
                                        data-v-7501b02e="">$ <?php echo e(number_format($element->package->price)); ?></span>
                                </p><img data-v-7501b02e="" src="<?php echo e(asset('public')); ?>/vip.PNG" alt="" class="imgti">
                            </div>
                            <img data-v-7501b02e="" src="<?php echo e(asset($element->package->photo)); ?>" alt="" class="imgpro">
                        </div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Daily income:</div>
                        <div>$ <?php echo e(number_format($element->package->commission_with_avg_amount / $element->package->validity)); ?>

                        </div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Purchase Validity:</div>
                        <div><?php echo e($element->package->validity); ?> day</div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Commission</div>
                        <div><?php echo e(price($element->package->commission_with_avg_amount)); ?></div>
                    </div>

                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>Started</div>
                        <div><?php echo e($element->created_at); ?></div>
                    </div>
                    
                    
                    <div style="display: flex;justify-content: space-between;padding: 5px 15px;line-height: 20px;">
                        <div>End</div>
                        <div><?php echo e($element->validity); ?></div>
                    </div>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <?php echo $__env->make('app.layout.manu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

</body>

</html><?php /**PATH /home/hellocod/v1.hellocoder.xyz/resources/views/app/main/purchase_history.blade.php ENDPATH**/ ?>