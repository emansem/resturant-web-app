<uni-toast data-duration="100000000" class="loadingClass" style="display: none;">
    <div class="uni-toast"><i class="uni-icon_toast uni-loading"></i>
        <p class="uni-toast__content"> Loading </p></div>
</uni-toast>
<?php /**PATH /home/hellocod/v1.hellocoder.xyz/resources/views/loading.blade.php ENDPATH**/ ?>