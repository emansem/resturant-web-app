<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="<?php echo e(asset('public')); ?>/NorthernStar/favicon.ico">
    <title><?php echo e(env('APP_NAME')); ?></title>
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-2ed43842.cad7a6c1.css">
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-68298b13="" class="minepage">
        <div data-v-68298b13="" class="topnav"><img data-v-68298b13="" src="<?php echo e(asset('public')); ?>/NorthernStar/dist/img/logo.3b8d8b63.png"
                                                    alt="" class="logoimg"><img data-v-68298b13=""
                                                                                src="https://cdn.discordapp.com/attachments/1079841109049618516/1255115991319449600/home_top_bj-363fbaa0.png?ex=667bf55b&is=667aa3db&hm=0d2b9517821907f336ce98b45554408e605cc2c78a1fbf737bc9eb55902c3f55&"
                                                                                alt="" class="imgtask"></div>
        <p data-v-68298b13="" class="username"><?php echo e(env('APP_NAME')); ?></p>
        <p data-v-68298b13="" class="mobile"><?php echo e(auth()->user()->phone); ?></p>
        <div data-v-68298b13="" class="itembox">
            <div data-v-68298b13="" class="listit" onclick="window.location.href='<?php echo e(route('user.deposit')); ?>'"><img data-v-68298b13=""
                                                        src="<?php echo e(asset('public')); ?>/NorthernStar/icon/20240626_024331.png"
                                                        alt="">
                <p data-v-68298b13="">Recharge</p></div>
            <div data-v-68298b13="" class="listit" onclick="window.location.href='<?php echo e(route('user.withdraw')); ?>'"><img data-v-68298b13=""
                                                        src="<?php echo e(asset('public')); ?>/NorthernStar/icon/20240626_024411.png"
                                                        alt="">
                <p data-v-68298b13="">Withdraw</p></div>
            <div data-v-68298b13="" class="listit" onclick="window.location.href='<?php echo e(route('user.bank')); ?>'"><img data-v-68298b13=""
                                                        src="<?php echo e(asset('public')); ?>/NorthernStar/icon/20240626_024451.png"
                                                        alt="">
                <p data-v-68298b13="">Account</p></div>
            <div data-v-68298b13="" class="listit"><img data-v-68298b13=""
                                                        src="<?php echo e(asset('public')); ?>/NorthernStar/icon/20240626_025011.png"
                                                        alt="">
                <p data-v-68298b13="">Telegram</p></div>
        </div>
        <section data-v-68298b13="" class="section-box">
            <div data-v-68298b13="" class="bottomi"><p data-v-68298b13="" class="amount"><?php echo e(price(auth()->user()->balance)); ?></p>
                <p data-v-68298b13="" class="totali">Total balance</p>
                <div data-v-68298b13="" class="listti flex" onclick="window.location.href='<?php echo e(route('user.change.password')); ?>'">
                    <div data-v-68298b13="" class="lefti"><img data-v-68298b13=""
                                                               src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAvdJREFUWEftmEtsTGEUx3//r63HgiARKSLpCiGRsGm404RaCBaKILGwkHhulFWxRFfUxjOxsJAgXgvEQkk6U+mGREKwkggakSAsPNp+R2Za0zst5t6ZDNfj7ma+75zzm/P/5pzzXZHwR+XwWRdT6WUdqBExG9PEnD/Za4wHYO1Uc1b1PC81TkmA1kEtzh0A1gM1RYL3AGfwfrca6I4LGhvQ0ixHOg2aEC+YvcFsg1JcjWMXC9AyVRswO4WoihMkv9foQ9qooO90VPvIgNZBI87dAKoLndtDzI4hbjKep7m1t9RhLEbaCpo1BKYX75eogfYokJEArYux9OoRaHJhNmhhgT8o4b8XzAxHp9uF0VqYdXtJtc1UPe+LQUYDzOT+EC0hZx6vtWrou1AsQHbdOqpW4+wc4EL7WxX43cXsiwLabUZRo27QuFD29ivl9xZzHl63tNuH2DP4nb2jx2q1kE8/81McsIMVOHc55PgVzuo0n4+xAO8wGq+noEl5O++b1MCV8gAz7hDQHHJyWIEPf47MaRnXBuwIGbQp8DvLBNQ10NJBJ36VAi5FpgpttAwrwV0MqXFdgS2LBWhp5uDcJrBFeNUhRpYCE9nG+IyzrPS38P6kUtwP2+bPoJ1nBFNyEmwhWx5+x9Nfro7zwjdrDV+yCDnAHFytriM1/g6uYTHN2um2pVnIfsBOdwRjWyLgvkGIo1rgt2vgzN0rlNWeYNaSbV8K+FBJcMswZqAttoKm52Nl5fZ+roZnz57QY/VayLtKgg31bbcZR426hkAelXXqEaYZeQPzK5UiVJh/HaalaUJusITJHsvS7lNhKfFjKy3rj35yTm7c4ABhfJZlnBXUncAXbX+VzOkwnv+AMdP992fQ0kzD6QJoXuSWmGthdhdvq5Xi2c+SWnYGLeOOA5tjKvdt+wkFfss/Dph0iUuUNrJZ2WcwcqQSN/6BgInvxYmfZoZN00mbB/tvccmdqBN/J/kjbnV5yKTei8M1NbFvFkos/BU3+wpZ4pzsweWn4AAAAABJRU5ErkJggg=="
                                                               alt="">
                        <p data-v-68298b13="">Security center</p></div>
                    <img data-v-68298b13=""
                         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAaCAYAAACkVDyJAAAAAXNSR0IArs4c6QAAAdVJREFUSEvN1tmLSFEYAPDf+Ac82Xmxb3+DIvvzeEAIkSRLtryLoUia5mVKliyRN6/WkP3f8GZXypK+nFun29xzx8y4ua/n+87vnq+zfD3Yg+N4jXV4p/2bgDuYhYO41J7yJ6IHHzA+JbzBcrxvmWAfzqWYX9iBC8NBA7yHpVnwK6xIP9I0xxLcx7gM3Y6LbWiAUZ5AF2fBL7GyBd2FgVSlSP2JbbhcQgOMb2JCF2XBLxL6sTDBbvTX0K240pRTgTE+KaELs+DnCf1UQGPTna+hW3B1qJwcjPHJCV2QBT/DKpTQvWkTVfP9wGZcr6N1sEJjQ8zPgp9iNT4XVrofZ7OVBroJN/KcocAYn5J24bws+ElCvxTQAzhTQzfiZpXTBMb41ITOzYDHWIMSeginM/Q7Ar0V85TAGJ+W0DkZ+ghr8bWw0iPoq6HrcbsNjDmnJ3R2BjxM5f1WQI/iZA3tHQ4Yc87AA8zMgJ0YLIAxdAwnspi3/yUYJY3VxctQff+spCPdNIdx6m83zVgdi7gANrQdi6aDH2ewdNuM6ODHfdrZ1RYvRmBjcXnHi3GtdHl3+jx1+gB33mLcxbKs1tEuRucW3VzTN6omqvM2cbSNcLx/re1hVarfRH6Ug60rbSMAAAAASUVORK5CYII="
                         alt="" class="rightimg"></div>








                <div data-v-68298b13="" class="listti flex" onclick="window.location.href='<?php echo e(route('checkin_history')); ?>'">
                    <div data-v-68298b13="" class="lefti"><img data-v-68298b13=""
                                                               src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAcpJREFUWEftmbsvBFEUxr/vJh4NURKVCpVEJdndwqNSSCj8CQiV0l+gVBH8CQoShcqj2JWoJCq2Ugml0FiS+8nOvl/ZmZ3Z5IqZcubcc375zjn3zpwhmlxKYwrGrAGag+UYiL5mdqHvCTkYPQO8hrXHTOGh3ierb+gEvRg1ewA2IJjQAEEcEBbAIV7sNlfxXVpaBvTgRngBcj6I38htpSu8arEEWQG8NfsQNiMP2IlD4oAJu5Vf6gEWa+6+Nq3KQtoBcckkPjuJ026NMhiAsAByF+B42T6fbmun8zVZAGxQT1n8aIazeG8XJIrnusEQenhXB+mpWATkI8SJcjDZFaZwFkVwvz6UxjJoTisq6okJTRZTbL5qtxI72K20tgL20g3zUREJOaZsfwEwY1S9kElbs/34VSGsXTOOGDCIqrGCQdRqZhuZgspgCeIRyGHfUNIbqHUmcd66kxubtaMmUZqvgeBKRNIbUxqJAZ1Pse+6C2gYWZMEjOvbPAb0LVULw/+joPNdHG/UxRrNv5d2dtS5fhaH7daun8UxYNgajBX8ewqmXf9wv3V99OH88Kgw8nV3/ObNZ1weYHqAro+Ay5CuDtGrTweXfkP8AmPAujgB6GngAAAAAElFTkSuQmCC"
                                                               alt="">
                        <p data-v-68298b13="">Checkin list</p></div>
                    <img data-v-68298b13=""
                         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAaCAYAAACkVDyJAAAAAXNSR0IArs4c6QAAAdVJREFUSEvN1tmLSFEYAPDf+Ac82Xmxb3+DIvvzeEAIkSRLtryLoUia5mVKliyRN6/WkP3f8GZXypK+nFun29xzx8y4ua/n+87vnq+zfD3Yg+N4jXV4p/2bgDuYhYO41J7yJ6IHHzA+JbzBcrxvmWAfzqWYX9iBC8NBA7yHpVnwK6xIP9I0xxLcx7gM3Y6LbWiAUZ5AF2fBL7GyBd2FgVSlSP2JbbhcQgOMb2JCF2XBLxL6sTDBbvTX0K240pRTgTE+KaELs+DnCf1UQGPTna+hW3B1qJwcjPHJCV2QBT/DKpTQvWkTVfP9wGZcr6N1sEJjQ8zPgp9iNT4XVrofZ7OVBroJN/KcocAYn5J24bws+ElCvxTQAzhTQzfiZpXTBMb41ITOzYDHWIMSeginM/Q7Ar0V85TAGJ+W0DkZ+ghr8bWw0iPoq6HrcbsNjDmnJ3R2BjxM5f1WQI/iZA3tHQ4Yc87AA8zMgJ0YLIAxdAwnspi3/yUYJY3VxctQff+spCPdNIdx6m83zVgdi7gANrQdi6aDH2ewdNuM6ODHfdrZ1RYvRmBjcXnHi3GtdHl3+jx1+gB33mLcxbKs1tEuRucW3VzTN6omqvM2cbSNcLx/re1hVarfRH6Ug60rbSMAAAAASUVORK5CYII="
                         alt="" class="rightimg"></div>
                <div data-v-68298b13="" class="listti flex" onclick="window.location.href='<?php echo e(route('user.service')); ?>'">
                    <div data-v-68298b13="" class="lefti"><img data-v-68298b13=""
                                                               src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAKKADAAQAAAABAAAAKAAAAAB65masAAAHuElEQVRYCe1YfYxU1RX/nTdfDMtugYJQPhpXxdZqi5TFwAyUlaoBy1aJpbVNP2ytjWDUVq1NaEuNsdZE/UNsGpXQxtjGFBMka5EqSK3uzi4tVqwitvW7yhYVWLrs7A4z805/9828N+/Ox2bwz4absPecc3/nvN89995z7wCcbP/nGZCx5qeZxBnQ/CWArIDqaRBMhyLHfoC2v7PvRrxtm3QcOdoojmaSM+HmuiDOWYwx28MJPgD0FSD6pKSPv9TI19jrEtS+cafCzd/GIF8jobqYUNBBIu6AzNggqXdGfLtmoikSup0xPjdmDMF+0rgVqZ9uFrnF9f39vubj2hv5EoM+yKDjfVCT/T7E4l04ZfoADvz7AZL7RpN+JZhIBppYLYuzB8J+FkHtdW7k4J1jzjjsXS0LDtE0QP9zqoea0gUHgUiXpPN/9fEBQWaOe00frSUnz8HRjUDsKWDqu0geSyA7PIcZ6gLcNQw0xQ/WsBd5lrG3cSlf5XYoUp4FV5ZBdCW/F7P8DElJzJfUyLvG7hHUvyRnI597ieC2EDgHR9ZiUeE3IqIheyBq/+Q2FI5u4Ae/FRht4QVEI1fLwny/bS5p5b1+Dyf7RXtc+pFeskTk6UKJYG/kfoK+F4AExwHnQkkXnglsDQTdN3UCBg/t5+Rm2RDZjtYpq2XuwWHbzumocs6lSRsZmdgvoO6PLJwj35VUcZNof3IWCrk3OBgNAIJrJO3+KtAbCJqZlYQObOcXl9oQ2YFp7V0y59Vc2K4942dAcg+R4tlcvCslXeSylwgjE93COJcGeMGbSMw700ExZ9IbJrcfqfX3BcAGgv7rjATJba0hJ/IMxk27tIZcf8s0yOgu4pcx29MYdq0f2stmIrGWGy4oU8ScisILnQ5nssIHer1iY716FMao3uLgvTc282MXhe2MtRs6aaV0HMiG7fq3CVNRGHmKH/1EYFd9LJApSEfWFH9mN9RcrCBBrTiZMYnuCEHqi323Xkdy9sYWPI+W1uWy+IOhGqeRkd/TxmX1m/xSFrv3saytYfV4TPuind6IwCLNbyw0Szvdd/N6bXsL5iZq0Mp7lreM1V5GouUimTc4aFmpaM+UVuBwZY+KPIBU4TrtibHeujcRARS1ndBzEIntg8vz6TfV6cwgIr7u9ePirFNjNPe4WdaWACF4B/Hk56VjyJqV7kl+3GBKGXXupTgIx7mT5K7mqeUEDblyE9ZH05KJ6glOdDiB/5Rhpa5waKalVysu5lkmwV1y3rAVg0uWRi73ovZGf26wLFffR7o4WVKFm5GJXMvMrQtiCF6DxK/x9OyoXfT5qHAgYkpMpRULnRWlCUnNGlUaSS1D0X2C1jZDhPvsx2bUr3sUfxCgBW8hkVjm3xrQgj15yAAzqE8EDiXhiirdVh3stQyKm7QvfpaxccNfTlKmtlW2gOI27XEqpCB/Kvu/jmj8fOkYebusc9VRqYOeUXpEM/FPwi3wyRNqjqxiFd8asgRi+Vp8hRmyXzumhimSAbBWWGNOrjHzm5/GotR+c5X5MO1PzEEhb3hUzoTjpEtXXU9kC91W+WD2RyCxBZLOvRayBSKX7QaSuTswNCMIPRz5tiwqPlgN1z3zY8jtfZqrmQrGBC8iVZxrTjE3SGQ9/wazoTwJyO/0T6KBWC112T3cVPey8lv7L8AIjvIuv4P6aGAzD9+ibtK+yJcDGwXvLh7du9EiZwAiPzP71sug0ZkVni7wZRJq3glLLA02cWjIiNofvRAFvYHPpvOoTqI/D5x5WiXWmYcnyayAq7wOEQ+5MhFymSwudnsxMpEdxFwQGjfkunlP8/lHMTzATb6JM/lO2EbEPxBLdlaXEgtDxTwcwk9+f1wzkVUksJm6uRT8xt81Dm8ivZHfq7ou8U9EJy6QhYf/a8A2QV0dQWbL7+j0FT9SuX8Z48d3ymePvV9lb0olya8y5m+ZydKWMl7CMxvWjc3hY1Vj6fDerzgYH3mkiNSSr1PiobHap5DN7tTdrR+1rE0qrAgPM/hVJFXZs9XkvDFZFyZnwlsEjcE7+uPOvZySfXEDn0FheIc+P3GiwZ1oI8lfk+C1df1KxK/3MFWAGoJmXDqey/PBuZrSHy288prLDj3pPfWtgSYVkbeJrL7rzfm+mQ9kc1/XtLoEDcp7cM6czdooOy0v1QUoHt3uPfWtgbEV/k5ezjLzCFGVQmwyJ1gvKfeuRt4NCRoHaX9zlK/jS7juf7YCmII6eHib7plh3yYWqKLw8XABXPdRWhIVq7cfb2fmqp9uIQg5WFoDxcvWkcNcbk1bEJFdkI+trFdefBwzt5T38+OkU5mMlzm5intuk49r1I+ZQd9Jzn7/GKIfuZjz2e3bvN78vnAHunVPq/1MKoNYV7/AzP3BImfGFGubIWegTWXQAE3zTvDwEPekzi9Zyn8F7zHUT3hlPot4ywByQ3NZ975J3JUWziiC67ms9o1VA6oYToigcdNM22S4x3ZRnFsJ06Tk4IdjHYh6UU6YoAniLWku280sLaoXtMZmbg0+VE8kc36MpvagD/Z77/fHKe3n8z7dwCXL+/YG/evEXfxhyJl4HyqDYSLamzidtfcK5nU5/7XzAEzg+EGG5n86YSvi5z7sFf6w00n5ZAYqGfgft3TOG5JjvqAAAAAASUVORK5CYII="
                                                               alt="">
                        <p data-v-68298b13="">Help Center</p></div>
                    <img data-v-68298b13=""
                         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAaCAYAAACkVDyJAAAAAXNSR0IArs4c6QAAAdVJREFUSEvN1tmLSFEYAPDf+Ac82Xmxb3+DIvvzeEAIkSRLtryLoUia5mVKliyRN6/WkP3f8GZXypK+nFun29xzx8y4ua/n+87vnq+zfD3Yg+N4jXV4p/2bgDuYhYO41J7yJ6IHHzA+JbzBcrxvmWAfzqWYX9iBC8NBA7yHpVnwK6xIP9I0xxLcx7gM3Y6LbWiAUZ5AF2fBL7GyBd2FgVSlSP2JbbhcQgOMb2JCF2XBLxL6sTDBbvTX0K240pRTgTE+KaELs+DnCf1UQGPTna+hW3B1qJwcjPHJCV2QBT/DKpTQvWkTVfP9wGZcr6N1sEJjQ8zPgp9iNT4XVrofZ7OVBroJN/KcocAYn5J24bws+ElCvxTQAzhTQzfiZpXTBMb41ITOzYDHWIMSeginM/Q7Ar0V85TAGJ+W0DkZ+ghr8bWw0iPoq6HrcbsNjDmnJ3R2BjxM5f1WQI/iZA3tHQ4Yc87AA8zMgJ0YLIAxdAwnspi3/yUYJY3VxctQff+spCPdNIdx6m83zVgdi7gANrQdi6aDH2ewdNuM6ODHfdrZ1RYvRmBjcXnHi3GtdHl3+jx1+gB33mLcxbKs1tEuRucW3VzTN6omqvM2cbSNcLx/re1hVarfRH6Ug60rbSMAAAAASUVORK5CYII="
                         alt="" class="rightimg"></div>
                <div data-v-68298b13="" class="listti flex" onclick="window.location.href='<?php echo e(route('about')); ?>'">
                    <div data-v-68298b13="" class="lefti"><img data-v-68298b13=""
                                                               src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAABZZJREFUWEfNmGuMXGMYx3//d3erXa3afqAWdYlrmihVbe2eKRKyWpe4NP1AIvGlJVRQBB8oiUvELUVcEpFI+FCUoGmFpJjZ7UUvS1KXktQlFhG29G533kfmzM7MObOzc86s6/vtzPu87/M7/+dy3nnF/3zor/DZZtrZw2Wgs4GpSO0YrYg9mPUBW8Hep5UVmk7hueExKkDr4TTyugvpIqAphdc8Zm/RZPeqgy0p7MsmDQHacsbR7h4Crk0JVs2SB56mz9+mBexNA5oa0HK0g1aCTk2zcX0b6wW7QEFy2FMBDsHlQMcMd2ybMHuZFj5gJ1/Rzy7aGM8EjmOAs5CuAJ1eY912sCAJMhGwGFb1DFfOtuHtBs3hnSRFrYcuvJaBTojbWi991lEv3MmAOfcEcH3VxiuYYFdpGruT4Erz9jEHslMvgi6rWvOkAr94pH3qAobV6t1H8YKwFfTZAi2gkPANDVtOE+1aXgWZx/kzRqru+oBZvY50SYXCtjHBpjeiXPUbDCm5ORZuszeUsUtrve2IgMUm7L6Nqef9+WlyLklW+5AunFsdscvT6qfUauYjA+YKeRfm39CwTQpsRpLztPOW08Z4dfvFCniyen0dQL0KurzC55cow6NpAZLsLMvNyD0SEeA1BTa/EcDPQCeVFzT7GZrNpiTHaedtHacz6DZGAD9XYCc3AOh+ByaUF+z1B+s8fksLkGRn7zKRcW5HxG6nAn9QI4CDsQLp883VrcVyXIzp2XBT2SIFvBl1UG/ejCa6XcFHaeQV+Ob0gFm3C3FgJAcnKUN/DCCrH5Amh7+Z/aiMHZZ23nqYhHe/ROx3KfCViA1N1CuSL2K9yvtZmsOGuEJuDzAukqeTNZufQt51HMqg+zFiv1eBby09Ww8z8W59JAe3KbAT0yuY02uxjm/+FmWIVB1YTmtBs8ubyt6gya4Jn/N6Bos1+XUK7MwyYJYlyD0cAVyhwCpdI1HBbhZjbllkgy0KbHpVjlX1yur3jz7H+5zlVPianFZ5OX+DOon03eLMyCHOEiCXjbls8vN0JqvKKmxlDP1an3xGtF7abJam8kcY/hzzwK2M7J0n74/RWXyXGGJ7i1ba3H3AdUBLfIF9ylg7VTMYiOTS4Xi9PTKk9eLsQnXwfQhXeKkd6sVU6XlGHrGM3/0dmsf+qM+YgtbNIZhWx6QfHrU7FfgHYqEOlWQh6ErQtOKcfQz2Em08V1Iu/LXb3Y2xtHYy2CZarEuzKFd3GbConAqn5kpexHfZj9nPiK8ZsLk6h131Mq7WnK2hmRb3PNgc0FG1U8w2MmAZncO+WA5azj0G3FgV0u3IHmCQ1bXyo1HAmOprmMwYLsJ0O+jYqr0eVuBvLQNaN0dh7st4ztlqdtt8daU/NY8G2NYwnma9gnR+ZP0A8serk2/CEFvWLUXcXTYwKyg3TQE7R+O00TVDh9hPYkoa9yjjlxYBu9WNqaMC6Bcpw3ONOvor9pZlIXLF73qxyNYqsI4iYM79CrSV5/J+yt+dc0nwto4jGHTRPtivwE8qARb6WuUk0ecP0IJiU/23hm2khX0u6nNQgW+preAYP0Uzh3f1fxLWNnAkf4T/gUojomB1Djq/SB3/cg72sBAfyUFZjzqtc6iKWYpcpYqx7bTZKZraeDMejcq2lfH0q1DFlasV8/coQ6mKa/RBs3eYZPP/acgQ7le9itQ1Yh8cquTaXxJnD9LMKr6mbzS3CbUUDW8YjqadQebiwy9J9aXU4wr8TYW1lW9xD+Pw6k44KIwmgg2usS0461RH8f4wfpp5j0MZq1X/HaRtYZ/N1bnFvw3DAMNQh0q6+2ufBxsUI715oQ8/hfN3lpQbEbA0ER4gPFfjdN7Q4XIi4NL7rGvpgd+QfYa3d3G8UDgY1FqReD/4NwGNeps/AQvlOUegWyLRAAAAAElFTkSuQmCC"
                                                               alt="">
                        <p data-v-68298b13="">About us</p></div>
                    <img data-v-68298b13=""
                         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAaCAYAAACkVDyJAAAAAXNSR0IArs4c6QAAAdVJREFUSEvN1tmLSFEYAPDf+Ac82Xmxb3+DIvvzeEAIkSRLtryLoUia5mVKliyRN6/WkP3f8GZXypK+nFun29xzx8y4ua/n+87vnq+zfD3Yg+N4jXV4p/2bgDuYhYO41J7yJ6IHHzA+JbzBcrxvmWAfzqWYX9iBC8NBA7yHpVnwK6xIP9I0xxLcx7gM3Y6LbWiAUZ5AF2fBL7GyBd2FgVSlSP2JbbhcQgOMb2JCF2XBLxL6sTDBbvTX0K240pRTgTE+KaELs+DnCf1UQGPTna+hW3B1qJwcjPHJCV2QBT/DKpTQvWkTVfP9wGZcr6N1sEJjQ8zPgp9iNT4XVrofZ7OVBroJN/KcocAYn5J24bws+ElCvxTQAzhTQzfiZpXTBMb41ITOzYDHWIMSeginM/Q7Ar0V85TAGJ+W0DkZ+ghr8bWw0iPoq6HrcbsNjDmnJ3R2BjxM5f1WQI/iZA3tHQ4Yc87AA8zMgJ0YLIAxdAwnspi3/yUYJY3VxctQff+spCPdNIdx6m83zVgdi7gANrQdi6aDH2ewdNuM6ODHfdrZ1RYvRmBjcXnHi3GtdHl3+jx1+gB33mLcxbKs1tEuRucW3VzTN6omqvM2cbSNcLx/re1hVarfRH6Ug60rbSMAAAAASUVORK5CYII="
                         alt="" class="rightimg"></div>
                <div data-v-68298b13="" class="listti flex">
                    <div data-v-68298b13="" class="lefti"><img data-v-68298b13=""
                                                               src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAiCAYAAADCp/A1AAAAAXNSR0IArs4c6QAAAwVJREFUWEftmE1sTFEUx3//VxONVHyEUBbYky5ISDOTpmEhFhLRsBIfC12wkygbXxsqsWNRCyFWpEgsxII0zQwhYSHs1YJWiBJdkDHvyLvVmTfT1/bNzBUbb/neu+f+7jnn3vM/V3h6rMBOTAPOnKxXWe57Mo18GbK8RpFWOntmY8pZuy/b/iALgcWhlA292fZmyP5DJiSODbGMDAdAOzA2IC0Cy2PWoxzjSblWjyctzxKkQVAOs2+I12APKHJd3XyutV8VbjtDwLbgGNgpUFsCzGllw3NNQxaCU8DZ6XZsAnSOR+ElnSGc+l6GtCFayegWaOcsu/IvQ07NbPcp2l5188OdaOXXBef+3TMAlsCG/0K4u4CW5DntjrLWU4a0pxwmDCYP4vJjX5D1EzLIY0bi7m823GXHROm1lbUE9GDqAy2tsh2EverkquwFC/ihEdDy8g+yN8i2q5P3aQ/kejZO4iKfshrTQ0zrY476RKutlT3hIBZci334Tsk61MXbtICuyHg4J22YdbToFWhhxWHhIVlBd0G7KlGmX7nwRD2AviCdnXxwAdEXc9q9CDIK9ZoKZLhJOV7+O0g2ouBFDPKdrBBE23x++WUxXKhuJv4Z5BBtZILvsfl/RpBehIEvO4mp48u4LzveIJ3ARQO4GNh5RrnCquBXVYp8COfRzhHQycmSkV4IT1twIx6oEriOzKJjo6M6j2ve1SGE/UAWNAp/VHjqHWZjyqZT654gXbhvgBanY7SvYPvT9j1eIF2An7GCX8FFYF9cqNRAR1l7k3nhcW3hY7oFJVSvRnIyPpnlySJdTsxJs6PKUUgLN/WfN09Wgd6mxe1kRUrGdYv90Y7XHkr1As50BHmpOI3AJI2x5Irjp3Z7g8wn1m4/KsgfZJIKStKTGevQ5vr0pA9Ie846ikl60pMybxbSZlPmbjd56HEagXQtdJoep3I2zdotNsLQ5JiabtF5M13f3eTEaYfP0Hc70LlvMNLO0uB/c9xgVFWQ6XdBS2Zu4hvkmRxWwmx8rrug3+7LwrBp9cXJAAAAAElFTkSuQmCC"
                                                               alt="">
                        <p data-v-68298b13="">Download App</p></div>
                    <img data-v-68298b13=""
                         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAaCAYAAACkVDyJAAAAAXNSR0IArs4c6QAAAdVJREFUSEvN1tmLSFEYAPDf+Ac82Xmxb3+DIvvzeEAIkSRLtryLoUia5mVKliyRN6/WkP3f8GZXypK+nFun29xzx8y4ua/n+87vnq+zfD3Yg+N4jXV4p/2bgDuYhYO41J7yJ6IHHzA+JbzBcrxvmWAfzqWYX9iBC8NBA7yHpVnwK6xIP9I0xxLcx7gM3Y6LbWiAUZ5AF2fBL7GyBd2FgVSlSP2JbbhcQgOMb2JCF2XBLxL6sTDBbvTX0K240pRTgTE+KaELs+DnCf1UQGPTna+hW3B1qJwcjPHJCV2QBT/DKpTQvWkTVfP9wGZcr6N1sEJjQ8zPgp9iNT4XVrofZ7OVBroJN/KcocAYn5J24bws+ElCvxTQAzhTQzfiZpXTBMb41ITOzYDHWIMSeginM/Q7Ar0V85TAGJ+W0DkZ+ghr8bWw0iPoq6HrcbsNjDmnJ3R2BjxM5f1WQI/iZA3tHQ4Yc87AA8zMgJ0YLIAxdAwnspi3/yUYJY3VxctQff+spCPdNIdx6m83zVgdi7gANrQdi6aDH2ewdNuM6ODHfdrZ1RYvRmBjcXnHi3GtdHl3+jx1+gB33mLcxbKs1tEuRucW3VzTN6omqvM2cbSNcLx/re1hVarfRH6Ug60rbSMAAAAASUVORK5CYII="
                         alt="" class="rightimg"></div>
                <button data-v-68298b13="" class="btnout" onclick="window.location.href='<?php echo e(url('logout')); ?>'">Sign out</button>
            </div>
            <p data-v-68298b13="" class="northrn">© 2024 Northern Star Resources Limited.</p></section>

        <?php echo $__env->make('app.layout.manu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/hellocod/v1.hellocoder.xyz/resources/views/app/main/profile.blade.php ENDPATH**/ ?>