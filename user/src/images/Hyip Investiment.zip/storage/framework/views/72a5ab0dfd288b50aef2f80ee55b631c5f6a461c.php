<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: calc(50px + env(safe-area-inset-bottom));">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Team</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="<?php echo e(asset('public')); ?>/index.2da1efab.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/team.css')); ?>">
    <style>
        .bottom .flex-bom[data-v-f93514ba] {
            height: 15.466667vw;
            display: flex;
        }
    </style>
</head>
<body class="uni-body pages-index-team">
<uni-app class="uni-app--showtabbar uni-app--maxwidth">
    <?php
    $rebate = \App\Models\Rebate::first();
    ?>
    <uni-page>
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-2bfad2ee="" class="content">
                    <uni-view data-v-2bfad2ee="" class="w690 fb mt30">My team</uni-view>
                    <uni-view data-v-2bfad2ee="" class="top-wrap white f26 d-b-c">
                        <uni-view data-v-2bfad2ee="" class="top-item">
                            <uni-text data-v-2bfad2ee=""><span>Total people</span></uni-text>
                            <uni-text data-v-2bfad2ee=""><span><?php echo e($team_size); ?></span></uni-text>
                        </uni-view>
                        <uni-view data-v-2bfad2ee="" class="line"></uni-view>
                        <uni-view data-v-2bfad2ee="" class="top-item">
                            <uni-text data-v-2bfad2ee=""><span>Total investment</span></uni-text>
                            <uni-text data-v-2bfad2ee=""><span><?php echo e(price($lvTotalDeposit)); ?></span></uni-text>
                        </uni-view>
                        <uni-view data-v-2bfad2ee="" class="line"></uni-view>
                        <uni-view data-v-2bfad2ee="" class="top-item">
                            <uni-text data-v-2bfad2ee=""><span>Total rebate</span></uni-text>
                            <uni-text data-v-2bfad2ee=""><span><?php echo e(price($levelTotalCommission1 + $levelTotalCommission2 + $levelTotalCommission3)); ?></span></uni-text>
                        </uni-view>
                    </uni-view>
                    <uni-view data-v-2bfad2ee="" class="section d-s-c">
                        <uni-image data-v-2bfad2ee="">
                            <div style="background-image: url(<?php echo e(asset('public')); ?>/static/image/team-section-icon.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                            <img src="<?php echo e(asset('public')); ?>/static/image/team-section-icon.png" draggable="false"></uni-image>
                        <uni-text data-v-2bfad2ee=""><span>My team data</span></uni-text>
                    </uni-view>
                    <uni-image data-v-2bfad2ee="" class="invite" onclick="window.location.href='<?php echo e(url('task')); ?>'">
                        <div style="background-image: url(<?php echo e(asset('public')); ?>/static/image/invite.115179ce.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                        <img src="<?php echo e(asset('public')); ?>/static/image/invite.115179ce.png" draggable="false"></uni-image>
                    <uni-view data-v-2bfad2ee="" class="team-wrap level1">
                        <uni-view data-v-2bfad2ee="" class="ration pa d-c-c"><?php echo e($rebate->interest_commission1); ?>%</uni-view>
                        <uni-view data-v-2bfad2ee="" class="team-name d-s-c">
                            <uni-image data-v-2bfad2ee="">
                                <div style="background-image: url(<?php echo e(asset('public')); ?>/static/image/level1.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                <img src="<?php echo e(asset('public')); ?>/static/image/level1.png" draggable="false"></uni-image>
                            <uni-text data-v-2bfad2ee=""><span>My Lv1 members</span></uni-text>
                        </uni-view>
                        <uni-view data-v-2bfad2ee="" class="team-info d-b-c">
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="red fb f36"><span><?php echo e(price($lv1Recharge)); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>Investment</span></uni-text>
                            </uni-view>
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="fb f36"><span><?php echo e(price($levelTotalCommission1)); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>Rebate</span></uni-text>
                            </uni-view>
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="fb f36"><span><?php echo e($first_level_users->count()); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>People</span></uni-text>
                            </uni-view>
                        </uni-view>
                    </uni-view>
                    <uni-view data-v-2bfad2ee="" class="team-wrap level2">
                        <uni-view data-v-2bfad2ee="" class="ration pa d-c-c"><?php echo e($rebate->interest_commission2); ?>%</uni-view>
                        <uni-view data-v-2bfad2ee="" class="team-name d-s-c">
                            <uni-image data-v-2bfad2ee="">
                                <div style="background-image: url(<?php echo e(asset('public')); ?>/static/image/level2.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                <img src="<?php echo e(asset('public')); ?>/static/image/level2.png" draggable="false"></uni-image>
                            <uni-text data-v-2bfad2ee=""><span>My Lv2 members</span></uni-text>
                        </uni-view>
                        <uni-view data-v-2bfad2ee="" class="team-info d-b-c">
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="red fb f36"><span><?php echo e(price($lv2Recharge)); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>Investment</span></uni-text>
                            </uni-view>
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="fb f36"><span><?php echo e(price($levelTotalCommission2)); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>Rebate</span></uni-text>
                            </uni-view>
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="fb f36"><span><?php echo e($second_level_users->count()); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>People</span></uni-text>
                            </uni-view>
                        </uni-view>
                    </uni-view>
                    <uni-view data-v-2bfad2ee="" class="team-wrap level3">
                        <uni-view data-v-2bfad2ee="" class="ration pa d-c-c"><?php echo e($rebate->interest_commission3); ?>%</uni-view>
                        <uni-view data-v-2bfad2ee="" class="team-name d-s-c">
                            <uni-image data-v-2bfad2ee="">
                                <div style="background-image: url(<?php echo e(asset('public')); ?>/static/image/level3.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                <img src="<?php echo e(asset('public')); ?>/static/image/level3.png" draggable="false"></uni-image>
                            <uni-text data-v-2bfad2ee=""><span>My Lv3 members</span></uni-text>
                        </uni-view>
                        <uni-view data-v-2bfad2ee="" class="team-info d-b-c">
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="red fb f36"><span><?php echo e(price($lv3Recharge)); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>Investment</span></uni-text>
                            </uni-view>
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="fb f36"><span><?php echo e(price($levelTotalCommission3)); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>Rebate</span></uni-text>
                            </uni-view>
                            <uni-view data-v-2bfad2ee="" class="team-info-item">
                                <uni-text data-v-2bfad2ee="" class="fb f36"><span><?php echo e($third_level_users->count()); ?></span></uni-text>
                                <uni-text data-v-2bfad2ee=""><span>People</span></uni-text>
                            </uni-view>
                        </uni-view>
                    </uni-view>
                    <uni-view data-v-2bfad2ee="" class="section2">— Why create a team —</uni-view>
                    <uni-view data-v-2bfad2ee="" class="rule">
                        <uni-view data-v-5594bfb4="" data-v-2bfad2ee="" id="_root" class="_root">
                            <uni-view data-v-51130a2d="" data-v-5594bfb4="" class="_block _span ">
                                <uni-rich-text data-v-51130a2d="">
                                    <div style="position: relative;"><p data-v-51130a2d="" style=""><strong
                                                data-v-51130a2d="" style="">Invite friends to participate and earn
                                                more commissions. If you successfully invite investors, you will receive a 50%
                                                reward of the investment amount.</strong></p>
                                        <uni-resize-sensor>
                                            <div>
                                                <div></div>
                                            </div>
                                            <div>
                                                <div></div>
                                            </div>
                                        </uni-resize-sensor>
                                    </div>
                                </uni-rich-text>
                                <uni-rich-text data-v-51130a2d="">
                                    <div style="position: relative;"><p data-v-51130a2d="" style=""><br
                                                data-v-51130a2d="" style=""></p>
                                        <uni-resize-sensor>
                                            <div>
                                                <div></div>
                                            </div>
                                            <div>
                                                <div></div>
                                            </div>
                                        </uni-resize-sensor>
                                    </div>
                                </uni-rich-text>
                                <uni-rich-text data-v-51130a2d="">
                                    <div style="position: relative;"><p data-v-51130a2d="" style=""><strong
                                                data-v-51130a2d="" style="">You can invite friends to register and
                                                recharge to become a platform agent. Agents can get additional commission
                                                rewards from the platform. The commission rewards are divided into three levels
                                                of income commission rewards. The income commission rewards are: 40% for the
                                                first level, 7% for the second level, and 3% for the third level.</strong></p>
                                        <uni-resize-sensor>
                                            <div>
                                                <div></div>
                                            </div>
                                            <div>
                                                <div></div>
                                            </div>
                                        </uni-resize-sensor>
                                    </div>
                                </uni-rich-text>
                                <uni-rich-text data-v-51130a2d="">
                                    <div style="position: relative;"><p data-v-51130a2d="" style=""><br
                                                data-v-51130a2d="" style=""></p>
                                        <uni-resize-sensor>
                                            <div>
                                                <div></div>
                                            </div>
                                            <div>
                                                <div></div>
                                            </div>
                                        </uni-resize-sensor>
                                    </div>
                                </uni-rich-text>
                                <uni-rich-text data-v-51130a2d="">
                                    <div style="position: relative;"><p data-v-51130a2d="" style=""><strong
                                                data-v-51130a2d="" style="">You can also share links on YouTube,
                                                Telegram or other various social media platforms to grow your team and earn more
                                                commissions.</strong></p>
                                        <uni-resize-sensor>
                                            <div>
                                                <div></div>
                                            </div>
                                            <div>
                                                <div></div>
                                            </div>
                                        </uni-resize-sensor>
                                    </div>
                                </uni-rich-text>
                            </uni-view>
                        </uni-view>
                    </uni-view>
                    <uni-view data-v-2bfad2ee="" style="height: 86px;"></uni-view>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
        <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-5281eed3.31e42df1.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-3cade526.7c0d8bb4.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css">
    
    <?php echo $__env->make('app.layout.manu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</uni-app>
</body>
</html>
<?php /**PATH /home/hellocod/v1.hellocoder.xyz/resources/views/app/main/team/index.blade.php ENDPATH**/ ?>