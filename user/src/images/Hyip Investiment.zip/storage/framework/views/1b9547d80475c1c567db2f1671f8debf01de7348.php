<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <link rel="icon" href="<?php echo e(asset('public')); ?>/NorthernStar/favicon.ico">
    <title><?php echo e(env('APP_NAME')); ?></title>
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-bc432452.a23a20eb.css" rel="prefetch">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="preload" as="style">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-vendors.85d09471.css" rel="stylesheet">
    <link href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/app.53982ac3.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/NorthernStar/dist/css/chunk-8be1b236.bb942f25.css">
    <style>
        select#methods {
            width: 100%;
            padding: 10px 0;
            border: 1px solid #310947;
            border-radius: 6px;
        }
    </style>
</head>

<body class="">
<div id="app">
    <div id="nava"></div>
    <div data-v-434e8384="" class="rechargepage">
        <div data-v-434e8384="" class="navboxi van-nav-bar van-hairline--bottom">
            <div class="van-nav-bar__content">
                <div class="van-nav-bar__left" onclick="window.location.href='<?php echo e(route('dashboard')); ?>'"><i
                        class="van-icon van-icon-arrow-left van-nav-bar__arrow"></i>
                </div>
                <div class="van-nav-bar__title van-ellipsis">Recharge</div>
            </div>
        </div>
        <section data-v-434e8384="" class="section-box">
            <div data-v-434e8384="" class="topbalace flex">
                <div data-v-434e8384="" class="lefti"><span data-v-434e8384="">Total balance</span>
                    <p data-v-434e8384=""><?php echo e(price(auth()->user()->balance)); ?></p></div>
                <div data-v-434e8384="" class="righti"><img data-v-434e8384=""
                                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAAA6CAYAAAA9Qj4fAAAAAXNSR0IArs4c6QAABiFJREFUeF7tnFuIVWUUx39rHzQ1TSksp+zGdHuYXqSHoAhMk3rooQcfAoUaH5Iw3yqjTESiO4QM4Uv24ECYD1EJimmCcyYMxILmISsZR52LjtpxvMzlOHvFt8/FOcc5c779nb1nC+0PztNe67/W/p+11/d967sIMTQ9yCxm0IJkWkCbURYjuhC824BbiiZHwR9CZRDhNMhxdLyLPF2ylJEo3FKYBbQUf83AYmAhUOUHQ8AgGD84DnSZnxCNHxPfRaJ4MYOhWeahLEe8ZSBLQGe6YcsY6FHUP4CwX57mUhgchXnAcmAZsARw9IMx4ChwANgvhPOjls8NE66dNON7q0BWIFqK3jAc1ZZVGQXdh+e3y1NB5NVsCiaCVwErJnxF0fgBo8A+oF0KX4BzcyZcD9GE561HZBmqnrMHNooiPqoH8P2t8gz9E1UUmoD1xYiO1w/wixG/Vaj0w+Y1jExowvUIMxjOrEb8VhCTI6ex6QjqbWf2+A6eCMyuBlop5OrpbKaP2Q7sEMiHMRyKcD3MYq55HwGPhTESuewYx1njQ3eQRpJsfwIbpNDZWjVrwjXLUkQ2oTLXCjkuoSvM5TxNDCts1346uRyXKUtcY3+zwEEbeSvC9ZfMSnzehJhzdT2Ph1jAv9yFFlOhouzUM+zWXD3VmJ+b3P6pwK56duoSrtnMGmAtaF3ZesYaep7jDnLBGLqyKbBbB9mp5xvCb1zZeLJN4KupoKYksRjZbyVOtonsCyyq+SLmVXfqwE0Q6caTT6aK9JqEBzmbzMeJpxGTs89xTzmN1GLdpJdtfu9NkNNNenm7Vk6flPBgNDIu7Yl3kNeYQR8P4JOx+uJHdZz39QS94YZqVtjhhExHumqy0csNhAfj7BHv68SHfqZj7Od+xkKOsU/rCBu1hzzm806ymSHjq9Xj9BsJ78i0Ivp6kp4Gtmt1kjaO/aCDfJt4J2o8/VIKE6RyqyC8MF2XXdM/g6xi0aSSXh5EcZuq59Vng3ZzJvHUYmakKyeWASoJz3ofAs/ZBFGsMme5m6tBCdW9/aZDfK597gCRaf4k8E4JrUx4UPUj803shah675FnJn1BdDc67lc2+t10B2XWJJsZtbxcqjJeJ7zD24TwYpKeBbbPsYjLLIjEj8Oao00HIsFqDORHgc0GIiC8sHiQ2Rt5PTuskz4ep3jIOXdX28vj84b/D5eDsmqSzdTTnzeLGAXCO3gJ8d5N0qPA9iXmB4WpKFu7389eLkYJ6Yj1gcB3xQj32oAnHYGiUxvgXka4NTpA4JheYYueihTTDeywwDopLPhmfnZfg3SzfoOW6SRP8nBk6aRk4Bo+r/l/M5r4RMh03s+KZs3aibctItrcYYaZwxnucweYQvMz/yS/czUW7HCga0U7M6+gui6cXgzSOW4nx50xIMP3epZdeiEW7HCgbaKd3haUF8LpxSA9SBNXmB8DMhzRi3yhFYvPsdipD7pHNBsUqh6vLxuzRF9QqJodi5UTOsx72hMLdjjQP0Q7ZTcqtYv74QDdpU/TjKmhxNFymmedNrSfJCK3BkSzmQ7QeCIrjJc9PBL5CKVkfwyfVv+vMO7EJDtsOs1fUbUr8MfkRQDbw6MR1E8m99CsBq32j8XpviX2eEq4JVMRiQWEH0J1TkSA7jD/j5RyNe003UPERdN0mumw0IU5Rx0zLEwnPo7kuajtSaf2LrS567SlxSt38lw016blWRfa3HQK5Vmjq9l0AcKNw1BahQWIgPB0iS0Uc47CE5fY0kVkRxJt1SoXkQtRnm6TsGXPQa5ym0RAeLoRyIFHK5XJNwIVO890q5sVh6GEJt/qFhCebuYMxaSF8NSbOQu5PN2ubEGkrcjU25UDwtMN+bZk1pOz25AfkJ4eOalHZr3n9kdOSkjpoap6nNZ8Hv5QVZn0woHY9NigPffuxwavR3p6MNaS78YPxlZFenr0uzbz0R39rsjp6eUGk1Ee/eUGZdLT6zuqCY/v+o4y6ekFNYaK6bmgZuLfm17BNE1XMFV/U+klY5ZjmKJYo2chy9bSa/TsiI+M8Ip0U+uiSPXmI8V7BJUxxL+Y0EWRZuN/6T5Ds7hrTrlNy0WR/wEBuClTcvDPSwAAAABJRU5ErkJggg=="
                                                            alt="" class="imgui">
                    <div data-v-434e8384="" class="recordi"
                         onclick="window.location.href='<?php echo e(route('recharge.history')); ?>'"><p data-v-434e8384="">Record</p>
                        <img data-v-434e8384=""
                             src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAAQCAYAAADwMZRfAAAAAXNSR0IArs4c6QAAAR5JREFUOE+11E9LV0EUxvHPsy4kQkICSSIQkkBo0ULQyqQ27VtFb8gX4ZuQEPMPBC2CIFCEoE0EEiIR4vrI/LjF9bq8dnYz55nvPGfOzKSqdnELr5L8MoiqWscbvE7yZZhv41TVARZwiGdJTvrCqtrAW5xiNcnXIahB7mEPc2iCJmwLJlFVN7CJZbQNnidpG/+LdML7HWgWzfKLJL97oJt4jyW0kpvjo7/5CaQDPcA+7uIz1pL86eWnsIUnOMbTJN8mZzKof75zNINPeJnkrAdqDdjGY/zsQN8vQTpHD9E6dgcfu66d90C38QGL+IGVK5AO9Ag7mMZGkncDx22+5Zvu4P9AqmpcOVU17mCralyLq2rcZbuWa39dD3D0V3ABy3+16wVi4e4AAAAASUVORK5CYII="
                             alt=""></div>
                </div>
            </div>
            <div data-v-434e8384="" class="listamout">
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 700)"> 700 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 1700)"> 1700 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 3600)"> 3600 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 7800)"> 7800 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 15800)"> 15800 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 27500)"> 27500 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 46800)"> 46800 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 67800)"> 67800 </p>
                <p data-v-434e8384="" class="amountItem" onclick="getAmount(this, 98200)"> 98200 </p>
            </div>
            <div data-v-434e8384="" class="input-box van-cell van-field">
                <div class="van-field__left-icon">
                    <div data-v-434e8384="" class="leftount"><p data-v-434e8384=""><?php echo e(currency()); ?>.</p><span
                            data-v-434e8384=""></span></div>
                </div>
                <div class="van-cell__value van-cell__value--alone van-field__value">
                    <div class="van-field__body"><input type="tel" inputmode="numeric"
                                                        placeholder="Please enter the recharge amount"
                                                        name="amount"
                                                        id="amount"
                                                        class="van-field__control"></div>
                </div>
            </div>
            <div data-v-434e8384="" class="input-box van-cell van-field">
                <div class="van-cell__value van-cell__value--alone van-field__value">
                    <div class="van-field__body">
                        <label for="">Payment Channel</label>
                        <select name="methods" id="methods">
                            <?php $__currentLoopData = \App\Models\PaymentMethod::where('status', 'active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($element->id); ?>"><?php echo e($element->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </section>
        <p data-v-434e8384="" class="methodi">Recharge rules</p>
        <p data-v-434e8384="" class="textui">1. The minimum deposit amount is <?php echo e(price(300)); ?><br><br> 2. If the account
            has not
            been received within half an hour after the successful recharge, please contact customer service in time,
            and send us the account number and proof of successful payment.<br><br> 3. Do not save the previous
            receiving account for transfer. The recharge receipt must match the payment amount. Avoid payment
            errors.<br><br> 4. Do not transfer money to strangers, recharge must be completed in the application.</p>
        <button data-v-434e8384="" class="btnrech" onclick="submitDeposit()">Recharge</button>
    </div>
</div>
<div class="loader" style="
    position: fixed;
    display: none;
    top: 50%;
    z-index: 99;
    width: 143px;
    border-radius: 15px;
    overflow: hidden;
    left: 50%;
    transform: translate(-50%, -50%);
">
    <img src="<?php echo e(asset('public/loader.webp')); ?>" style="width: 100%;" alt="">
</div>
<?php echo $__env->make('alert-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function getAmount(_this, amount) {
        var elements = document.querySelectorAll('.amountItem');
        for (let i = 0; i < elements.length; i++) {
            if (elements[i].classList.contains('ui-active')) {
                elements[i].classList.remove('ui-active')
            }
        }
        _this.classList.add('ui-active')
        document.querySelector('input[name="amount"]').value = amount;
    }

    function submitDeposit() {
        var amount = document.getElementById('amount').value;
        var methods = document.querySelector('select[name="methods"]').value;
        if (methods == '') {
            message("Select payment channel");
            return 0;
        }

        if (amount < 1) {
            message("Enter Amount");
            return 0;
        }

        window.location.href = '<?php echo e(url('user/payment')); ?>' + "/" + amount + "/" + methods
    }
</script>
</body>
</html>
<?php /**PATH /home/hellocod/v1.hellocoder.xyz/resources/views/app/main/deposit/index.blade.php ENDPATH**/ ?>