<html lang="zh-CN" style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(env('APP_NAME')); ?> | Register</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="<?php echo e(asset('public')); ?>/static/index.2da1efab.css">
    <link rel="stylesheet" href="<?php echo e(asset('public')); ?>/static/register.css">
    <style>
        .register[data-v-1f33345e] {
            min-height: 100vh;
            position: relative;
            z-index: 1;
            padding: 25px 0 0;
            background: url(<?php echo e(asset('public')); ?>/bg.png) no-repeat;
            background-size: 100% 100%
        }
    </style>
</head>
<body class="uni-body pages-login-register">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/login/register">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-1f33345e="" class="register">
                    <uni-view data-v-1f33345e="" style="margin-top: 30px;">
                        <img data-v-1f33345e=""
                             src="<?php echo e(asset('public')); ?>/static/img/EnterOTP-amico@2x.19f95e47.png"
                             alt=""
                             style="width: 200px; height: 200px;">
                    </uni-view>
                    <div data-v-1f33345e="" class="register-container form-box">
                        <form action="<?php echo e(url('register')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div data-v-1f33345e="" class="login-title-container"><h3 data-v-1f33345e="">REGISTER</h3>
                                <p data-v-1f33345e="">Join us, Take control of wealth and life.</p></div>
                            <p data-v-1f33345e="" class="phonei">Phone</p>
                            <div data-v-1f33345e="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-1f33345e=""
                                     class="input-box van-cell van-cell--large van-field van-field--label-left">
                                    <div data-v-1f33345e="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-1f33345e="" class="van-field__body"><img data-v-1f33345e=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/phone.png"
                                                                                             style="width: 21px; height: 26px; margin-right: 14px;">
                                            <uni-input data-v-1f33345e="" class="van-field__control">
                                                <div class="uni-input-wrapper">
                                                    <input maxlength="10" step="" autocomplete="off"
                                                           placeholder="Enter phone number"
                                                           name="phone"
                                                           inputmode="decimal" type="number" class="uni-input-input"></div>
                                            </uni-input>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p data-v-1f33345e="" class="phonei">Password</p>
                            <div data-v-1f33345e="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-1f33345e=""
                                     class="input-box van-cell van-cell--large van-field van-field--label-left">
                                    <div data-v-1f33345e="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-1f33345e="" class="van-field__body"><img data-v-1f33345e=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/lock.png"
                                                                                             style="width: 21px; height: 21px; margin-right: 14px;"><input
                                                data-v-1f33345e="" placeholder="Enter your password" type="password"
                                                name="password"
                                                class="van-field__control van-icon-closed-eye">
                                            <div data-v-1f33345e="" class="van-field__right-icon"
                                                 style="color: rgb(229, 94, 80); width: 12px; height: 25px;" onclick="eye()"><i
                                                    data-v-1f33345e="" class="van-icon  van-icon-closed-eye"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p data-v-1f33345e="" class="phonei">Confirm password</p>
                            <div data-v-1f33345e="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-1f33345e=""
                                     class="input-box van-cell van-cell--large van-field van-field--label-left">
                                    <div data-v-1f33345e="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-1f33345e="" class="van-field__body"><img data-v-1f33345e=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/lock.png"
                                                                                             style="width: 21px; height: 21px; margin-right: 14px;"><input
                                                data-v-1f33345e="" placeholder="Enter your password" type="password"
                                                name="confirm_password"
                                                class="van-field__control van-icon-closed-eye">
                                            <div data-v-1f33345e="" class="van-field__right-icon"
                                                 style="color: rgb(229, 94, 80); width: 12px; height: 25px;" onclick="eye2()"><i
                                                    data-v-1f33345e="" class="van-icon  van-icon-closed-eye"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php $code = rand(0,9999);?>
                            <p data-v-1f33345e="" class="phonei">code</p>
                            <div data-v-1f33345e="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-1f33345e=""
                                     class="input-box van-cell van-cell--large van-field van-field--label-left">
                                    <div data-v-1f33345e="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-1f33345e="" class="van-field__body"><img data-v-1f33345e=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/camera.png"
                                                                                             style="width: 21px; height: 21px; margin-right: 14px;">
                                            <uni-input data-v-1f33345e="" class="van-field__control">
                                                <div class="uni-input-wrapper">
                                                    <input maxlength="140" step="" autocomplete="off"
                                                           placeholder="Enter graphic verification code"
                                                           type="number" name="code" class="uni-input-input"></div>
                                            </uni-input>
                                            <div data-v-1f33345e="" class="van-field__right-icon" style="position: relative;">
                                                <uni-image data-v-1f33345e="" style="width: 90px; height: 30px;">
                                                    <div style="background-image: url(<?php echo e(asset('public')); ?>/360_F_31887307_OoJwTcy1M3hQJgoOXqwQ5AXMbjAVQepf.jpg); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;">
                                                        <div style="text-align: center;align-items: center;letter-spacing: 10px;font-style: italic"><?php echo e($code); ?></div>
                                                    </div>
                                                </uni-image>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <p data-v-1f33345e="" class="phonei">Invitation Refer Code</p>
                            <div data-v-1f33345e="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-1f33345e=""
                                     class="input-box van-cell van-cell--large van-field van-field--label-left">
                                    <div data-v-1f33345e="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-1f33345e="" class="van-field__body"><img data-v-1f33345e=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/lock.png"
                                                                                             style="width: 21px; height: 21px; margin-right: 14px;"><input
                                                data-v-1f33345e="" placeholder="Invite Code[optional]" type="text"
                                                name="ref_by"
                                                value="<?php echo e(isset($ref_by) && !empty($ref_by) && $ref_by != null ? $ref_by : ''); ?>"
                                                class="van-field__control van-icon-closed-eye">
                                            <div data-v-1f33345e="" class="van-field__right-icon"
                                                 style="color: rgb(229, 94, 80); width: 12px; height: 25px;"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div data-v-1f33345e="" class="sign-up">
                                <div data-v-1f33345e="" class="checkbox-container">
                                    <div data-v-1f33345e="" role="checkbox" tabindex="0" aria-checked="true"
                                         class="van-checkbox">
                                        <div data-v-1f33345e=""
                                             class="van-checkbox__icon van-checkbox__icon--square  van-checkbox__icon--checked">
                                            <i data-v-1f33345e="" class="van-icon van-icon-success isagree"></i></div>
                                        <span data-v-1f33345e="" class="van-checkbox__label">Remember Account</span></div>
                                </div>
                            </div>
                            <uni-button data-v-1f33345e=""
                                        onclick="login()"
                                        class="registerBtn van-button van-button--primary van-button--normal van-button--block">
                                <div data-v-1f33345e="" class="van-button__content"><span data-v-1f33345e=""
                                                                                          class="van-button__text">Register</span>
                                </div>
                            </uni-button>
                            <uni-button data-v-1f33345e=""
                                        onclick="window.location.href='<?php echo e(url('login')); ?>'"
                                        class="registerBtnBot van-button van-button--primary van-button--normal van-button--block">
                                <div data-v-1f33345e="" class="van-button__content"><span data-v-1f33345e=""
                                                                                          class="van-button__text">Log in</span>
                                </div>
                            </uni-button>
                        </form>
                    </div>
                    <div data-v-1f33345e="" class="van-overlay" style="background: rgba(0, 0, 0, 0); display: none;">
                        <div data-v-1f33345e="" class="loading-box-h">
                            <div data-v-1f33345e="" class="van-loading van-loading--spinner van-loading--vertical"><span
                                    data-v-1f33345e="" class="van-loading__spinner van-loading__spinner--spinner"
                                    style="width: 30px; height: 30px;"><i data-v-1f33345e=""></i><i
                                        data-v-1f33345e=""></i><i data-v-1f33345e=""></i><i data-v-1f33345e=""></i><i
                                        data-v-1f33345e=""></i><i data-v-1f33345e=""></i><i data-v-1f33345e=""></i><i
                                        data-v-1f33345e=""></i><i data-v-1f33345e=""></i><i data-v-1f33345e=""></i><i
                                        data-v-1f33345e=""></i><i data-v-1f33345e=""></i></span><span data-v-1f33345e=""
                                                                                                      class="van-loading__text">Loading...</span>
                            </div>
                        </div>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
<?php echo $__env->make('alert-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    var varCode = '<?php echo e($code); ?>';
    function login(){
        let code = document.querySelector('input[name="code"]').value;
        if (code != varCode){
            message('Incorrect Verification code')
            return true;
        }
        document.querySelector('.van-overlay').style.display='block';
        document.querySelector('form').submit();
    }
</script>
<script>
    function eye(){
        var pass = document.querySelector('input[name="password"]');
        if (pass.type == 'password'){
            pass.type = 'text'
        }else {
            pass.type = 'password'
        }
    }
    function eye2(){
        var pass = document.querySelector('input[name="confirm_password"]');
        if (pass.type == 'password'){
            pass.type = 'text'
        }else {
            pass.type = 'password'
        }
    }
</script>
</body>
</html>
<?php /**PATH /home/evboxmoz/nissanrentalsrtg234.online/resources/views/app/auth/registration.blade.php ENDPATH**/ ?>