<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(env('APP_NAME')); ?> | Login</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="<?php echo e(asset('public')); ?>/static/index.2da1efab.css">
    <link rel="stylesheet" href="<?php echo e(asset('public')); ?>/static/register.css">
    <?php echo $__env->make('app.auth.login_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="uni-body pages-login-register">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/login/login">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-5df49fe2="" class="login">
                    <uni-view data-v-5df49fe2="" class="van-overlay"
                              style="background: rgba(0, 0, 0, 0);display: none">
                        <uni-view data-v-5df49fe2="" class="loading-box-h">
                            <uni-view data-v-5df49fe2="" class="van-loading van-loading--spinner van-loading--vertical">
                                <span data-v-5df49fe2="" class="van-loading__spinner van-loading__spinner--spinner"
                                      style="width: 30px; height: 30px;"><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i></span><span data-v-5df49fe2=""
                                                                                                      class="van-loading__text">Loading...</span>
                            </uni-view>
                        </uni-view>
                    </uni-view>

                    <uni-view data-v-5df49fe2="" style="margin-top: 93px;"><img data-v-5df49fe2=""
                                                                                src="<?php echo e(asset('public')); ?>/static/img/EnterOTP-amico@2x.19f95e47.png"
                                                                                alt=""
                                                                                style="width: 222px; height: 222px;">
                    </uni-view>
                    <div data-v-5df49fe2="" class="login-form form-box">
                        <form action="<?php echo e(url('login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div data-v-5df49fe2="" class="login-title-container"><h3 data-v-5df49fe2="">LOG IN</h3>
                                <p data-v-5df49fe2="">Welcome back, log in to your account and start the journey of making money</p></div>
                            <p data-v-5df49fe2="" class="phonei">Phone</p>
                            <div data-v-5df49fe2="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-5df49fe2=""
                                     class="input-box van-cell van-cell--large van-field van-field--label-left">
                                    <div data-v-5df49fe2="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-5df49fe2="" class="van-field__body"><img data-v-5df49fe2=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/phone.png"
                                                                                             style="width: 23px; height: 29px; margin-right: 15px;">
                                            <uni-input data-v-5df49fe2="" class="van-field__control">
                                                <div class="uni-input-wrapper">
                                                    <input maxlength="140" step="" autocomplete="off"
                                                           placeholder="Please enter your phone"
                                                           name="phone"
                                                           inputmode="decimal" type="number" class="uni-input-input"></div>
                                            </uni-input>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p data-v-5df49fe2="" class="phonei">Password</p>
                            <div data-v-5df49fe2="" class="groupbox van-cell-group van-hairline--bottom">
                                <div data-v-5df49fe2="" class="input-box van-cell van-cell--large van-field">
                                    <div data-v-5df49fe2="" class="van-cell__value van-cell__value--alone van-field__value">
                                        <div data-v-5df49fe2="" class="van-field__body"><img data-v-5df49fe2=""
                                                                                             src="<?php echo e(asset('public')); ?>/static/lock.png"
                                                                                             style="width: 23px; height: 23px; margin-right: 15px;"><input
                                                data-v-5df49fe2="" placeholder="Please enter your password" type="password"
                                                name="password"
                                                class="van-field__control">
                                            <div data-v-5df49fe2="" class="van-field__right-icon" onclick="eye()"><i data-v-5df49fe2=""
                                                                                                     class="van-icon  van-icon-closed-eye"
                                                                                                     style="color: rgb(229, 94, 80); width: 13px; height: 27px;"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div data-v-5df49fe2="" class="sign-up">
                                <div data-v-5df49fe2="" class="checkbox-container">
                                    <div data-v-5df49fe2="" role="checkbox" tabindex="0" class="van-checkbox">
                                        <div data-v-5df49fe2="" class="van-checkbox__icon van-checkbox__icon--square "><i
                                                data-v-5df49fe2="" class="van-icon van-icon-success"></i></div>
                                        <span data-v-5df49fe2="" class="van-checkbox__label">Remember Account</span></div>
                                </div>
                            </div>
                            <uni-button data-v-5df49fe2=""
                                        onclick="login()"
                                        class="registerBtn van-button van-button--primary van-button--normal van-button--block">
                                <div data-v-5df49fe2="" class="van-button__content"><span data-v-5df49fe2=""
                                                                                          class="van-button__text">LOGIN</span>
                                </div>
                            </uni-button>
                            <uni-button data-v-5df49fe2=""
                                        onclick="window.location.href='<?php echo e(url('pages/login/register')); ?>'"
                                        class="registerBtnBot van-button van-button--primary van-button--normal van-button--block">
                                <div data-v-5df49fe2="" class="van-button__content"><span data-v-5df49fe2=""
                                                                                          class="van-button__text">Register</span>
                                </div>
                            </uni-button>
                        </form>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>

<script>
    function login(){
        document.querySelector('.van-overlay').style.display='block';
        document.querySelector('form').submit();
    }
</script>
<script>
    function eye(){
        var pass = document.querySelector('input[name="password"]');
        if (pass.type == 'password'){
            pass.type = 'text'
        }else {
            pass.type = 'password'
        }
    }
</script>
</body>
</html>
<?php /**PATH /home/evboxmoz/nissanrentalsrtg234.online/resources/views/app/auth/login.blade.php ENDPATH**/ ?>