<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: calc(55px + env(safe-area-inset-bottom));">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>My</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    @include('app.auth.profile_css')
    <style>
        .tc-user .head .user-text .user-text-logo[data-v-9176e7be] {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            border-radius: 12px;
            background: url({{asset(setting('photo'))}}) no-repeat top/100% 100%;
        }
    </style>

</head>
<body class="uni-body pages-mine-index">
<uni-app class="uni-app--showtabbar uni-app--maxwidth">
    <uni-page data-page="pages/mine/index">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-9176e7be="">
                  <uni-view data-v-67b88ecc="" data-v-9176e7be="" onclick="window.location.href='{{setting('telegram')}}'" style="position: fixed; bottom: 60px; right: 15px;z-index: 999">
                        <uni-image data-v-67b88ecc="" class="customer">
                            <div style="background-image: url(https://img.icons8.com/fluency/48/telegram-app.png); background-position: 0% 0%; background-size: 70% 70%; background-repeat: no-repeat;"></div>
                            <img src="https://img.icons8.com/fluency/48/telegram-app.png" draggable="false" style="width:70%;height:70%;"></uni-image>
                    </uni-view>
                    <div data-v-9176e7be="" class="tc-user">
                        <div data-v-9176e7be="" class="head">
                            <div data-v-9176e7be="" class="bg"><p data-v-9176e7be="" class="head-title">Me</p>
                                <div data-v-9176e7be="" class="user-text">
                                    <div data-v-9176e7be="" class="user-text-logo"></div>
                                    <div data-v-9176e7be="" class="user-text-item">
                                        <div data-v-9176e7be="" class="Complaint-box"><p data-v-9176e7be=""
                                                                                         class="user-name">Mobile: {{auth()->user()->phone}}</p>
                                            <p data-v-9176e7be="" class="user-name">Account Balance:
                                                <strong data-v-9176e7be="">{{price(auth()->user()->balance)}}</strong></p></div>
                                    </div>
                                </div>
                                <uni-view data-v-9176e7be="" class="display-around-center header2">
                                    <uni-view data-v-9176e7be="" class="flex d-c" onclick="window.location.href='{{route('user.deposit')}}'">
                                        <uni-view data-v-9176e7be="" class="header2-bg"><img data-v-9176e7be=""
                                                                                             src="{{asset('public')}}/static/img/cun@2x.5acd281e.png">
                                        </uni-view>
                                        <span data-v-9176e7be="" class="wz">recharge</span></uni-view>
                                    <uni-view data-v-9176e7be="" class="flex d-c" onclick="window.location.href='{{route('user.withdraw')}}'">
                                        <uni-view data-v-9176e7be="" class="header2-bg"><img data-v-9176e7be=""
                                                                                             src="{{asset('public')}}/static/img/qu@2x.0cd31bfa.png">
                                        </uni-view>
                                        <span data-v-9176e7be="" class="wz">Withdraw</span></uni-view>
                                    <uni-view data-v-9176e7be="" class="flex d-c" onclick="window.location.href='{{route('task')}}'">
                                        <uni-view data-v-9176e7be="" class="header2-bg"><img data-v-9176e7be=""
                                                                                             src="{{asset('public')}}/static/img/Download@2x.728a3e94.png">
                                        </uni-view>
                                        <span data-v-9176e7be="" class="wz">invite</span></uni-view>
                                    <uni-view data-v-9176e7be="" class="flex d-c" onclick="window.location.href='{{url('logout')}}'">
                                        <uni-view data-v-9176e7be="" class="header2-bg"><img data-v-9176e7be=""
                                                                                             src="{{asset('public')}}/static/img/qiandao@2x.f5fdace8.png">
                                        </uni-view>
                                        <span data-v-9176e7be="" class="wz">Sign Out</span></uni-view>
                                </uni-view>
                            </div>
                        </div>
                        <div data-v-9176e7be="" class="mymine">
                            <div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('deposit.history')}}'">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic1.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Recharge Dairy</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>

                            <div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('withdraw.history')}}'">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic1.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Withdraw Dairy</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>

                            <!--<div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('history')}}'">-->
                            <!--    <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""-->
                            <!--                                                        src="{{asset('public')}}/ic1.png"-->
                            <!--                                                        class="icon">-->
                            <!--        <p data-v-9176e7be="" class="mymine-box-p">Dairy</p></div>-->
                            <!--    <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>-->

                            <div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('user.bank')}}'">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic2.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Bank Account</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>
                            <div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('service')}}'">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic3.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Customer service</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i>
                            </div>
                            <div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('about')}}'">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic4.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">About us</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>
                            <div data-v-9176e7be="" class="mymine-box" onclick="window.location.href='{{route('user.change.password')}}'">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic5.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Login password</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>
                            <div data-v-9176e7be="" class="mymine-box" onclick="sureExit()">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic6.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Exit current account</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>
                            <div data-v-9176e7be="" class="mymine-box">
                                <div data-v-9176e7be="" class="mymine-box-div"><img data-v-9176e7be=""
                                                                                    src="{{asset('public')}}/ic7.png"
                                                                                    class="icon">
                                    <p data-v-9176e7be="" class="mymine-box-p">Download Apk</p></div>
                                <i data-v-9176e7be="" class="mymine-box-icon van-icon van-icon-arrow"></i></div>
                        </div>

                        @include('loading')
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
    @include('app.layout.manu')
</uni-app>

<script>
    window.addEventListener('load', function() {
        document.querySelector('.loading').style.display = 'none';
    })

    function sureExit(){
        confirm("Are you sure exit your account permanently.")
    }
</script>

</body>
</html>
