<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Product Detail</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/static/details.css">
    <style>
        .order-grabbing .grabbing-dialog .progress-bg[data-v-9d7f1624] {
            width: 92%;
            height: 9px;
            margin: 0 auto;
        }
    </style>
    <style>
        .top[data-v-9d7f1624] {
            height: 287px;
            background: url("{{asset('public/static/bbe219ca10cd6f5f4e8fe4eafbf891a8.png')}}");
            color: #fff;
            background-size: cover;
        }
    </style>
</head>
<body class="uni-body pages-steady-detail">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/steady/detail">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-9d7f1624="">
                    <div data-v-9d7f1624="" class="order-grabbing">
                        <uni-view data-v-67b88ecc="" data-v-9176e7be="" onclick="window.location.href='https://t.me/SezVip_880'" style="position: fixed; bottom: 60px; right: 15px;z-index: 999">
                        <uni-image data-v-67b88ecc="" class="customer">
                            <div style="background-image: url(https://img.icons8.com/fluency/48/telegram-app.png); background-position: 0% 0%; background-size: 70% 70%; background-repeat: no-repeat;"></div>
                            <img src="https://img.icons8.com/fluency/48/telegram-app.png" draggable="false" style="width:70%;height:70%;"></uni-image>
                    </uni-view>
                        <div data-v-9d7f1624="" class="order-container">
                            <div data-v-9d7f1624="" class="teamtitle display-between-center">
                                <p data-v-9d7f1624="" onclick="window.location.href='{{route('dashboard')}}'">
                                    <img style="width: 20px;height: 20px;" src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                                </p>
                                <p data-v-9d7f1624="">Device</p>
                                <p data-v-9d7f1624=""
                                   style="width: 19px; height: 19px; line-height: 19px; color: rgb(232, 97, 97); font-size: 11px;">
                                    {{currency()}}</p></div>
                            <div data-v-9d7f1624="" class="order-container-box">
                                <div data-v-9d7f1624="" class="order-rule">
                                    <div data-v-9d7f1624="" class="rule-info-box"><img data-v-9d7f1624=""
                                                                                       src="{{asset($package->photo)}}"
                                                                                       class="van-image__img">
                                        <p data-v-9d7f1624="" class="order-title">{{$package->title}}</p>
                                        <div data-v-9d7f1624="" class="rule-info"><span data-v-9d7f1624="">Invest amount:</span>
                                            <p data-v-9d7f1624="">{{price($package->price)}}</p></div>
                                        <div data-v-9d7f1624="" class="rule-info"><span data-v-9d7f1624="">Hourly income:</span>
                                            <p data-v-9d7f1624="">{{currency()}}{{number_format(($package->commission_with_avg_amount / $package->validity) / 24 , 3)}}</p></div>
                                        <div data-v-9d7f1624="" class="rule-info"><span
                                                data-v-9d7f1624="">Daily income:</span>
                                            <p data-v-9d7f1624="">{{price(($package->commission_with_avg_amount / $package->validity))}}</p></div>
                                        <div data-v-9d7f1624="" class="rule-info"><span data-v-9d7f1624="">Total revenue:</span>
                                            <p data-v-9d7f1624="">{{price(($package->commission_with_avg_amount))}}</p></div>
                                        <div data-v-9d7f1624="" class="rule-info"><span
                                                data-v-9d7f1624="">Invest term:</span>
                                            <p data-v-9d7f1624="">{{$package->validity}}days</p></div>
                                        <div data-v-9d7f1624="" class="rule-info"><span data-v-9d7f1624="">Invertible quantity</span>
                                            <p data-v-9d7f1624="">{{rand(0,9)}}/{{rand(0,999)}}</p></div>
                                    </div>
                                </div>
                                <div data-v-9d7f1624="" class="order-info"><span data-v-9d7f1624=""></span><span
                                        data-v-9d7f1624=""></span></div>

                                <?php
                                $pa = \App\Models\Purchase::where('user_id', auth()->id())->where('package_id', $package->id)->where('status', 'active')->first();
                                ?>
                                @if($pa)
                                    <div data-v-9d7f1624="" class="order-btn" onclick="window.location.href='{{route('ordered')}}'">
                                        <uni-button data-v-9d7f1624="" class="van-button van-button--default van-button--normal">
                                            <div data-v-9d7f1624="" class="van-button__content">
                                                <span data-v-9d7f1624="" class="van-button__text">Check My Invest</span>
                                            </div>
                                        </uni-button>
                                    </div>
                                @else
                                    <div data-v-9d7f1624="" class="order-btn" onclick="buyPurchase()">
                                        <uni-button data-v-9d7f1624="" class="van-button van-button--default van-button--normal">
                                            <div data-v-9d7f1624="" class="van-button__content">
                                                <span data-v-9d7f1624="" class="van-button__text">Invest Now</span>
                                            </div>
                                        </uni-button>
                                    </div>
                                @endif
                                <div data-v-9d7f1624="" class=" order-btn" onclick="window.location.href='{{route('dashboard')}}'" style="justify-content: center; margin-top: 22px;">
                                    <div data-v-9d7f1624="" class="canceli">
                                        <span data-v-9d7f1624=""  class="canceli__text">Go Back</span>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div data-v-9d7f1624="" class="van-overlay loading" style="background: rgba(0, 0, 0, 0); display: block;">
                            <div data-v-9d7f1624="" class="loading-box-h">
                                <div data-v-9d7f1624="" class="van-loading van-loading--spinner van-loading--vertical">
                                    <span data-v-9d7f1624="" class="van-loading__spinner van-loading__spinner--spinner"
                                          style="width: 30px; height: 30px;"><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i>
                                    </span>
                                    <span data-v-9d7f1624="" class="van-loading__text">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
@include('alert-message')
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
    window.addEventListener('load', function() {
        document.querySelector('.loading').style.display = 'none';
    })

    function buyPurchase(){
        document.querySelector('.loading').style.display = 'block';
        $.ajax({
            url: "{{url('purchase/confirmation/')}}"+"/"+'{{$package->id}}',
            type: 'GET',
            dataType: 'json',
            success: function(res) {
                document.querySelector('.loading').style.display = 'none';
                message(res.message)
                window.location.href='{{route('ordered')}}'
            }
        });
    }
</script>
</body>
</html>
