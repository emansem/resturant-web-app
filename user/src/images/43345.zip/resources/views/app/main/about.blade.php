<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + calc(44px + env(safe-area-inset-top))); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>About Us</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <style>
        uni-view.box {
            width: 90%;
            margin: auto;
        }
        img {
            width: 100%;
        }
    </style>
</head>
<body class="uni-body pages-home-companyProfile">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/home/companyProfile">
        <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head" style="background-color: rgb(232, 97, 97); color: rgb(0, 0, 0);">
                <div class="uni-page-head-hd" onclick="window.location.href='{{route('profile')}}'">
                    <img style="width: 20px;height: 20px;" src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                    <div class="uni-page-head-ft"></div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;"> About Us</div>
                </div>
                <div class="uni-page-head-ft"></div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head>
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-b8ae78b0="">
                    <uni-view data-v-b8ae78b0="" class="top"></uni-view>
                    <uni-view data-v-b8ae78b0="" class="box">
                        <uni-view data-v-b8ae78b0="" class="font-size-28"
                                  style="color: rgb(51, 51, 51); line-height: 25px;">
                            <uni-view data-v-b8ae78b0=""><p class="p" align="justify" style="text-align: justify;">In
                                    the hot summer, finding a cool haven has become a necessary logic for every business and
                                    family. In order to meet the continuous and growing demand for refrigeration, Panasonic
                                    Refrigeration Equipment Co., Ltd., as a reset refrigeration equipment startup, brings
                                    you top refrigeration solutions. Sez Refrigeration Equipment Sales Co., Ltd. has joined
                                    forces to officially announce, And authorized its sole sales representative in
                                    India.</p>
                                <p class="p" align="justify" style="text-align: justify;"><img
                                        src="{{asset('public')}}/static/342a6440c64d740a57e0a27a7ea58532.jpg"
                                        alt="undefined"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">About Panasonic Refrigeration
                                    Equipment Corporation</p>
                                <p class="p" align="justify" style="text-align: justify;">With advanced technology and
                                    fine craftsmanship, Panasonic Refrigeration Equipment Company has always been a
                                    leader in the global refrigeration industry. Our product line is rich, ranging from
                                    large-scale refrigeration solutions to household portable air conditioners, to meet
                                    the dietary needs of different customers. With years of R&amp;D and market
                                    experience, Panasonic Refrigeration Equipment Company is committed to providing the
                                    highest quality, The most energy efficient product.</p>
                                <p class="p" align="justify" style="text-align: justify;"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">In order to better serve
                                    customers in this region, Panasonic Refrigeration Equipment Company proposed to
                                    choose Sez Refrigeration Equipment Sales Co., Ltd. as its officially authorized
                                    sales partner. Sez Refrigeration Equipment Sales Co., Ltd. has strong local market
                                    insights and a mature customer service system, which can quickly respond to customer
                                    needs and provide personalized consultation and support.</p>
                                <p class="p" align="justify" style="text-align: justify;"><img
                                        src="{{asset('public')}}/static/5e842749c5396f6529381687ed054a06.jpg"
                                        alt="undefined"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">Product advantages of
                                    Panasonic refrigeration equipment:</p>
                                <p class="p" align="justify" style="text-align: justify;"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">Energy-saving and efficient:
                                    Using the latest energy-saving technology, the air conditioner is stronger, consumes
                                    more power, and is more environmentally friendly.</p>
                                <p class="p" align="justify" style="text-align: justify;">Quiet operation: Enjoy a quiet
                                    cooling experience, providing a comfortable environment whether late at night or
                                    during breaks during the day.</p>
                                <p class="p" align="justify" style="text-align: justify;">Intelligent control: Easily
                                    manage everything in front of you through a customized control system, and
                                    smartphone remote control puts everything at your fingertips.</p>
                                <p class="p" align="justify" style="text-align: justify;">Durable: After strict quality
                                    inspection, each product is ensured to operate stably in the long term.</p>
                                <p class="p" align="justify" style="text-align: justify;"><img
                                        src="{{asset('public')}}/static/c4e00d4d25a57901ddcaf8c9b075db27.jpg"
                                        alt="undefined"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">special promotion</p>
                                <p class="p" align="justify" style="text-align: justify;">To celebrate the cooperation
                                    between Panasonic Refrigeration Equipment Company and Sez Refrigeration Equipment
                                    Sales Co., Ltd., you can now invest in purchasing any of our products online to get
                                    the income generated by the equipment, and you can also invite friends to invest and
                                    purchase products to get cash rewards.</p>
                                <p class="p" align="justify" style="text-align: justify;"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">Now let us immerse ourselves
                                    in the coolness brought to us by Panasonic Refrigeration Equipment Company and Sez
                                    Refrigeration Equipment Sales Co., Ltd. Whether it is a hot summer or a special
                                    environment that requires constant temperature, Sez Refrigeration Equipment Sales
                                    Co., Ltd. will be your most reliable partner.</p>
                                <p class="p" align="justify" style="text-align: justify;"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">Official
                                    website:https://sezvip.com&nbsp;</p>
                                <p class="p" align="justify" style="text-align: justify;"><br></p>
                                <p class="p" align="justify" style="text-align: justify;">Refrigeration has never been
                                    so sophisticated. Sez Refrigeration Equipment Sales Co., Ltd., your refrigeration
                                    expert!</p></uni-view>
                        </uni-view>
                    </uni-view>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
</body>
</html>
