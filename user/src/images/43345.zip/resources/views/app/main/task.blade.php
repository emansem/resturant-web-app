<html lang="zh-CN" style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: calc(55px + env(safe-area-inset-bottom));">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Invite</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    @include('app.auth.task_css')
    <style>
        .box .invite_f .bounsi .btncord .rightui .disbot[data-v-4ea766a0] {
            opacity: 1;
        }
    </style>
</head>
<body class="uni-body pages-home-invitation">
<uni-app class="uni-app--showtabbar uni-app--maxwidth">
    <uni-page data-page="pages/home/invitation">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-4ea766a0="" class="box">
                    <uni-view data-v-67b88ecc="" data-v-9176e7be="" onclick="window.location.href='https://t.me/SezVip_880'" style="position: fixed; bottom: 60px; right: 15px;z-index: 999">
                        <uni-image data-v-67b88ecc="" class="customer">
                            <div style="background-image: url(https://img.icons8.com/fluency/48/telegram-app.png); background-position: 0% 0%; background-size: 70% 70%; background-repeat: no-repeat;"></div>
                            <img src="https://img.icons8.com/fluency/48/telegram-app.png" draggable="false" style="width:70%;height:70%;"></uni-image>
                    </uni-view>
                    <div data-v-4ea766a0="" class="teamtitle "><p data-v-4ea766a0="">Task</p></div>
                    <div data-v-4ea766a0="" class="invite_f">
                        <div data-v-4ea766a0="" class="title"><span data-v-4ea766a0="">invite friends</span></div>
                        <uni-view data-v-4ea766a0="" class="bounsi">
                            <uni-view data-v-4ea766a0="" class="copyLink">
                                <uni-text data-v-4ea766a0=""><span>Invite Code：{{auth()->user()->ref_id}}</span></uni-text>
                                <uni-view data-v-4ea766a0="" class=" recebtn" onclick="copyCode('{{auth()->user()->ref_id}}')">copy</uni-view>
                            </uni-view>
                            <uni-view data-v-4ea766a0=""
                                      style="height: 2px; background: rgba(0, 0, 0, 0.3); margin: 0px 16px;"></uni-view>
                            <uni-view data-v-4ea766a0="" class="copyLink">
                                <uni-text data-v-4ea766a0=""><span>Invite Link：{{url('pages/login/register').'?invite='.auth()->user()->ref_id}}</span>
                                </uni-text>
                                <uni-view data-v-4ea766a0="" class=" recebtn" onclick="copyLink('{{url('pages/login/register').'?invite='.auth()->user()->ref_id}}')">copy</uni-view>
                            </uni-view>
                        </uni-view>
                    </div>
                    <div data-v-4ea766a0="" class="invite_f">
                        <div data-v-4ea766a0="" class="title tbg"><span data-v-4ea766a0="">invite friends to purchase equipment rewards</span>
                        </div>
                        <uni-view data-v-4ea766a0="" class="bounsi bounsi2">

                            @foreach(\App\Models\Task::get() as $key=>$element)

                                <?php
                                    $apply = \App\Models\TaskRequest::where('task_id', $element->id)->where('user_id', auth()->id())->where('status', '!=', 'rejected')->first();
                                ?>

                            <uni-view data-v-4ea766a0="">
                                <div data-v-4ea766a0="" class="bgc">
                                    <div data-v-4ea766a0="" class="toptitle"><p data-v-4ea766a0="" class="invitet"><span
                                                data-v-4ea766a0="">{{$key+1}} The
								investment amount is {{price($element->invest)}}, you will receive a bonus of
								{{price($element->bonus)}}.</span></p></div>
                                    <div data-v-4ea766a0="" class="finishow "><p data-v-4ea766a0="" class="schedule">
                                            <span data-v-4ea766a0="" style="width: 100%;"></span></p>
                                        <p data-v-4ea766a0="" class="jindu" style="left: 0%;">100%</p></div>
                                    <div data-v-4ea766a0="" class="finishow "><p data-v-4ea766a0="" class="schedule">
                                            <span data-v-4ea766a0="" style="width: 100%;"></span></p>
                                        <p data-v-4ea766a0="" class="jindu" style="left: 0%;">100%</p></div>
                                    <div data-v-4ea766a0="" class="btncord flex">
                                        <div data-v-4ea766a0="" class="obtained"><p data-v-4ea766a0="">{{price($element->bonus)}}</p><span
                                                data-v-4ea766a0="">Bonus</span></div>
                                        <div data-v-4ea766a0="" class="obtained"><p data-v-4ea766a0="">{{price($element->invest)}}</p><span
                                                data-v-4ea766a0="">investment</span></div>
                                        <div data-v-4ea766a0="" class="rightui">
                                            @if($apply)
                                                <uni-button data-v-4ea766a0="" class="recebtn disbot" style="opacity: 0.4;">Applied</uni-button>
                                            @else
                                                <uni-button data-v-4ea766a0="" class="recebtn disbot" onclick="applyes('{{$element->id}}')">Apply</uni-button>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </uni-view>
                            @endforeach
                            <uni-view data-v-4ea766a0="" class="bgc" style="text-align: left; font-size: 8px;"><p
                                    data-v-4ea766a0="" style="margin-bottom: 5px;"><strong data-v-4ea766a0="">Why create
                                        a team?</strong></p>
                                <p data-v-4ea766a0="" style="color: rgb(229, 94, 80); font-size: 10px;">If you want to
                                    make more money, you can invite your
                                    friends to join us.
                                    When friends you invite
                                    buy equipment, you can get cash rewards. You can earn a profit share from equipment
                                    purchased by
                                    your team members..</p></uni-view>
                        </uni-view>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>

    @include('loading')
    @include('app.layout.manu')
    @include('alert-message')
</uni-app>

<script>
    window.addEventListener('load', function() {
        document.querySelector('.loading').style.display = 'none';
    })

    function applyes(task_id){
        document.querySelector('.loading').style.display = 'block';
        window.location.href = '{{url('apply-for-task-commission')}}'+"/"+task_id
    }
</script>


<script>
    function copyCode(text)
    {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();

        document.querySelector('.loading').style.display = 'block';
        setTimeout(function (){
            document.querySelector('.loading').style.display = 'none';
            message('Invite Code copy successful.')
        }, 500)
    }

    function copyLink(text)
    {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();

        document.querySelector('.loading').style.display = 'block';
        setTimeout(function (){
            document.querySelector('.loading').style.display = 'none';
            message('Link copy successful.')
        }, 500)
    }
</script>

</body>
</html>
