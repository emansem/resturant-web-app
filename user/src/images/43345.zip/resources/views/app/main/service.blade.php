<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + calc(44px + env(safe-area-inset-top))); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Service</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/service.css">
    <style>
        .active .active_s .device_font[data-v-545dad6c] {
            background: url("{{asset('public')}}/static/img/矩形 413@2x.f12854aa.png") no-repeat;
            background-size: 100% 100%;
            font-family: PingFang SC;
            font-weight: 600;
            font-size: 29px;
            color: #fff;
            line-height: 0px;
            text-shadow: 0 3px 5px #f0b9b2;
            text-align: left;
            font-style: normal;
            height: 44px;
            text-transform: none
        }
        uni-image>img {
            opacity: 1;
        }
    </style>
</head>
<body class="uni-body pages-home-kefu">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/home/kefu">
        <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head" style="background-color: rgb(232, 97, 97); color: rgb(0, 0, 0);">
                <div class="uni-page-head-hd" onclick="window.location.href='{{route('profile')}}'">
                    <img style="width: 20px;height: 20px;" src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                    <div class="uni-page-head-ft"></div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;"> Online Service</div>
                </div>
                <div class="uni-page-head-ft"></div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head>
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-6b479015="">
                    <uni-view data-v-6b479015="">
                        <uni-view data-v-6b479015="">
                            <uni-view data-v-6b479015="" class="item display">
                                <uni-image data-v-6b479015="" style="width: 55px; margin-right: 11px; height: 56px;">
                                    <div style="background-image: url({{asset('public')}}/static/whatsapp.jpg); background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                    <uni-resize-sensor>
                                        <div>
                                            <div></div>
                                        </div>
                                        <div>
                                            <div></div>
                                        </div>
                                    </uni-resize-sensor>
                                    <img src="{{asset('public')}}/static/whatsapp.jpg" draggable="false"></uni-image>
                                <uni-view data-v-6b479015="" style="text-align: left;">
                                    <uni-view data-v-6b479015="">WhatsApp</uni-view>
                                    <p data-v-6b479015=""
                                       style="font-weight: 400; font-size: 11px; color: rgb(204, 204, 204);">Customer
                                        service hours 09:00-22:00</p><img data-v-6b479015=""
                                                                          src="{{asset('public')}}/2787f250.png"
                                                                          style="width: 71px; height: 14px;"></uni-view>
                            </uni-view>
                            <uni-view data-v-6b479015=""
                            onclick="window.location.href='{{setting('whatsapp')}}'"
                                      style="width: 40%; color: rgb(255, 255, 255); margin: 0px auto; border-radius: 15px; padding: 5px 10px; background: rgb(232, 97, 97);">
                                Connect
                            </uni-view>
                        </uni-view>
                        <uni-view data-v-6b479015="">
                            <uni-view data-v-6b479015="" class="item display">
                                <uni-image data-v-6b479015="" style="width: 55px; margin-right: 11px; height: 56px;">
                                    <div style="background-image: url({{asset('public')}}/static/images.png); background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                    <uni-resize-sensor>
                                        <div>
                                            <div></div>
                                        </div>
                                        <div>
                                            <div></div>
                                        </div>
                                    </uni-resize-sensor>
                                    <img src="{{asset('public')}}/static/images.png" draggable="false"></uni-image>
                                <uni-view data-v-6b479015="" style="text-align: left;">
                                    <uni-view data-v-6b479015="">Telegram</uni-view>
                                    <p data-v-6b479015=""
                                       style="font-weight: 400; font-size: 11px; color: rgb(204, 204, 204);">Customer
                                        service hours 09:00-22:00</p><img data-v-6b479015=""
                                                                          src="{{asset('public')}}/2787f250.png"
                                                                          style="width: 71px; height: 14px;"></uni-view>
                            </uni-view>
                            <uni-view data-v-6b479015="" onclick="window.location.href='{{setting('telegram')}}'" style="width: 40%; color: rgb(255, 255, 255); margin: 0px auto; border-radius: 15px; padding: 5px 10px; background: rgb(232, 97, 97);">Connect
                            </uni-view>
                        </uni-view>
                    </uni-view>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
</body>
</html>
