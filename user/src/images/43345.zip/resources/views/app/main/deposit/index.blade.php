<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Recharge</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public/deposit.css')}}">
    <style>
        .recharge .recharge-container .amount-container .balance-text[data-v-069fc72c] {
            width: 100%;
            margin: 5px 0 10px;
            text-align: center;
            font-weight: 400;
            font-size: 21px;
            color: #94512a;
            background-size: 100% 100%;
        }
        a.deposit_btn {
            background: linear-gradient(89deg, #e86161, #da4340);
            display: block;
            width: 80%;
            margin: auto;
            padding: 17px 0;
            color: #fff;
            border-radius: 50px;
            margin-top: 17px;
            margin-bottom: 20px;
        }
        .box-item[data-v-069fc72c] {
            justify-content: center;
        }
    </style>
</head>
<body class="uni-body pages-mine-recharge">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/mine/recharge">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-069fc72c="">
                    <div data-v-069fc72c="" class="recharge">
                        <div data-v-069fc72c="" class="navboxi  van-hairline--bottom">
                            <div data-v-069fc72c="" class=" display-center-center">
                                <div data-v-069fc72c="" class="van-nav-bar__left" onclick="window.location.href='{{route('dashboard')}}'">
                                    <img style="width: 20px;height: 20px;" src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                                </div>
                                <div data-v-069fc72c="" class="van-nav-bar__center van-ellipsis">Recharge</div>
                                <div data-v-069fc72c="" class="van-nav-bar__right" onclick="window.location.href='{{route('deposit.history')}}'">
                                    <img data-v-069fc72c="" src="{{asset('public')}}/static/ere.png" style="width: 27px; right: 27px;height: 24px;">
                                </div>
                            </div>
                        </div>
                        <div data-v-069fc72c="" class="recharge-container">
                            <div data-v-069fc72c="" class="amount-container box-style">
                                <div data-v-069fc72c="" class="balance-text display-between-center">
                                    <div data-v-069fc72c="" class="display"><img data-v-069fc72c=""
                                                                                 src="{{asset('public')}}/5acd281e.png"><span
                                            data-v-069fc72c="">Account Balance</span></div>
                                    <div data-v-069fc72c=""><span data-v-069fc72c="" class="money">{{price(auth()->user()->balance)}}</span></div>
                                </div>
                                <div data-v-069fc72c="" class="page-title"><p data-v-069fc72c="">Select amount</p></div>
                                <div data-v-069fc72c="" class="amount-input">
                                    <div data-v-069fc72c="" class="van-cell van-field">
                                        <div data-v-069fc72c="" class="van-cell__title van-field__label"
                                             style="width: 16%;"><img data-v-069fc72c=""
                                                                      src="{{asset('public')}}/static/ww.png"
                                                                      style="width: 31px; height: 31px;"></div>
                                        <div data-v-069fc72c="" class="van-cell__value van-field__value">
                                            <div data-v-069fc72c="" class="van-field__body">
                                                <uni-input data-v-069fc72c="" autocomplete="off"
                                                           class="van-field__control">
                                                    <div class="uni-input-wrapper">
                                                        <div class="uni-input-placeholder input-placeholder"
                                                             data-v-069fc72c="" style="display: none;">Please enter the
                                                            recharge amount
                                                        </div>
                                                        <input maxlength="140" step=""
                                                               placeholder="{{price(0)}}"
                                                               name="amount"
                                                               autocomplete="off" inputmode="numeric" type="tel"
                                                               class="uni-input-input"></div>
                                                </uni-input>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div data-v-069fc72c="" class="page-title"><p data-v-069fc72c="">Select channel</p></div>
                                <div data-v-069fc72c="" class="amount-input">
                                    <div data-v-069fc72c="" class="van-cell van-field">
                                        <div data-v-069fc72c="" class="van-cell__title van-field__label"
                                             style="width: 16%;"><img data-v-069fc72c=""
                                                                      src="{{asset('public')}}/static/ww.png"
                                                                      style="width: 31px; height: 31px;"></div>
                                        <div data-v-069fc72c="" class="van-cell__value van-field__value">
                                            <div data-v-069fc72c="" class="van-field__body">
                                                <uni-input data-v-069fc72c="" autocomplete="off"
                                                           class="van-field__control">
                                                    <div class="uni-input-wrapper">
                                                        <select name="channel" id="channel" class="uni-input-input" style="width: 100%;">
                                                            @foreach(\App\Models\PaymentMethod::get() as $element)
                                                                <option value="{{$element->name}}">{{$element->name}}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </uni-input>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div data-v-069fc72c="" class="page-title"><p data-v-069fc72c="">Payment Amount</p></div>
                            <uni-view data-v-069fc72c="" class="box-item p20 ">
                                <uni-view data-v-069fc72c="" class="box display-center-center" onclick="getAmount(this, 680)">
                                    <uni-view data-v-069fc72c="" class="display" style="margin-top: 11px;">
                                        <uni-view data-v-069fc72c="" class="ml-30 pymethod ">680</uni-view>
                                    </uni-view>
                                </uni-view>
                                <uni-view data-v-069fc72c="" class="box display-center-center" onclick="getAmount(this, 1600)">
                                    <uni-view data-v-069fc72c="" class="display" style="margin-top: 11px;">
                                        <uni-view data-v-069fc72c="" class="ml-30 pymethod ">1600</uni-view>
                                    </uni-view>
                                </uni-view>
                                <uni-view data-v-069fc72c="" class="box display-center-center" onclick="getAmount(this, 3600)">
                                    <uni-view data-v-069fc72c="" class="display" style="margin-top: 11px;">
                                        <uni-view data-v-069fc72c="" class="ml-30 pymethod ">3600</uni-view>
                                    </uni-view>
                                </uni-view>
                                <uni-view data-v-069fc72c="" class="box display-center-center" onclick="getAmount(this, 7600)">
                                    <uni-view data-v-069fc72c="" class="display" style="margin-top: 11px;">
                                        <uni-view data-v-069fc72c="" class="ml-30 pymethod ">7600</uni-view>
                                    </uni-view>
                                </uni-view>
                                <uni-view data-v-069fc72c="" class="box display-center-center" onclick="getAmount(this, 14600)">
                                    <uni-view data-v-069fc72c="" class="display" style="margin-top: 11px;">
                                        <uni-view data-v-069fc72c="" class="ml-30 pymethod ">14600</uni-view>
                                    </uni-view>
                                </uni-view>
                                <uni-view data-v-069fc72c="" class="box display-center-center" onclick="getAmount(this, 25600)">
                                    <uni-view data-v-069fc72c="" class="display" style="margin-top: 11px;">
                                        <uni-view data-v-069fc72c="" class="ml-30 pymethod ">25600</uni-view>
                                    </uni-view>
                                </uni-view>
                            </uni-view>

                            <div>
                                <a href="javascript:void(0)" class="deposit_btn" onclick="submitPayment()">Deposit</a>
                            </div>

                            <div class="" style="width: 90%;margin: auto;">
                                <p data-v-069fc72c="" class="rules-text">
                                <p>Recharging is your first step to making great wealth.
</p>
                                <p><br></p>
                                <p>The recharge channel is open 24 hours a day. To ensure your safety
</p>
                                <p><br></p>
                                <p>Please be sure to operate funds on the platform and pay attention to the following matters.
</p>
                                <p><br></p>
                                <p>If you encounter a prompt that the payment is unsuccessful, please try to change the payment wallet to pay.
</p>
                                <p><br></p>
                                <p>Minimum deposit amount is:
 {{price(680)}}</p>
                                <p><br></p>
                                <p>If the payment is successful but the account balance is not reflected for a long time, please contact customer service and provide a screenshot of the account with successful payment.
</p>
                                <p><br></p>
                                <p><br></p>
                                <p>If you encounter any problems or need help during the recharge process, please feel free to contact our official customer service team, we will be happy to answer and support you.
</p>
                                <p><br></p>
                                <p>Thank you for your trust and support in our platform!
</p>
                                <p><br></p>
                                <p>Happy investing!</p>
                            </div>
                        </div>
                        <div data-v-069fc72c="" class="van-overlay"
                             style="background: rgba(0, 0, 0, 0); display: none;">
                            <div data-v-069fc72c="" class="loading-box-h">
                                <div data-v-069fc72c="" class="van-loading van-loading--spinner van-loading--vertical">
                                    <span data-v-069fc72c="" class="van-loading__spinner van-loading__spinner--spinner"
                                          style="width: 30px; height: 30px;"><i data-v-069fc72c=""></i><i
                                            data-v-069fc72c=""></i><i data-v-069fc72c=""></i><i
                                            data-v-069fc72c=""></i><i data-v-069fc72c=""></i><i
                                            data-v-069fc72c=""></i><i data-v-069fc72c=""></i><i
                                            data-v-069fc72c=""></i><i data-v-069fc72c=""></i><i
                                            data-v-069fc72c=""></i><i data-v-069fc72c=""></i><i data-v-069fc72c=""></i></span><span
                                        data-v-069fc72c="" class="van-loading__text">Cardano...</span></div>
                            </div>
                        </div>

                        <div data-v-069fc72c="" class="hasreset van-popup van-popup--center"
                             style="z-index: 2002; display: none;"><p data-v-069fc72c="" class="fory">Reminder: The APP code merchant is updated every 5 minutes. Please do not save the account payment, the latest prevails. Please do not pay across wallets, the APP prompts you to use what payment, you must use what payment, otherwise the loss will be borne by you.
                            </p>
                            <uni-button data-v-069fc72c="" class="btnsure subuser">I see</uni-button>
                        </div>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
@include('alert-message')
<script>
    function getAmount(_this, amount){
        document.querySelector('input[name="amount"]').value = amount;
    }

    function submitPayment()
    {
        var amount = document.querySelector('input[name="amount"]').value;
        if (amount > 0){
            var channel = document.querySelector('select[name="channel"]').value;

            if (channel != ''){
                window.location.href='{{url('siglepay/request')}}'+"/"+amount+"/"+channel;
            }
            else {
                message('Please select a channel');
            }
        }else {
            message('Not Acceptable amount.');
        }
    }
</script>
</body>
</html>
