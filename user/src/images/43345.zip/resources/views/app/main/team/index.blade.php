<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: calc(55px + env(safe-area-inset-bottom));">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>MyTeam</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/static/team.css">
    <style>
        .active .active_s .device_font[data-v-545dad6c] {
            background: url("{{asset('public')}}/f12854aa.png") no-repeat;
        }
        .boxnews[data-v-261bb4e6] {
            background: url({{asset('public')}}/b7bc7b65.png) no-repeat;
        }
        .webearning .list-product .list[data-v-3b1c4efe] {
            background: url("{{asset('public')}}/c68138a2.png");
        }
        .header_bg[data-v-3b1c4efe] {
            background: url({{asset('public')}}/65e1ef25.png) no-repeat;
        }
        .device .teamtitle p[data-v-7bea9402] {
            background: url("{{asset('public')}}/783b195d.png");
        }
        .device .topdevice .leftexit[data-v-7bea9402] {
            background: url("{{asset('public')}}/2c580da3.png") no-repeat;
        }
        .device .space-box .bg[data-v-7bea9402] {
            background: url({{asset('public')}}/5a1d1960.png) no-repeat top/100%
        }
        .team .teamtitle p[data-v-545dad6c] {
            background: url("{{asset('public')}}/783b195d.png");
        }
        .team .topdevice .leftexit[data-v-545dad6c] {
            background: url("{{asset('public')}}/2c580da3.png") no-repeat;
        }
        .active .active_s[data-v-545dad6c] {
            height: 30%;
        }
        .active[data-v-545dad6c] {
            background: unset;
            padding: 2px;
        }
        .team .topdevice .leftexit[data-v-545dad6c] {
            background-size: contain;
        }
    </style>
    <?php
        $rebate = \App\Models\Rebate::first();
    ?>
</head>
<body class="uni-body pages-home-myTeam" style="overflow: visible;">
<uni-app class="uni-app--showtabbar uni-app--maxwidth">
    <uni-page data-page="pages/home/myTeam">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-545dad6c="">
                    <div data-v-545dad6c="" class="team">
                        <div data-v-545dad6c="" class="teamtitle "><p data-v-545dad6c="">committee</p></div>
                        <div data-v-545dad6c="" class="topdevice flex">
                            <div data-v-545dad6c="" class="leftexit"><p data-v-545dad6c="">{{$team_size}}</p><span data-v-545dad6c=""
                                                                                                      class="title">My Team</span>
                            </div>
                            <div data-v-545dad6c="" class="leftexit ">
                                <div data-v-545dad6c=""><p data-v-545dad6c="" style="position: relative;">
                                        <?php $amount = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'commission')->sum('amount') ?>
                                                {{price($amount)}}
                                        <i
                                            data-v-545dad6c="" class="van-icon van-icon-arrow"
                                            style="font-size: 16px; position: absolute; right: 5px; top: 50%; transform: translateY(-50%);"></i>
                                    </p><span data-v-545dad6c="" class="title">Team income</span></div>
                            </div>
                        </div>
                        <section data-v-545dad6c="" class="section-box">
                            <div data-v-545dad6c="" class="list-level"
                                 style="background: url({{asset('public')}}/static/committee/2x1.png) 0% 0% / 100% 100%;">
                                <div data-v-545dad6c="" class="firstl flex">
                                    <div data-v-545dad6c="" class="myteam"><img data-v-545dad6c=""
                                                                                src="{{asset('public')}}/6a78edcd.png"
                                                                                alt="" class="imgfirst">
                                        <p data-v-545dad6c="">My first-level team</p></div>
                                    <uni-view data-v-545dad6c=""><img data-v-545dad6c=""
                                                                      src="{{asset('public')}}/c4e53389.png"
                                                                      style="width: 105px; height: 16px;">
                                        <p data-v-545dad6c="" class="commis"><span data-v-545dad6c="">Commission:</span>{{$rebate->team_commission1}}%
                                        </p></uni-view>
                                </div>
                                <div data-v-545dad6c="" class="listuis">
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(47, 222, 67);">{{$first_level_users->count()}}</p><span
                                            data-v-545dad6c="">Total people</span></div>
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(229, 94, 80);"><span
                                                data-v-545dad6c="" style="color: rgb(229, 94, 80);"></span>{{price($lv1Recharge)}}</p><span
                                            data-v-545dad6c="">Total invest</span></div>
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(229, 94, 80);"><span
                                                data-v-545dad6c="" style="color: rgb(229, 94, 80);"></span>{{price($levelTotalCommission1)}}</p><span
                                            data-v-545dad6c="">Total commission</span></div>
                                </div>
                            </div>
                            <div data-v-545dad6c="" class="list-level"
                                 style="background: url({{asset('public')}}/static/committee/2x2.png) 0% 0% / 100% 100%;">
                                <div data-v-545dad6c="" class="firstl flex">
                                    <div data-v-545dad6c="" class="myteam"><img data-v-545dad6c=""
                                                                                src="{{asset('public')}}/e433d3cc.png"
                                                                                alt="" class="imgfirst">
                                        <p data-v-545dad6c="">My second-level team</p></div>
                                    <uni-view data-v-545dad6c=""><img data-v-545dad6c=""
                                                                      src="{{asset('public')}}/d1d3b1dd.png"
                                                                      style="width: 105px; height: 16px;">
                                        <p data-v-545dad6c="" class="commis"><span data-v-545dad6c="">Commission:</span>{{$rebate->team_commission2}}%
                                        </p></uni-view>
                                </div>
                                <div data-v-545dad6c="" class="listuis">
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(47, 222, 67);">{{$second_level_users->count()}}</p><span
                                            data-v-545dad6c="">Total people</span></div>
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(229, 94, 80);"><span
                                                data-v-545dad6c="" style="color: rgb(229, 94, 80);"></span>{{price($lv2Recharge)}}</p><span
                                            data-v-545dad6c="">Total invest</span></div>
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(229, 94, 80);"><span
                                                data-v-545dad6c="" style="color: rgb(229, 94, 80);"></span>{{price($levelTotalCommission2)}}</p><span
                                            data-v-545dad6c="">Total commission</span></div>
                                </div>
                            </div>
                            <div data-v-545dad6c="" class="list-level"
                                 style="background: url({{asset('public')}}/static/committee/2x3.png) 0% 0% / 100% 100%;">
                                <div data-v-545dad6c="" class="firstl flex">
                                    <div data-v-545dad6c="" class="myteam"><img data-v-545dad6c=""
                                                                                src="{{asset('public')}}/5c9b47dc.png"
                                                                                alt="" class="imgfirst">
                                        <p data-v-545dad6c="">My three-level team</p></div>
                                    <uni-view data-v-545dad6c=""><img data-v-545dad6c=""
                                                                      src="{{asset('public')}}/4176ad54.png"
                                                                      style="width: 105px; height: 16px;">
                                        <p data-v-545dad6c="" class="commis"><span data-v-545dad6c="">Commission:</span>{{$rebate->team_commission3}}%
                                        </p></uni-view>
                                </div>
                                <div data-v-545dad6c="" class="listuis">
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(47, 222, 67);">{{$third_level_users->count()}}</p><span
                                            data-v-545dad6c="">Total people</span></div>
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(229, 94, 80);"><span
                                                data-v-545dad6c="" style="color: rgb(229, 94, 80);"></span>{{price($lv3Recharge)}}</p><span
                                            data-v-545dad6c="">Total invest</span></div>
                                    <div data-v-545dad6c="" class="uis"><p data-v-545dad6c=""
                                                                           style="color: rgb(229, 94, 80);"><span
                                                data-v-545dad6c="" style="color: rgb(229, 94, 80);"></span>{{price($levelTotalCommission3)}}</p><span
                                            data-v-545dad6c="">Total commission</span></div>
                                </div>
                            </div>
                            <uni-view data-v-545dad6c="" class="bounsi">
                                <uni-view data-v-545dad6c="" class="copyLink">
                                    <uni-text data-v-545dad6c=""><span>Invite Code：{{auth()->user()->ref_id}}</span></uni-text>
                                    <uni-view data-v-545dad6c="" class=" recebtn  " onclick="copyCode('{{auth()->user()->ref_id}}')">copy</uni-view>
                                </uni-view>
                                <uni-view data-v-545dad6c=""
                                          style="height: 2px; background: rgba(0, 0, 0, 0.3); margin: 0px 16px;"></uni-view>
                                <uni-view data-v-545dad6c="" class="copyLink">
                                    <uni-text data-v-545dad6c=""><span>Invite Link：{{url('pages/login/register').'?invite='.auth()->user()->ref_id}}</span>
                                    </uni-text>
                                    <uni-view data-v-545dad6c="" class=" recebtn  " onclick="copyLink('{{url('pages/login/register').'?invite='.auth()->user()->ref_id}}')">copy</uni-view>
                                </uni-view>
                            </uni-view>
                            <uni-view data-v-545dad6c="" class="bounsi"
                                      style="background: url({{asset('public')}}/static/committee/2x.png) 0% 0% / 100% 100%; padding: 0px;">
                                <uni-view data-v-545dad6c=""
                                          style="background: url({{asset('public')}}/static/committee/6852x.png) 0% 0% / 100% 100%; width: 111px; height: 22px;">
                                    <span data-v-545dad6c=""
                                          style="font-weight: 600; font-size: 12px; color: rgb(145, 72, 0); line-height: 0px;">invitation rules</span>
                                </uni-view>
                                <uni-view data-v-545dad6c="" class="display "><img data-v-545dad6c=""
                                                                                   src="{{asset('public')}}/10dd0ca4.png"
                                                                                   style="width: 53px; height: 50px; margin: 11px;">
                                    <uni-view data-v-545dad6c=""><p data-v-545dad6c=""
                                                                    style="font-weight: 400; font-size: 12px; color: rgb(145, 72, 0);">
                                            invite {{setting('total_member_register_reword')}} friend to register and get 1/{{price(setting('total_member_register_reword_amount'))}}~~{{price(setting('total_member_register_reword_amount') * setting('total_member_register_reword'))}}</p>
                                        <uni-view data-v-545dad6c="" class="display" style="margin-top: 7px;">
                                            <uni-view data-v-545dad6c=""><img data-v-545dad6c=""
                                                                              src="{{asset('public')}}/3e709f53.png"
                                                                              style="width: 25px; height: 25px;"><img
                                                    data-v-545dad6c="" src="{{asset('public')}}/d4fa17c9.png"
                                                    style="width: 25px; height: 25px;"></uni-view>
                                            <p data-v-545dad6c=""
                                               style="font-weight: 400; line-height: 27px; height: 27px; font-size: 12px; color: rgb(229, 94, 80); margin-left: 16px;">
                                                …….</p></uni-view>
                                    </uni-view>
                                </uni-view>
                            </uni-view>
                            <uni-view data-v-545dad6c="" class="active">
                                <uni-view data-v-545dad6c="" class="active_s">
                                    <uni-view data-v-545dad6c="" class="display-center-center m-19-0  device_font">
                                        <uni-view data-v-545dad6c="" class="first_d"></uni-view>
                                        <uni-view data-v-545dad6c="" class="sec_d"></uni-view>
                                        <uni-view data-v-545dad6c="" class="three_d"></uni-view>
                                        <uni-view data-v-545dad6c=""
                                                  style="margin-right: 5px; padding: 0px 11px; font-size: 17px;">
                                            activity 1
                                        </uni-view>
                                        <uni-view data-v-545dad6c="" class="three_d"></uni-view>
                                        <uni-view data-v-545dad6c="" class="sec_d"></uni-view>
                                        <uni-view data-v-545dad6c="" class="first_d"></uni-view>
                                    </uni-view>
                                    <uni-view data-v-545dad6c=""
                                              style="color: rgba(0, 0, 0, 0.44); text-align: left; padding: 0px 11px; font-size: 14px;">
                                        Recommend friends to invest in purchasing equipment and receive total commission
                                        rewards of up to
                                        LV1+LV2+LV3~{{$rebate->team_commission1 + $rebate->team_commission1 + $rebate->team_commission3}}% of investment income.
                                    </uni-view>
                                    <uni-view data-v-545dad6c="" style="padding: 16px 11px;">
                                        <table data-v-545dad6c="">
                                            <tr data-v-545dad6c="">
                                                <td data-v-545dad6c="">Subordinate</td>
                                                <td data-v-545dad6c="">Awards ( {{currency()}})</td>
                                            </tr>
                                            <tr data-v-545dad6c="">
                                                <td data-v-545dad6c="">Level 1</td>
                                                <td data-v-545dad6c="">{{$rebate->team_commission1}}%</td>
                                            </tr>
                                            <tr data-v-545dad6c="">
                                                <td data-v-545dad6c="">Level 2</td>
                                                <td data-v-545dad6c="">{{$rebate->team_commission2}}%</td>
                                            </tr>
                                            <tr data-v-545dad6c="">
                                                <td data-v-545dad6c="">Level 3</td>
                                                <td data-v-545dad6c="">{{$rebate->team_commission3}}%</td>
                                            </tr>
                                        </table>
                                    </uni-view>
                                </uni-view>
                            </uni-view>
                        </section>
                    </div>
                    @include('loading')
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
    @include('app.layout.manu')
</uni-app>
<script>
    window.addEventListener('load', function() {
        document.querySelector('.loading').style.display = 'none';
    })
</script>
@include('alert-message')
<script>
    function copyCode(text)
    {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();

        document.querySelector('.loading').style.display = 'block';
        setTimeout(function (){
            document.querySelector('.loading').style.display = 'none';
            message('Invite Code copy successful.')
        }, 500)
    }

    function copyLink(text)
    {
        const body = document.body;
        const input = document.createElement("input");
        body.append(input);
        input.style.opacity = 0;
        input.value = text.replaceAll(' ', '');
        input.select();
        input.setSelectionRange(0, input.value.length);
        document.execCommand("Copy");
        input.blur();
        input.remove();

        document.querySelector('.loading').style.display = 'block';
        setTimeout(function (){
            document.querySelector('.loading').style.display = 'none';
            message('Link copy successful.')
        }, 500)
    }
</script>
</body>
</html>
