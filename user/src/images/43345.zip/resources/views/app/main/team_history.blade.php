<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>{{env('APP_NAME')}}</title>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/history.css">

</head>
<body class="uni-body pages-mine-bill">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/mine/bill">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-34389f56="" class="pages">
                    <uni-view data-v-34389f56="" class="fixedTop">
                        <uni-view data-v-647d8196="" data-v-34389f56="" class="bar">
                            <uni-view data-v-647d8196="" class="backBar">
                                <uni-view data-v-647d8196="" class="status_bars"></uni-view>
                                <uni-view data-v-647d8196="" class="lineBox flexBetween black">
                                    <uni-view data-v-647d8196="" class="ke"
                                              onclick="window.location.href='{{route('user.team')}}'">
                                        <uni-view data-v-647d8196="" class="back">
                                            <uni-image data-v-647d8196="" style="height: 16px;">
                                                <div
                                                    style="background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAABF0lEQVRYR+3XMQrCMBSA4b+bq4PgpoODnsMLeAMXB4/g4OrgCRxcvIYg6A0cXLyC4ODoKIEIpQrhJe+RDO1SymvIl/eStKko7KoK89CCQhWxylAfmAIn4BFC1OMWoCFwBtz9DkxyguoY53gCvVygJuYNzIBjDpAKxsE15pAaRgOkikkFqWNSQCaYWJAZJgZkipGCOsANGPl9JWqfCe1JkmU/Bw6WGGmG9sDCg1bANjTamLgkQztg6TtZA5uYDkNtJKDiSuYm9RUYW84jSYacYwBc/L+Oe1ZfaVKQOSoGZIqKBZmhUkAmqFSQOkoDpIrSAqmhNEH/UC+gG/pc1OPaoCYq+0HxO9iijtKSCv28a1GyFpSUgVDjD/AnTCVG0231AAAAAElFTkSuQmCC); background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                                <uni-resize-sensor>
                                                    <div>
                                                        <div></div>
                                                    </div>
                                                    <div>
                                                        <div></div>
                                                    </div>
                                                </uni-resize-sensor>
                                                <img
                                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAABF0lEQVRYR+3XMQrCMBSA4b+bq4PgpoODnsMLeAMXB4/g4OrgCRxcvIYg6A0cXLyC4ODoKIEIpQrhJe+RDO1SymvIl/eStKko7KoK89CCQhWxylAfmAIn4BFC1OMWoCFwBtz9DkxyguoY53gCvVygJuYNzIBjDpAKxsE15pAaRgOkikkFqWNSQCaYWJAZJgZkipGCOsANGPl9JWqfCe1JkmU/Bw6WGGmG9sDCg1bANjTamLgkQztg6TtZA5uYDkNtJKDiSuYm9RUYW84jSYacYwBc/L+Oe1ZfaVKQOSoGZIqKBZmhUkAmqFSQOkoDpIrSAqmhNEH/UC+gG/pc1OPaoCYq+0HxO9iijtKSCv28a1GyFpSUgVDjD/AnTCVG0231AAAAAElFTkSuQmCC"
                                                    draggable="false"></uni-image>
                                        </uni-view>
                                    </uni-view>
                                    <uni-view data-v-647d8196="" class="title Bold">Team History</uni-view>
                                    <uni-view data-v-647d8196="" class="ke"></uni-view>
                                </uni-view>
                            </uni-view>
                        </uni-view>
                        <uni-view data-v-34389f56="" class="status_bar"></uni-view>
                    </uni-view>

                    <uni-view data-v-34389f56="" style="height: 722px;">
                        <uni-view data-v-c7cacc8a="" data-v-34389f56="">
                            <uni-view data-v-c7cacc8a="">
                                <uni-scroll-view data-v-c7cacc8a="" style="height: 722px;">
                                    <div class="uni-scroll-view">
                                        <div class="uni-scroll-view" style="overflow: hidden auto;">
                                            <div class="uni-scroll-view-content all">
                                                <uni-view data-v-c7cacc8a="" id="topId"></uni-view>
                                                @foreach(\App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'commission')->orderByDesc('id')->get() as $element)
                                                    <uni-view data-v-34389f56="" class="flexBetween auto90 itemBox">
                                                        <uni-view data-v-34389f56="" class="itemLeft">
                                                            <uni-view data-v-34389f56="" class="flexBetween flexColumn">
                                                                <uni-view data-v-34389f56="" class="l1">Member Interest
                                                                </uni-view>
                                                                <uni-view data-v-34389f56=""
                                                                          class="l2 Small">{{$element->created_at->format('Y-m-d')}}</uni-view>
                                                            </uni-view>
                                                        </uni-view>
                                                        <uni-view data-v-34389f56="" class="itemRight Blod">
                                                            <uni-view data-v-34389f56="" class="l1"
                                                                      style="text-align: right">{{price($element->amount)}}</uni-view>
                                                        </uni-view>
                                                    </uni-view>
                                                @endforeach
                                                <uni-view data-v-c7cacc8a="" class="noCard">-—— No more data available
                                                    ——-
                                                </uni-view>
                                                <uni-view data-v-c7cacc8a="" style="height: 80px;"></uni-view>
                                            </div>
                                        </div>
                                    </div>
                                </uni-scroll-view>
                            </uni-view>
                            <uni-view data-v-c7cacc8a=""></uni-view>
                        </uni-view>
                    </uni-view>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
</body>
</html>
