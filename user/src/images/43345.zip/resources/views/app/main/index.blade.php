<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: calc(55px + env(safe-area-inset-bottom));">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>{{env('APP_NAME')}}</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick-theme.css">
    <style>
        .boxnews[data-v-261bb4e6] {
            width: 412px;
            height: 557px;
            /* background: #fff; */
            border-radius: 32px;
            padding: 27px 66px;
            color: #fff;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            background: url({{asset('public')}}/static/img/tip@2x.b7bc7b65.png) no-repeat;
            background-size: 100% 100%
        }

        .header_bg[data-v-3b1c4efe] {
            background: url({{asset('public')}}/static/img/mz1@2x.65e1ef25.png) no-repeat;
            background-size: 100% 100%;
            color: #fff;
            font-size: 15px;
            line-height: 1.5
        }

        .van-pull-refresh__track {
            position: relative;
            height: 18%;
        }

        .webearning .list-product .list[data-v-3b1c4efe] {
            margin-bottom: 12px;
            padding: 16px 0px 16px 14px;
            background: url("{{asset('public')}}/bg1.png");
            display: flex;
            position: relative;
        }
        .overlay {
            width: 100%;
            height: 100%;
            background: #0000003d;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 9;
        }
        .van-pull-refresh__track {
            height: 24%;
        }

        .boxnews[data-v-261bb4e6] {
            width: 412px;
            height: 557px;
            /* background: #fff; */
            border-radius: 32px;
            padding: 27px 66px;
            color: #fff;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            background: url({{asset('public/b7bc7b65.png')}}) no-repeat;
            background-size: 100% 100%;
        }


        .carousel__slide__inner {
            overflow: hidden;
            position: relative;
        }
        .doAnimation .slick-active .carousel__slide__inner .carousel__image {
            animation: scale-out 0.875s cubic-bezier(0.7, 0, 0.3, 1) 0.375s both;
            transform: scale(1.3);
        }
        .carousel__slide__overlay {
            background-color: transparent;
            background-size: 100%;
            height: 100%;
            left: 0;
            opacity: 0.5;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 2;
        }
        .slick-active .carousel__slide__overlay {
            animation: scale-in-hor-left 1.375s cubic-bezier(0.645, 0.045, 0.355, 1) 0.25s reverse both;
        }
        .carousel__image {
            height: 100%;
            object-fit: cover;
            position: relative;
            transform: scale(1);
            width: 100%;
            z-index: 1;
        }
        @keyframes scale-out {
            0% {
                transform: scale(1.3);
            }
            100% {
                transform: scale(1);
            }
        }
        @keyframes scale-in-hor-left {
            0% {
                -webkit-transform: translateX(-100%) scaleX(0);
                transform: translateX(-100%) scaleX(0);
                -webkit-transform-origin: 0% 0%;
                transform-origin: 0% 0%;
                opacity: 1;
            }
            50% {
                -webkit-transform: translateX(-50%) scaleX(0.5);
                transform: translateX(-50%) scaleX(0.5);
                -webkit-transform-origin: 0% 0%;
                transform-origin: 0% 0%;
                opacity: 1;
            }
            100% {
                -webkit-transform: translateX(0) scaleX(1);
                transform: translateX(0) scaleX(1);
                -webkit-transform-origin: 0% 0%;
                transform-origin: 0% 0%;
                opacity: 1;
            }
        }
        .banner[data-v-3b1c4efe] {
            height: 156px;
        }
        strong.ppprice {
    position: absolute;
    top: 16px;
    right: 18px;
}
    </style>
</head>
<body class="uni-body pages-home-index" style="overflow: visible;">
<uni-app class="uni-app--showtabbar uni-app--maxwidth">
    <uni-page data-page="pages/home/index">
        <uni-page-wrapper>
            <uni-page-body>


                <uni-view data-v-3b1c4efe="" class="webearning">
                    <uni-view data-v-3b1c4efe="" class="van-pull-refresh">
                        <div data-v-3b1c4efe="" class="van-pull-refresh__track "
                             style="transition-duration: 0ms; padding-top: 13px; background: linear-gradient(89deg, rgb(232, 97, 97) 0%, rgb(218, 67, 64) 100%);">
                            <div data-v-3b1c4efe="" class="header_bg">
                                <uni-view data-v-3b1c4efe="" class="display-between-center" style="padding: 0px 14px;">
                                    <uni-view data-v-3b1c4efe="" class="flex " style="justify-content: flex-start;">
                                        <uni-view data-v-3b1c4efe="" class="flex d-c" style="margin-right: 16px;"><p
                                                data-v-3b1c4efe="">My Balance</p>
                                            <p data-v-3b1c4efe="" class="money">
                                                <uni-view data-v-3b1c4efe="" class="rs_bef"><span
                                                        data-v-3b1c4efe="">{{currency()}}</span></uni-view>
                                                <uni-text data-v-3b1c4efe=""><span>{{auth()->user()->balance}}</span></uni-text>
                                            </p>
                                        </uni-view>
                                        <uni-view data-v-3b1c4efe="" class="flex d-c"><p data-v-3b1c4efe="">My Income</p>
                                            <p data-v-3b1c4efe="" class="money">
                                                <uni-view data-v-3b1c4efe="" class="rs_bef"><span
                                                        data-v-3b1c4efe="">{{currency()}}</span></uni-view>
                                                <uni-text data-v-3b1c4efe=""><span>
                                                        <?php
                                                            $refer_commission = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'my_commission')->sum('amount');
                                                            $commission = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'commission')->sum('amount');
                                                        ?>
                                                        {{$refer_commission + $commission}}
                                                    </span></uni-text>
                                            </p>
                                        </uni-view>
                                    </uni-view>
                                    <uni-view data-v-3b1c4efe=""
                                              style="width: 55px; height: 55px; border-radius: 50%; background: rgb(255, 255, 255); overflow: hidden;">
                                        <img data-v-3b1c4efe="" src="{{asset(setting('photo'))}}"
                                             style="width: 55px; height: 55px;"></uni-view>
                                </uni-view>
                                <uni-view data-v-3b1c4efe="" class="display-around-center header2"
                                          style="margin-top: 16px;">
                                    <uni-view data-v-3b1c4efe="" class="flex d-c" onclick="window.location.href='{{route('user.deposit')}}'">
                                        <uni-view data-v-3b1c4efe="" class="header2-bg"><img data-v-3b1c4efe=""
                                                                                             src="{{asset('public')}}/5acd281e.png">
                                        </uni-view>
                                        <uni-text data-v-3b1c4efe=""><span>Recharge</span></uni-text>
                                    </uni-view>
                                    <uni-view data-v-3b1c4efe="" class="flex d-c" onclick="window.location.href='{{route('user.withdraw')}}'">
                                        <uni-view data-v-3b1c4efe="" class="header2-bg"><img data-v-3b1c4efe=""
                                                                                             src="{{asset('public')}}/static/img/qu@2x.0cd31bfa.png">
                                        </uni-view>
                                        <uni-text data-v-3b1c4efe=""><span>Withdraw</span></uni-text>
                                    </uni-view>
                                    <uni-view data-v-3b1c4efe="" class="flex d-c">
                                        <uni-view data-v-3b1c4efe="" class="header2-bg"><img data-v-3b1c4efe=""
                                                                                             src="{{asset('public')}}/static/img/Download@2x.728a3e94.png">
                                        </uni-view>
                                        <uni-text data-v-3b1c4efe=""><span>Download</span></uni-text>
                                    </uni-view>
                                    <uni-view data-v-3b1c4efe="" class="flex d-c" onclick="window.location.href='{{url('logout')}}'">
                                        <uni-view data-v-3b1c4efe="" class="header2-bg"><img data-v-3b1c4efe=""
                                                                                             src="{{asset('public')}}/static/img/qiandao@2x.f5fdace8.png">
                                        </uni-view>
                                        <uni-text data-v-3b1c4efe=""><span>Sign Out</span></uni-text>
                                    </uni-view>
                                </uni-view>
                            </div>
                        </div>
                        <uni-view data-v-3b1c4efe="" class="boxbelli">
                            <div data-v-3b1c4efe="" role="alert" class="barboxi van-notice-bar"
                                 style="color: rgb(1, 104, 183);"><img data-v-3b1c4efe=""
                                                                       src="{{asset('public')}}/static/mic.png">
                                <marquee behavior="" direction="">
                                    Welcome to {{env('APP_NAME')}} Registration. Date of publication: 01/ 05/ 2024! Register as a member and get free gifts: 280 {{currency()}}.
                                </marquee>
                            </div>
                        </uni-view>
                        <uni-view data-v-3b1c4efe="" class="banner">

                            <div class="carousel">

                                @foreach(\App\Models\VipSlider::get() as $element)
                                <div class="carousel__slide">
                                    <img style="width: 100%;" src="{{asset($element->photo)}}" draggable="false">
                                </div>
                                @endforeach
                            </div>

                        </uni-view>
                    </uni-view>

                    <uni-view data-v-3b1c4efe="" class="display-center-center m-19-0  device_font">
                        <uni-view data-v-3b1c4efe="" class="first_d"></uni-view>
                        <uni-view data-v-3b1c4efe="" class="sec_d"></uni-view>
                        <uni-view data-v-3b1c4efe="" class="three_d"></uni-view>
                        <uni-view data-v-3b1c4efe="" style="margin-right: 5px; padding: 0px 11px;">Device list
                        </uni-view>
                        <uni-view data-v-3b1c4efe="" class="three_d"></uni-view>
                        <uni-view data-v-3b1c4efe="" class="sec_d"></uni-view>
                        <uni-view data-v-3b1c4efe="" class="first_d"></uni-view>
                    </uni-view>
                    <uni-view data-v-3b1c4efe="" class="list-product">r
                        @foreach(\App\Models\Package::where('status', 'active')->get() as $element)
                        <uni-view data-v-3b1c4efe="" class="list" onclick="window.location.href='{{route('package.details', $element->id)}}'" style="position:relative;">
                            <uni-view data-v-3b1c4efe="" class="vip"><img data-v-3b1c4efe=""
                                                                          src="{{asset('public')}}/static/tt.png"><span
                                    data-v-3b1c4efe="">{{$element->name}}</span></uni-view>
                            <uni-view data-v-3b1c4efe="" class="topimg"><img data-v-3b1c4efe=""
                                                                             src="{{asset($element->photo)}}">
                        </uni-view>
                            <uni-view data-v-3b1c4efe="" class="dailyui"><p data-v-3b1c4efe="" class="namei ellipsis-1">{{$element->title}}</p>
                                <div data-v-3b1c4efe="" class="display-center-center">
                                    <strong class="ppprice">{{price($element->price)}}</strong>
                                  <div data-v-3b1c4efe="" class="income "><span data-v-3b1c4efe="" class="cumlai">Hourly income</span>
                                        <p data-v-3b1c4efe="" class="totalin">{{currency()}}{{number_format(($element->commission_with_avg_amount / $element->validity) / 24 , 3)}}</p></div>

                                    <div data-v-3b1c4efe="" class="income "><span data-v-3b1c4efe="" class="cumlai">Daily income</span>
                                        <p data-v-3b1c4efe="" class="totalin">{{price($element->commission_with_avg_amount / $element->validity)}}</p></div>

                                    <div data-v-3b1c4efe="" class="income "><span data-v-3b1c4efe="" class="cumlai">Total revenue</span>
                                        <p data-v-3b1c4efe="" class="totalin">{{price($element->commission_with_avg_amount)}}</p></div>

                                </div>
                                <div data-v-3b1c4efe="" class="btnn">Invest Now</div>
                            </uni-view>
                        </uni-view>
                        @endforeach
                    </uni-view>
                    <uni-view data-v-261bb4e6="" data-v-3b1c4efe=""></uni-view>

                    <uni-view data-v-67b88ecc="" data-v-9176e7be="" onclick="window.location.href='{{setting('telegram')}}'" style="position: fixed; bottom: 60px; right: 15px;z-index: 999">
                        <uni-image data-v-67b88ecc="" class="customer">
                            <div style="background-image: url(https://img.icons8.com/fluency/48/telegram-app.png); background-position: 0% 0%; background-size: 70% 70%; background-repeat: no-repeat;"></div>
                            <img src="https://img.icons8.com/fluency/48/telegram-app.png" draggable="false" style="width:70%;height:70%;"></uni-image>
                    </uni-view>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>


    @include('loading')


    <div class="overlay" onclick="closeModalHome()"></div>
    <uni-view data-v-261bb4e6="" data-v-3b1c4efe="" class="mainModalPop">
        <uni-view data-v-58e7869c="" data-v-261bb4e6="" class="uni-popup center" style="overflow: visible;">
            <uni-view data-v-58e7869c="">
                <uni-view data-v-acf5fb64="" data-v-58e7869c="" class="" name="content"
                          style="transform: scale(1); opacity: 1; position: fixed; display: flex; flex-direction: column; inset: 0px; justify-content: center; align-items: center; transition: opacity 300ms ease 0ms, -webkit-transform 300ms ease 0ms, transform 300ms ease 0ms; transform-origin: 50% 50%;">
                    <uni-view data-v-58e7869c="" class="uni-popup__wrapper center"
                              style="background-color: transparent;">
                        <div data-v-261bb4e6="" data-v-69a8819c="" class="boxnews van-popup van-popup--center"
                             style="z-index: 2002; overflow: visible;"><p data-v-261bb4e6="" data-v-69a8819c=""
                                                                          class="notifia">Notification</p>
                            <div data-v-261bb4e6="" data-v-69a8819c="" class="niticelist">
                                <span data-v-261bb4e6="" data-v-69a8819c="">
                                    <p>Welcome back</p>
                                    <p><br></p>
                                    <p>Date of publication: 01/ 05/ 2024</p>
                                    <p><br></p>
                                    <p>Register as a member and get free gifts: 280 {{currency()}}</p>
                                    <p>Minimum recharge is 680 {{currency()}}
</p>
                                    <p>Minimum withdrawal is 300 {{currency()}}
</p>
                                    <p><br></p>
                                    <p>Invite friends to join and direct members get cashback on device purchases
</p>
                                    <p>+27% commission on 1st level members devices
</p>
                                    <p><br></p>
                                    <p>If you encounter any problems, please contact the official customer service in time.</p>
                                </span>
                            </div>
                            <uni-button data-v-261bb4e6="" class="btnok" data-v-69a8819c="" onclick="closeModalHome()">OK</uni-button>
                        </div>
                    </uni-view>
                </uni-view>
            </uni-view>
        </uni-view>
    </uni-view>

    @include('app.layout.manu')
</uni-app>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
<script>
    function closeModalHome(){
        document.querySelector('.overlay').style.display = 'none';
        document.querySelector('.mainModalPop').style.display = 'none';
    }

    window.addEventListener('load', function() {
        document.querySelector('.loading').style.display = 'none';
    })

    // find elements
    var carousel = $(".carousel");

    var options = {
        adaptiveHeight: true,
        arrows: false,
        dots: true,
        fade: true,
        infinite: false,
        mobileFirst: true,
        rows: 0,
        slidesToScroll: 1,
        slidesToShow: 1,
        speed: 0,
        zIndex: 75,
        autoplay: true,
    };

    var addAnimationClass = true;

    carousel.on('beforeChange', function(e, slick, current, next) {
        var current = carousel.find('.slick-slide')[current];
        var next = carousel.find('.slick-slide')[next];
        var src = $(current).find('.carousel__image').attr('src');

        $(next).find('.carousel__slide__overlay').css('background-image', 'url("' + src + '")');


        if(addAnimationClass) {
            carousel.addClass('doAnimation');

            // so that adding the class only happens once
            addAnimationClass = false;
        }
    });

    carousel.not('.slick-initialized').slick(options);

    window.onload = function() {
        $.ajax({
            url: "{{url('onepay-payment-checker')}}",
            type: 'GET',
            dataType: 'json',
            success: function(res) {
                console.log(res);
            }
        });
    };
</script>
</body>
</html>
