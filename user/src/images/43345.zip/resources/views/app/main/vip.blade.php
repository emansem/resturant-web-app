<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>{{env('APP_NAME')}}</title>
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/vip.css">
    <style>
        .pages .topBox .otherHalf[data-v-048725ca] {
            width: 369px;
            margin: auto;
            background: url({{asset('public')}}/static/img/bg2.2090e9d3.png) no-repeat bottom #2d3132;
            background-size: 100% auto;
            height: 128px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative
        }

        uni-view.menuItem {
            background: #9fe0ff;
            padding: 10px 24px;
            margin: 10px 0;
            border-radius: 5px;
            width: 100%;
            text-align: center;
        }

        .flexBetween {
            width: 94%;
        }

        .pages .switchBox > uni-view > uni-view[data-v-032d680a] {
            width: 0;
            height: 0;
            position: absolute;
            bottom: 0px !important;
            left: 65px;
            border-top: 12px solid #9fe0ff;
            border-right: 12px solid transparent;
            border-left: 12px solid transparent;
        }

        uni-view.menuItem.activate {
            background: #3ebaf4;
            color: #fff;
        }
        .pages .ListBox .innerBox .innerRight .ListShow .boxItem[data-v-048725ca] {
    height: 20px;
    text-align: left;
    border-radius: 6px;
}
    </style>
</head>
<body class="uni-body pages-second-second">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/second/second">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-048725ca="" class="pages">
                    <uni-view data-v-048725ca="" class="topFixed">
                        <uni-view data-v-048725ca="" style="height: 66px;"></uni-view>
                        <uni-view data-v-048725ca="" class="topBox auto90 ">
                            <uni-view data-v-048725ca="" class="otherHalf radius30">
                                <uni-view data-v-048725ca="" class="mask"></uni-view>
                                <uni-view data-v-048725ca="" class="innerBoxB flexAround">
                                    <uni-view data-v-048725ca="" class="boxItem flexColumn">
                                        <uni-view data-v-048725ca="" class="Bold tit">Account balance</uni-view>
                                        <uni-view data-v-048725ca=""
                                                  class="Bold num">{{price(auth()->user()->balance)}}</uni-view>
                                    </uni-view>
                                    <uni-view data-v-048725ca="" class="line"></uni-view>
                                    <uni-view data-v-048725ca="" class="boxItem flexColumn">
                                        <uni-view data-v-048725ca="" class="Bold tit">Cumulative invest</uni-view>
                                        <uni-view data-v-048725ca="" class="Bold num">
                                            <?php
                                            $investsAmount = \App\Models\Purchase::where('user_id', auth()->id())->where('status', 'active')->sum('amount');
                                            ?>
                                            {{price($investsAmount)}}
                                        </uni-view>
                                    </uni-view>
                                </uni-view>
                            </uni-view>

                            <uni-view data-v-048725ca="" class="tipShow">
                                <uni-view data-v-048725ca="" class="txt">Product List</uni-view>
                            </uni-view>
                            <uni-view data-v-048725ca="" class="tipLine">Choose the product investment you need
                            </uni-view>
                        </uni-view>

                        <uni-view data-v-048725ca="" class="contact_us" onclick="window.location.href='https://wa.me/+8801932961871'">
                            <uni-text data-v-048725ca=""><span>If you wan to make money. please contact us</span>
                            </uni-text>
                            <uni-image data-v-048725ca="" style="height: 26px;">
                                <div
                                    style="background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAS+SURBVHgB7Zo9bBxVEMf/b89x4ksAG0xBguyNSOEGkSCRylJMQ+i4NmlyCalASi6CAiEBRjQUQTmQ6ADbTShzdMFNDKICKTkEhYtELJYACUzOspI7x/bty8zz7d3e3n68/Thfivyk1X6fZubNzJt5e8BjBotAhhT/KZnYg6PIiUnY0qRLo61bFgyxhqb8EzlU58fKFjIitQLF/0ozMPAG/VJBSphaLwlYQmIJNhbmny0vIQWJFSiulook+EUS+ijSQMoYQszOjV1ZQAJiK8AWlznMQdfa+pIkUkRbgWKtNEpDPiuBi+gjJFCZRvZjipM1zeejIeFNcpVrSOsuunCMCLyqE+yRCrSEv5G5y0ShqUSoAgMT3kFDiUAF2OdJ+FtJhR83nsb5A6eQxwi+uPcNVu27SIRAtaWEb0wYgS9SwKax/PTeVzA1dAQTQ4fUcWI47mx8FHTbVwHO8Wmzjdviq82E1m9BspTUhOnDkO8LBmksEUlejOC1fSfIXcbU+fL2Hfz04Oed4607al+pX1fXCyMn6d4viV1JzT3AYe/1nhhQ1hfq4VAmcofw3pNvKyXcsICfrn+p9hO5g7Q9j9P7C+q5umzgrdr7SIphiKJ3outxIWX9CDhALzxxrkd45975/aewo0ytLTxTtxtIgy1lyXutawRUmWBQ2oyABZzeezz0GR6F5e3bahSm9hxRStzc/B0rzb+QBmFTRnIVgN0xYOAMNODMEv3MQaXASvNvtWUGV76gSrZ96oJ8fybqfbYk+/+goNxScJ+3FeBZVyfv+/m9Hyvb6VwlBPPN2juTzklnBJrZFWqcSjl19gu7abdl7SggxKTOy5wKw1jeuo2r9Qr6Cbm66Ry7gliO6rzMCvDmdaWbm79hceOHvlq+g+q3Fe4gNqEJC+vH7givaBvbQAI4PXp5efhFVbztNm4FtFo4hickv1hQ5bNmlkqJ5Ry4FBAWNGHh2d+9cBnBRVv/EW1jdxSQtOgUg8WNH31HgatT3voJrSlZznFHAVoxQwyCRoE5nS8ExgO7GNdRPFK851GLi9ySvzrHXcXcmf9LfwDxurDLT32A8VyvEKwgF3Tu4m16+HhXdepQqX+PysZ1aGItPFNu9wVdWYi0iT0Dcb/rBwvJ/YJTN3FFGhTkhfzJOG635D7pTqM2vkNM2MJX71/zvecowcJFBbdu8FNTM+8+7+nIyI1u0S52XcQCFEZeRxreXfskquXsch+mZyITTXyOBFQa5McNbT/2xemtgzCkmPVe810XShLMDuzzFw6c8w3sMDT65R7rM76lBLVtZ5EQjokP1y8HptggFhvhz/tZnwlcmaNRuEK7ElLgzMxR/TP3D1/d/zbskTJZ/5LfjailxRtZrEizIlNDL6iCj4/zxk4q5a5NowS3xDqOzR/2X1oMX9ylb15yWK1SmBgMltikVYjnEizuOgxQiUjhmch+gH+AfwiuEnYXqOoIz2g1NEoJA8fAn3/6T5l8Xkt4Jv5Hvn9p7TSnlh9NZIvVWvuMlX+Tf2bNTpEq5fjy3PgufWb1crZ26YRtyyIdzkBfGYu2Clm8EtfiXjL/q4HYJ16SNisiR9tf7gXWBLWsFEeWAaP69dhnsbq/xzzKPASrBtX9Qgv9FwAAAABJRU5ErkJggg==); background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                <uni-resize-sensor>
                                    <div>
                                        <div></div>
                                    </div>
                                    <div>
                                        <div></div>
                                    </div>
                                </uni-resize-sensor>
                                <img
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAS+SURBVHgB7Zo9bBxVEMf/b89x4ksAG0xBguyNSOEGkSCRylJMQ+i4NmlyCalASi6CAiEBRjQUQTmQ6ADbTShzdMFNDKICKTkEhYtELJYACUzOspI7x/bty8zz7d3e3n68/Thfivyk1X6fZubNzJt5e8BjBotAhhT/KZnYg6PIiUnY0qRLo61bFgyxhqb8EzlU58fKFjIitQLF/0ozMPAG/VJBSphaLwlYQmIJNhbmny0vIQWJFSiulook+EUS+ijSQMoYQszOjV1ZQAJiK8AWlznMQdfa+pIkUkRbgWKtNEpDPiuBi+gjJFCZRvZjipM1zeejIeFNcpVrSOsuunCMCLyqE+yRCrSEv5G5y0ShqUSoAgMT3kFDiUAF2OdJ+FtJhR83nsb5A6eQxwi+uPcNVu27SIRAtaWEb0wYgS9SwKax/PTeVzA1dAQTQ4fUcWI47mx8FHTbVwHO8Wmzjdviq82E1m9BspTUhOnDkO8LBmksEUlejOC1fSfIXcbU+fL2Hfz04Oed4607al+pX1fXCyMn6d4viV1JzT3AYe/1nhhQ1hfq4VAmcofw3pNvKyXcsICfrn+p9hO5g7Q9j9P7C+q5umzgrdr7SIphiKJ3outxIWX9CDhALzxxrkd45975/aewo0ytLTxTtxtIgy1lyXutawRUmWBQ2oyABZzeezz0GR6F5e3bahSm9hxRStzc/B0rzb+QBmFTRnIVgN0xYOAMNODMEv3MQaXASvNvtWUGV76gSrZ96oJ8fybqfbYk+/+goNxScJ+3FeBZVyfv+/m9Hyvb6VwlBPPN2juTzklnBJrZFWqcSjl19gu7abdl7SggxKTOy5wKw1jeuo2r9Qr6Cbm66Ry7gliO6rzMCvDmdaWbm79hceOHvlq+g+q3Fe4gNqEJC+vH7givaBvbQAI4PXp5efhFVbztNm4FtFo4hickv1hQ5bNmlkqJ5Ry4FBAWNGHh2d+9cBnBRVv/EW1jdxSQtOgUg8WNH31HgatT3voJrSlZznFHAVoxQwyCRoE5nS8ExgO7GNdRPFK851GLi9ySvzrHXcXcmf9LfwDxurDLT32A8VyvEKwgF3Tu4m16+HhXdepQqX+PysZ1aGItPFNu9wVdWYi0iT0Dcb/rBwvJ/YJTN3FFGhTkhfzJOG635D7pTqM2vkNM2MJX71/zvecowcJFBbdu8FNTM+8+7+nIyI1u0S52XcQCFEZeRxreXfskquXsch+mZyITTXyOBFQa5McNbT/2xemtgzCkmPVe810XShLMDuzzFw6c8w3sMDT65R7rM76lBLVtZ5EQjokP1y8HptggFhvhz/tZnwlcmaNRuEK7ElLgzMxR/TP3D1/d/zbskTJZ/5LfjailxRtZrEizIlNDL6iCj4/zxk4q5a5NowS3xDqOzR/2X1oMX9ylb15yWK1SmBgMltikVYjnEizuOgxQiUjhmch+gH+AfwiuEnYXqOoIz2g1NEoJA8fAn3/6T5l8Xkt4Jv5Hvn9p7TSnlh9NZIvVWvuMlX+Tf2bNTpEq5fjy3PgufWb1crZ26YRtyyIdzkBfGYu2Clm8EtfiXjL/q4HYJ16SNisiR9tf7gXWBLWsFEeWAaP69dhnsbq/xzzKPASrBtX9Qgv9FwAAAABJRU5ErkJggg=="
                                    draggable="false"></uni-image>
                        </uni-view>
                    </uni-view>
                    <uni-view data-v-048725ca="" class="ListBox" style="height: 100%;">
                        <uni-view data-v-048725ca="" class="swiper_item" id="product">
                            @foreach(\App\Models\Package::whereStatus('active')->get() as $element)

                                <uni-view data-v-048725ca="" class="auto90 boxOne radius30">
                                    <uni-view data-v-048725ca="" class="Blod title auto90" style="display: flex;justify-content: space-between;width: 90%;">
                                        <div>Product</div>
                                        <div>{{$element->name}}</div>
                                    </uni-view>
                                    <uni-view data-v-048725ca="" class="innerBox  ">
                                        <uni-view data-v-048725ca="" class="flexStart box_under">
                                            <uni-view data-v-048725ca="" class="listImg">
                                                <uni-image data-v-048725ca="" style="height: 76px;">
                                                    <div
                                                        style="background-image: url({{asset($element->photo)}}); background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                                    <uni-resize-sensor>
                                                        <div>
                                                            <div></div>
                                                        </div>
                                                        <div>
                                                            <div></div>
                                                        </div>
                                                    </uni-resize-sensor>
                                                    <img src="{{asset($element->photo)}}"
                                                         draggable="false"></uni-image>
                                            </uni-view>
                                            <uni-view data-v-048725ca="" class="innerRight">
                                                <uni-view data-v-048725ca="" class="ListShow Bold">
                                                    <uni-view data-v-048725ca="" class="boxItem flexBetween">
                                                        <uni-view data-v-048725ca="" class="f20">Cycle</uni-view>
                                                        <uni-view data-v-048725ca=""
                                                                  class="f24 Blod">{{$element->validity}} days
                                                        </uni-view>
                                                    </uni-view>
                                                    <uni-view data-v-048725ca="" class="boxItem flexBetween">
                                                        <uni-view data-v-048725ca="" class="f20">Daily Income</uni-view>
                                                        <uni-view data-v-048725ca=""
                                                                  class="f24">{{price($element->commission_with_avg_amount / $element->validity)}}</uni-view>
                                                    </uni-view>
                                                    <?php
                                                        $hourly = ($element->commission_with_avg_amount / $element->validity) / 24;
                                                    ?>
                                                    <uni-view data-v-048725ca="" class="boxItem flexBetween">
                                                        <uni-view data-v-048725ca="" class="f20">Hourly Income</uni-view>
                                                        <uni-view data-v-048725ca=""
                                                                  class="f24">৳{{number_format($hourly, 3)}}</uni-view>
                                                    </uni-view>
                                                    
                                                    <uni-view data-v-048725ca="" class="boxItem flexBetween">
                                                        <uni-view data-v-048725ca="" class="f20">Cumulative income
                                                        </uni-view>
                                                        <uni-view data-v-048725ca="" class="f24">
                                                            {{price($element->commission_with_avg_amount)}}
                                                        </uni-view>
                                                    </uni-view>
                                                </uni-view>
                                            </uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="priceBox Bold flexBetween">
                                            <uni-view data-v-048725ca="">
                                                {{price($element->price)}}
                                                <uni-text data-v-048725ca=""><span>/Price</span></uni-text>
                                            </uni-view>

                                            <?php
                                            $daily = price($element->commission_with_avg_amount / $element->validity);
                                            $total = price($element->commission_with_avg_amount);
                                            $hourly = price(($element->commission_with_avg_amount / $element->validity) / 24);
                                            $price = price($element->price);
                                            $name = $element->name;
                                            $photo = asset($element->photo);
                                            $url = route('purchase.confirmation', $element->id);
                                            ?>
                                            <?php
                                            $myPackage = \App\Models\Purchase::where('user_id', auth()->id())->where('package_id', $element->id)->first();
                                            ?>
                                            @if($myPackage)
                                                <uni-view data-v-048725ca="" class="boxBtn" style="background: #93d1eea8;">
                                                    Invested
                                                </uni-view>
                                            @else
                                                <uni-view
                                                    data-v-048725ca="" class="boxBtn"
                                                    onclick="buy('{{$url}}', '{{$daily}}', '{{$hourly}}', '{{$total}}', '{{$price}}', '{{$name}}', '{{$photo}}', '{{$element->validity}}')"
                                                >
                                                    Invest Now
                                                </uni-view>
                                            @endif
                                        </uni-view>
                                    </uni-view>
                                </uni-view>
                            @endforeach
                                <div style="height: 100px;"></div>
                        </uni-view>
                    </uni-view>


                    <uni-view data-v-3193bb52="" data-v-048725ca="" class="uni-popup bottom" style="display: none;"
                              id="ppPop">
                        <uni-view data-v-3193bb52="">
                            <uni-view data-v-1a12f82f="" data-v-3193bb52="" class="" name="mask"
                                      onclick="closePurchase()"
                                      style="opacity: 1; position: fixed; inset: 0px; background-color: rgba(0, 0, 0, 0.8); transition: opacity 300ms ease 0ms, -webkit-transform 300ms ease 0ms, transform 300ms ease 0ms; transform-origin: 50% 50%;"></uni-view>
                            <uni-view data-v-1a12f82f="" data-v-3193bb52="" class="" name="content"
                                      style="transform: translateY(0px); opacity: 1; position: fixed; left: 0px; right: 0px; bottom: 0px; padding-bottom: 0px; background-color: transparent; transition: -webkit-transform 300ms ease 0ms, transform 300ms ease 0ms; transform-origin: 50% 50%;">
                                <uni-view data-v-3193bb52="" class="uni-popup__wrapper bottom"
                                          style="background-color: transparent;">
                                    <uni-view data-v-048725ca="" class="popupBox" style="width: 100%">
                                        <uni-view data-v-048725ca="" class="topBox flexBetween">
                                            <uni-image data-v-048725ca="">
                                                <div>
                                                    <img
                                                        id="popup3-img"
                                                        style="width: 100%"
                                                        src=""
                                                        draggable="false">
                                                </div>
                                            </uni-image>
                                            <uni-view data-v-048725ca="" class="flexRight">
                                                <uni-view data-v-048725ca="" id="pname"></uni-view>
                                                <uni-view data-v-048725ca="">Price:
                                                    <uni-text data-v-048725ca=""><span id="price">{{price(0)}}</span>
                                                    </uni-text>
                                                </uni-view>
                                                <uni-view data-v-048725ca="" style="display: none;">Purchase quantity
                                                    limit:
                                                    <uni-text data-v-048725ca=""><span>1</span></uni-text>
                                                    /0
                                                </uni-view>
                                            </uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="line"></uni-view>
                                        <uni-view data-v-048725ca="" class="title auto90">Snap up investment shares and
                                            earn stable income every day
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="boxItem flexBetween auto90">
                                            <uni-view data-v-048725ca="" class="f20">Cycle</uni-view>
                                            <uni-view data-v-048725ca="" class="f24 Blod"><span id="validity">0</span>
                                                days
                                            </uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="boxItem flexBetween auto90">
                                            <uni-view data-v-048725ca="" class="f20">Daily Income</uni-view>
                                            <uni-view data-v-048725ca="" class="f24"
                                                      id="dailyIncome">{{price(0)}}</uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="boxItem flexBetween auto90">
                                            <uni-view data-v-048725ca="" class="f20">Hourly income</uni-view>
                                            <uni-view data-v-048725ca="" class="f24"
                                                      id="hourlyIn">{{price(0)}}</uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="boxItem flexBetween auto90">
                                            <uni-view data-v-048725ca="" class="f20">Cumulative income</uni-view>
                                            <uni-view data-v-048725ca="" class="f24" id="total">{{price(0)}}</uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="boxBor">
                                            <uni-view data-v-048725ca="">
                                                <uni-view data-v-048725ca="">Available Balance</uni-view>
                                                <uni-view
                                                    data-v-048725ca="">{{price(auth()->user()->balance)}}</uni-view>
                                            </uni-view>
                                            <uni-view data-v-048725ca="" class="deposit"
                                                      onclick="window.location.href='{{url('deposit')}}'">Top up
                                            </uni-view>
                                        </uni-view>
                                        <uni-view data-v-048725ca="" class="comfirmBtn" onclick="buyPackage()">Invest
                                            now
                                        </uni-view>
                                    </uni-view>
                                </uni-view>
                            </uni-view>
                        </uni-view>
                    </uni-view>
                    @include('app.layout.manu')
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
<input type="hidden" name="buy_url">
@include('alert-message')
<script>
    function buyPackage() {
        window.location.href = document.querySelector('input[name="buy_url"]').value;
    }

    function closePurchase() {
        document.querySelector('uni-view[name="mask"]').style.display = 'none';
        document.querySelector('uni-view[name="content"]').style.display = 'none';
        document.querySelector('#ppPop').style.display = 'none';
    }

    let dailyElement = document.getElementById('dailyIncome');
    let hourlyInElement = document.getElementById('hourlyIn');
    let totalElement = document.getElementById('total');
    let pnameElement = document.getElementById('pname');
    let priceElement = document.getElementById('price');
    let validityElement = document.getElementById('validity');
    let buyBtn = document.getElementById('buyBtn');

    function buy(url, daily, hourly, total, price, name, photo, validity) {
        dailyElement.innerHTML = daily;
        hourlyInElement.innerHTML = hourly;
        totalElement.innerHTML = total;
        pnameElement.innerHTML = name;
        priceElement.innerHTML = price;
        validityElement.innerHTML = validity;

        document.querySelector('uni-view[name="mask"]').style.display = 'block';
        document.querySelector('uni-view[name="content"]').style.display = 'block';
        document.querySelector('#ppPop').style.display = 'block';

        document.querySelector('#popup3-img').src = photo

        document.querySelector('input[name="buy_url"]').value = url
    }
</script>
</body>
</html>
