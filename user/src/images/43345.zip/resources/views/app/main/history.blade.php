<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + calc(44px + env(safe-area-inset-top))); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dairy Record </title>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <style type="text/css">.uni-app--showtabbar uni-page-wrapper {
            display: block;
            height: calc(100% - 55px);
            height: calc(100% - 55px - constant(safe-area-inset-bottom));
            height: calc(100% - 55px - env(safe-area-inset-bottom));
        }

        .uni-app--showtabbar uni-page-wrapper::after {
            content: "";
            display: block;
            width: 100%;
            height: 55px;
            height: calc(55px + constant(safe-area-inset-bottom));
            height: calc(55px + env(safe-area-inset-bottom));
        }

        .uni-app--showtabbar uni-page-head[uni-page-head-type="default"] ~ uni-page-wrapper {
            height: calc(100% - 44px - 55px);
            height: calc(100% - 44px - constant(safe-area-inset-top) - 55px - constant(safe-area-inset-bottom));
            height: calc(100% - 44px - env(safe-area-inset-top) - 55px - env(safe-area-inset-bottom));
        }.noCont[data-v-d1639d14] {
             text-align: center;
             width: 100%;
             padding-top: 100px;
             font-size: 14px;
             color: #999
         }

        body.pages-mine-rechargedetail-rechargedetail uni-page-body {
            background-color: #eff1f6
        }

        body.pages-mine-rechargedetail-rechargedetail {
            background-color: #eff1f6
        }

        .item {
            background: #fff;
            margin: 11px;
            padding: 11px;
            border-radius: 5px;
            font-size: 15px;
        }
        .title {
            color: #999;
            margin-bottom: 5px
        }

        .txt {
            color: #3ab370
        }
        .item {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body class="uni-body pages-mine-rechargedetail-rechargedetail">

<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/mine/rechargedetail/rechargedetail">
        <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head" style="background-color: rgb(232, 97, 97); color: rgb(0, 0, 0);">
                <div class="uni-page-head-hd" onclick="window.location.href='{{route('profile')}}'">
                    <img style="width: 20px;height: 20px;" src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                    <div class="uni-page-head-ft"></div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;"> Dairy  Record</div>
                </div>
                <div class="uni-page-head-ft"></div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head>
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-d1639d14="">
                    <div data-v-d1639d14="" class="content">
                        <uni-view data-v-67b88ecc="" data-v-d1639d14=""
                                  style="position: fixed; bottom: 60px; right: 15px;">
                            <uni-image data-v-67b88ecc="" class="customer">
                                <div style="background-image: url({{asset('public')}}/4e640eb3.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                <img src="{{asset('public')}}/4e640eb3.png" draggable="false"></uni-image>
                        </uni-view>
                        <uni-view data-v-d1639d14="" class="list">

                            @foreach(\App\Models\UserLedger::where('user_id', auth()->id())->orderByDesc('id')->get() as $element)
                            <uni-view data-v-d1639d14="" class="item display-between-center">
                                <uni-view data-v-d1639d14="" class="flex1">
                                    <uni-view data-v-d1639d14="" class="title">Time</uni-view>
                                    <uni-view data-v-d1639d14="" class="font-size-24">{{$element->created_at->format('Y-m-d')}}</uni-view>
                                </uni-view>
                                <uni-view data-v-d1639d14="" class="flex1 text-center">
                                    <uni-view data-v-d1639d14="" class="title">Amount({{currency()}})</uni-view>
                                    <uni-view data-v-d1639d14="">{{price($element->amount)}}</uni-view>
                                </uni-view>
                                <uni-view data-v-d1639d14="" class="flex1 text-right">
                                    <uni-view data-v-d1639d14="" class="title">Histories</uni-view>
                                    <uni-view data-v-d1639d14="" class="txt"> {{$element->perticulation}}</uni-view>
                                </uni-view>
                            </uni-view>

                            @endforeach

                        </uni-view>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
</body>
</html>
