<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: calc(55px + env(safe-area-inset-bottom));">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Device</title>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public')}}/static/order.css">
    <style>
        .money[data-v-7bea9402] {
            display: flex;
            align-items: center;
            background: url({{asset('public')}}/static/vf1.png) no-repeat;
            background-size: 100% 100%;
            padding: 3px 25px 3px 8px;
            font-weight: 600
        }

        .money .rs_bef[data-v-7bea9402] {
            background: url({{asset('public')}}/static/sdd.png) no-repeat;
            background-size: 100% 100%;
            width: 21px;
            height: 22px;
            padding-top: 1px;
            margin-right: 5px
        }

        .device .topdevice .leftexit[data-v-7bea9402] {
            background: url("{{asset('public')}}/2c580da3.png") no-repeat;
            background-size: 100% 100%;
            width: 50%;
            height: 66px;
            line-height: 66px;
            position: relative;
            font-weight: 600;
            font-size: 28px;
            color: #94512a
        }

        .device .teamtitle p[data-v-7bea9402] {
            background: url("{{asset('public')}}/783b195d.png");
            background-repeat: no-repeat;
            background-size: 100% 100%;
            z-index: 1000
        }

        .receisd {
            font-size: 16px !important;
            text-transform: capitalize;
            background: rgb(229, 94, 80);
            padding: 4px 11px;
            border-radius: 50px;
            color: #fff !important;
        }
    </style>
</head>
<body class="uni-body pages-steady-index" style="overflow: visible;">
<uni-app class="uni-app--showtabbar uni-app--maxwidth">
    <uni-page data-page="pages/steady/index">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-7bea9402="">
                    <div data-v-7bea9402="" class="device">
                        <div data-v-7bea9402="" class="teamtitle "><p data-v-7bea9402="">Device</p></div>
                        <div data-v-7bea9402="" class="topdevice flex">
                            <div data-v-7bea9402="" class="leftexit"><p data-v-7bea9402="">
                                    {{\App\Models\Purchase::where('user_id', auth()->id())->where('status', 'active')->count()}}
                                </p><span data-v-7bea9402=""
                                                                                                      class="title">My device</span>
                            </div>
                            <div data-v-7bea9402="" class="leftexit ">
                                <div data-v-7bea9402="">
                                    <p data-v-7bea9402="" style="position: relative;">
                                        <?php
                                        $refer_commission = \App\Models\UserLedger::where('user_id', auth()->id())->where('reason', 'my_commission')->sum('amount');
                                        ?>
                                        <span>{{price($refer_commission)}}</span>
                                        <i data-v-7bea9402="" class="van-icon van-icon-arrow" style="font-size: 16px; position: absolute; right: 5px; top: 50%; transform: translateY(-50%);"></i>
                                    </p><span data-v-7bea9402="" class="title">Device income</span></div>
                            </div>
                        </div>
                        <uni-view data-v-7bea9402="" class="display-center-center m-19-0  device_font">
                            <uni-view data-v-7bea9402="" class="first_d"></uni-view>
                            <uni-view data-v-7bea9402="" class="sec_d"></uni-view>
                            <uni-view data-v-7bea9402="" class="three_d"></uni-view>
                            <uni-view data-v-7bea9402="" style="margin-right: 5px; padding: 0px 11px;">Device list
                            </uni-view>
                            <uni-view data-v-7bea9402="" class="three_d"></uni-view>
                            <uni-view data-v-7bea9402="" class="sec_d"></uni-view>
                            <uni-view data-v-7bea9402="" class="first_d"></uni-view>
                        </uni-view>


                        <div data-v-7bea9402="" class="tabs-box van-tabs van-tabs--card">
                            <div data-v-7bea9402="" class="van-tabs__wrap">
                                <div data-v-7bea9402="" role="tablist" class="van-tabs__nav van-tabs__nav--card"
                                     style="border-color: rgb(229, 94, 80);">
                                    <div data-v-7bea9402="" role="tab" aria-selected="true" class="van-tab tttbtn  van-tab--active select_active" onclick="activeTab(this, 'one')">
                                        <span data-v-7bea9402="" class="van-tab__text van-tab__text--ellipsis">Purchased device</span>
                                    </div>
                                    <div data-v-7bea9402="" role="tab" class="van-tab tttbtn select_noactive" onclick="activeTab(this, 'two')">
                                        <span data-v-7bea9402="" class="van-tab__text van-tab__text--ellipsis">Already expired</span>
                                    </div>
                                </div>
                            </div>
                            <div data-v-7bea9402="" class="van-tabs__content">
                                <div data-v-7bea9402="" role="tabpanel" class="van-tab__pane tabOne">

                                    @foreach(\App\Models\Package::whereIn('id', my_active_vips())->where('status', 'active')->get() as $element)
                                        <?php
                                        $pa = \App\Models\Purchase::where('user_id', auth()->id())->where('package_id', $element->id)->where('status', 'active')->first();
                                        ?>
                                        <div data-v-7bea9402="" class="device-list">
                                            <div data-v-7bea9402="" role="feed" class="van-list">
                                                <div data-v-7bea9402="" class="device-item">
                                                    <div data-v-7bea9402="" class="van-image"><img data-v-7bea9402=""
                                                                                                   src="{{asset($element->photo)}}"
                                                                                                   class="van-image__img">
                                                    </div>
                                                    <div data-v-7bea9402="" class="deviceDetails"><p data-v-7bea9402=""
                                                                                                     class="deviceTitle">{{$element->title}}</p>
                                                        <uni-view data-v-7bea9402="" class="display-around-center"
                                                                  style="text-align: center;">
                                                            <div data-v-7bea9402="" class="item"><span
                                                                    data-v-7bea9402="">Daily income:</span>
                                                                <p data-v-7bea9402=""
                                                                   class="zcolor">{{price($element->commission_with_avg_amount / $element->validity)}}</p>
                                                            </div>
                                                            <div data-v-7bea9402="" class="item"><span
                                                                    data-v-7bea9402="">Total revenue:</span>
                                                                <p data-v-7bea9402=""
                                                                   class="zcolor">{{price($element->commission_with_avg_amount)}}</p>
                                                            </div>
                                                            <div data-v-7bea9402="" class="item"><span
                                                                    data-v-7bea9402="">Invest Amount:</span>
                                                                <p data-v-7bea9402=""
                                                                   class="zcolor">{{price($element->price)}}</p></div>
                                                        </uni-view>
                                                        <div data-v-7bea9402="" class="item "><span data-v-7bea9402="">Device days:</span><span
                                                                data-v-7bea9402=""
                                                                class="zcolor">{{$element->validity}}</span>
                                                            <div data-v-7bea9402="" class="finishow">
                                                                <p data-v-7bea9402="" class="schedule">
                                                                    <span data-v-7bea9402="" style="width: 0%;"></span>
                                                                </p>
                                                                <p data-v-7bea9402="" class="jindu" style="left: 0%;">
                                                                    100%</p></div>
                                                        </div>
                                                    </div>
                                                    <div data-v-7bea9402="" class="receive-container flex">
                                                        <uni-view data-v-7bea9402="">
                                                            <p data-v-7bea9402="" class="money">
                                                                <uni-view data-v-7bea9402="" class="rs_bef"><span
                                                                        data-v-7bea9402="">{{currency()}}</span>
                                                                </uni-view>
                                                                <uni-text data-v-7bea9402="" style="font-weight: 600;">
                                                                    <span></span></uni-text>
                                                            </p>
                                                        </uni-view>
                                                        <uni-view data-v-7bea9402=""></uni-view>
                                                        <uni-view data-v-7bea9402="" style="display: flex;">
                                                            <p data-v-7bea9402="" class="display-between-center">
                                                                <strong data-v-7bea9402="" style="color: rgb(229, 94, 80);">
                                                                    + <span class="amm{{$element->id}}">{{currency(). $pa->streaming_amount}}</span>
                                                                </strong>
                                                            </p>

                                                            <p data-v-7bea9402="" class="display-between-center"
                                                               style="margin-left: 20px;"
                                                               onclick="received_amount('{{$element->id}}', '{{$pa->id}}')">
                                                                <strong data-v-7bea9402="" class="receisd received{{$element->id}}">
                                                                    receive
                                                                </strong>
                                                            </p>
                                                        </uni-view>
                                                    </div>
                                                </div>
                                                <div data-v-7bea9402="" class="van-list__finished-text"></div>
                                                <div data-v-7bea9402="" class="van-list__placeholder"></div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>

                                <div data-v-7bea9402="" role="tabpanel" class="van-tab__pane tabTwo" style="display: none;">

                                    @foreach(\App\Models\Package::whereIn('id', in_active_vips())->where('status', 'active')->get() as $element)
                                        <?php
                                        $pa = \App\Models\Purchase::where('user_id', auth()->id())->where('package_id', $element->id)->first();
                                        ?>
                                        <div data-v-7bea9402="" class="device-list">
                                            <div data-v-7bea9402="" role="feed" class="van-list">
                                                <div data-v-7bea9402="" class="device-item">
                                                    <div data-v-7bea9402="" class="van-image"><img data-v-7bea9402=""
                                                                                                   src="{{asset($element->photo)}}"
                                                                                                   class="van-image__img">
                                                    </div>
                                                    <div data-v-7bea9402="" class="deviceDetails"><p data-v-7bea9402=""
                                                                                                     class="deviceTitle">{{$element->title}}</p>
                                                        <uni-view data-v-7bea9402="" class="display-around-center"
                                                                  style="text-align: center;">
                                                            <div data-v-7bea9402="" class="item"><span
                                                                    data-v-7bea9402="">Daily income:</span>
                                                                <p data-v-7bea9402=""
                                                                   class="zcolor">{{price($element->commission_with_avg_amount / $element->validity)}}</p>
                                                            </div>
                                                            <div data-v-7bea9402="" class="item"><span
                                                                    data-v-7bea9402="">Total revenue:</span>
                                                                <p data-v-7bea9402=""
                                                                   class="zcolor">{{price($element->commission_with_avg_amount)}}</p>
                                                            </div>
                                                            <div data-v-7bea9402="" class="item"><span
                                                                    data-v-7bea9402="">Invest Amount:</span>
                                                                <p data-v-7bea9402=""
                                                                   class="zcolor">{{price($element->price)}}</p></div>
                                                        </uni-view>
                                                        <div data-v-7bea9402="" class="item "><span data-v-7bea9402="">Device days:</span><span
                                                                data-v-7bea9402=""
                                                                class="zcolor">{{$element->validity}}</span>
                                                            <div data-v-7bea9402="" class="finishow">
                                                                <p data-v-7bea9402="" class="schedule">
                                                                    <span data-v-7bea9402="" style="width: 0%;"></span>
                                                                </p>
                                                                <p data-v-7bea9402="" class="jindu" style="left: 0%;">
                                                                    100%</p></div>
                                                        </div>
                                                    </div>
                                                    <div data-v-7bea9402="" class="receive-container flex">
                                                        <uni-view data-v-7bea9402="">
                                                            <p data-v-7bea9402="" class="money">
                                                                <uni-view data-v-7bea9402="" class="rs_bef"><span
                                                                        data-v-7bea9402="">{{currency()}}</span>
                                                                </uni-view>
                                                                <uni-text data-v-7bea9402="" style="font-weight: 600;">
                                                                    <span></span></uni-text>
                                                            </p>
                                                        </uni-view>
                                                        <uni-view data-v-7bea9402=""></uni-view>
                                                        <uni-view data-v-7bea9402="" style="display: flex;">
                                                            <p data-v-7bea9402="" class="display-between-center">
                                                                <strong data-v-7bea9402="" style="color: rgb(229, 94, 80);">
                                                                    + <span class="amm{{$element->id}}">{{price($pa->streaming_amount)}}</span>
                                                                </strong>
                                                            </p>

                                                            <p data-v-7bea9402="" class="display-between-center"
                                                               style="margin-left: 20px;">
                                                                <strong data-v-7bea9402="" class="receisd received{{$element->id}}">
                                                                    Expired
                                                                </strong>
                                                            </p>
                                                        </uni-view>
                                                    </div>
                                                </div>
                                                <div data-v-7bea9402="" class="van-list__finished-text"></div>
                                                <div data-v-7bea9402="" class="van-list__placeholder"></div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div data-v-9d7f1624="" class="van-overlay loading"
                             style="background: rgba(0, 0, 0, 0); display: block;">
                            <div data-v-9d7f1624="" class="loading-box-h">
                                <div data-v-9d7f1624="" class="van-loading van-loading--spinner van-loading--vertical">
                                    <span data-v-9d7f1624="" class="van-loading__spinner van-loading__spinner--spinner"
                                          style="width: 30px; height: 30px;"><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i><i data-v-9d7f1624=""></i><i
                                            data-v-9d7f1624=""></i>
                                    </span>
                                    <span data-v-9d7f1624="" class="van-loading__text">Loading...</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
    @include('app.layout.manu')
</uni-app>
@include('alert-message')
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
    window.addEventListener('load', function () {
        document.querySelector('.loading').style.display = 'none';
    })

    function received_amount(pid, id) {
        document.querySelector('.loading').style.display = 'block';
        var received = document.querySelector('.received'+pid);
        var amm = document.querySelector('.amm'+pid);

        received.innerHTML = 'Receiving...';
        $.ajax({
            url: "{{url('received-amount')}}" + "/" + id,
            type: 'GET',
            dataType: 'json',
            success: function (res) {
                document.querySelector('.loading').style.display = 'none';
                message(res.message);
                received.innerHTML = 'Received';
                amm.innerHTML = res.amount;
                setTimeout(function () {
                    received.innerHTML = 'Receive';
                }, 500)
            }
        });
    }

    function activeTab(_this, tab){
        var elements = document.querySelectorAll('.tttbtn');
        for (let i=0;i<elements.length;i++){
            if (elements[i].classList.contains('select_active')){
                elements[i].classList.remove('select_active');
                elements[i].classList.remove('van-tab--active');
                elements[i].querySelector('span').style.color = '#e55e50'
            }
        }
        _this.classList.add('select_active');
        _this.querySelector('span').style.color = '#fff';

        if (tab == 'one'){
            document.querySelector('.tabOne').style.display='block';
            document.querySelector('.tabTwo').style.display='none';
        }
        if (tab == 'two'){
            document.querySelector('.tabOne').style.display='none';
            document.querySelector('.tabTwo').style.display='block';
        }
    }

    window.onload = function() {
        $.ajax({
            url: "{{url('commission-interest')}}",
            type: 'GET',
            success: function(res) {
                console.log(res);
            }
        });
    };
</script>
</body>
</html>
