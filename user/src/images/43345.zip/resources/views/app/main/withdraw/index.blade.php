<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Withdrawal</title>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public/withdraw.css')}}">
</head>
<body class="uni-body pages-mine-withdrawal">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/mine/withdrawal">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-1db404bd="">
                    <div data-v-1db404bd="" class="withdraws">
                        <div data-v-1db404bd="" class="navboxi  van-hairline--bottom">
                            <div data-v-1db404bd="" class=" display-center-center">
                                <div data-v-1db404bd="" class="van-nav-bar__left"
                                     onclick="window.location.href='{{route('dashboard')}}'">
                                    <img style="width: 20px;height: 20px;"
                                         src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                                </div>
                                <div data-v-1db404bd="" class="van-nav-bar__center van-ellipsis">Balance Withdraw</div>
                                <div data-v-1db404bd="" class="van-nav-bar__right"
                                     onclick="window.location.href='{{route('withdraw.history')}}'">
                                    <img data-v-1db404bd=""
                                         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB8CAYAAACi9XTEAAAAAXNSR0IArs4c6QAAC4JJREFUeF7tnXuMHVUdx7+/2W3vnXPm7raWliJCKAhCBAqIykOR2koQ+EMDfyAgKG9RaIJBUIyPBJ9BoQRFQIMBSjUQRHlEo0iREEIBgcICgtCIARqXdsveOWcuZff8zOwD9nVnzty5d/dO75k/d77nd37n+zm/nTlz50GYYWPm+VrrM4hoJTOOIYKYSef+Zu+AMfx3Iu+OoaHtd/X29m61b5lPSVObK1U7FzCXA9g9X2jXuo4D/czm0iAIbpoNh94FzMxlrfU1AJ0zGx27PnCHEP5ZRDTYSi/eBaxUdA/Ax7eyMxd7mgOPCeEfTkTDrfJmBLBS+hcALmhVJy5uogPXSikubJVHFIbblxMNPQlg2vG4VZ26uJMdYKZVQeDf3wpfSCl9O4CTWhHcxbRzgIgeEsI/yk6dTRUDVoBbBmWzrfnqoSFvn97e8kvNjhwDZougw8wcTwS3ZXSAiAIAXnoz7zwpyzek67IpUgEz84Dn0bFCiA3ZQjt17IDW+ghm3AFgl2RH6HtS+t9vtmupgIHWdNzsgbRzvDCMLiPiH6UA/ouU/rHNHocF4Nb862j2QNo53lgVP5yUIxHWCyFWNHscFoD5fCnl9c3uuJPiaa0/xoxHHeAdlLoDvIOCHR+WA+wAwx2DCzwJXAUXGJ5N6g6wjUsF1jjABYZnk7oDbONSgTUOcIHh2aTuANu4VGCNA1xgeDapO8A2LhVY4wAXGJ5N6g6wjUsF1hQasNb6fmbsUWD/66bOjD8Ggbg479gKDTgM1bNE9OG8JrRne7pZSv+MvLk5wHkdbFl7BxiugtNnl6vgdI/mSOEq2FWwxdRzFWxh0txIXAW7CraYeQWvYP0iEfa2GGfhJMxYGwTitLyJFxpwrVZbZYzpyWtCO7Zn5lellI/nza3QgPMOvhPaO8A7OGUH2AF290UXeQ64Ci4yPYvcHWALk4oscYCLTM8idwfYwqQiSxzgItOzyN0BtjCpyBIHuMj0LHJ3gC1MKrLEAS4yPYvcHWALk4oscYCLTM8i90IDVir6FcBLLcZZOAkz/hEE4ud5Ey80YHfbbDp+BzjdozlSuJvu3E13FlPPVbCFSXMjcRXsKthi5rkKtjBpbiSugl0FW8y8Qr8vWqnoOYD3sxhn4SREuEUIcXrexAcGBhaUy+WvMPMqZsQv/Z72CaO2fRmp1vqi4WHeOa8J7dmenqxURPy9haZtWuvdmPnLAJ0/8TsObQu4aSPvsEDMLKIoOo8Zl8SgHeAddALEoGu12pXG8EFSiiOaPUz3zYZmO9pgvCiKdvd9/9UGm9dt5gBndJSZS1rrA5i9fYnMhwDsOiGEYfbWex6/EobhxiVLloQZwzdd7gBbWBp/ET2KohOY+UsAHQ5gp7RmzLyNyNvAjFvD8K07ly5dOidfjnOAE0j19fXNX7Zs2QXM+BqAvdKg1tvPjKrn4Ubf979LRLNa1Q5wHSphGB5L5MXfVd6zUbAztHuDmS4LAv/mJsZMDOUAz2BPGOofE+HS1kGgG4QoryaiWuv6GI3sAE9xOAz1rUQ4teXGEx6IouhzixYtGmxlXw7wBHe11rcwI/c7OWyBMeNFKf2DiCiybZNV5wCPOaaU+i1Aud9LmRUAM9ZL6R/XKsgOMACl1NkA3ZgRjiKip5nx7/facS+ATwFYkCUWEX4qhGjJMb/jAUdRtAczNjJzxQ4KP8nMV0kp/0REb01ts3Xr1t558/yDPc98C6DP2MXEEBE+IYRI/EKpZaxJso4HrLW+nRknWZgXEuF0IcQfLLQjkjCMVhLxrwGb92lTn5T+/raxbXUdDTiuXmP4BQClJMOI8BKAFUKI12yNHdcxc69S0d1E+GRaW2NwcqUifp+my7K/owErpX4D0JkphvUT4eBG4E6AXNI6egTAwUl9MePBIBBHZwGYpu1YwK+//rro6VmwmQhJx97tnkerfN9/KM3ItP0DA7xg/vwo/m+ReHMEs1keBMHGtHi2+zsWsFK14wFzT7JRdJ2U/gW2ZqbpwjA6hYjXplTxJUEgrkyLZbu/YwFrXfsJs/lGPaOI6G2A9xZC/NfWzDQdM3tKRc8TYZ/6Wr5PSnl8Wizb/R0LWCn9GIBD6xtFf5XSP8bWSFtdtaqu8Dy6PEH/ppRisW28NF1HAo5/tI+i6EVm7F7PIGOwulIR16QZmHW/UupQgOLJVW8bNqbrwEql9FzW2DPpOxLw4ODgTl1d3f1JBnZ3dy0vlUpNO9kZ72vsZGsg+ThsDgyC4BkHuEEHBgcHF3V1db85WyZP7IeZfa2jVwDUfaaa2QFuEO1os7kHrF8GaJd6g3CAc+EdAWzzL3q/UqkUr1uburl/0U21c+ZgmzZtKi9ZsnN8+fED9bvjc6WUWX9hSs1eqe2HAENPJAiNMcMHViqVvtRgFoKOPMmKfQlDtZGIDkjw6E4pxYkWHmaSaK2/zoy6FzKYeUsQyNS7Nm077VjASqkbATq7/nGQt0kp9iaixJMxW6NjXXyhI4qiPmbsW78d/VlK/7NZ4iZpOxaw1vpEZqQ8WNbcS5VRFJ1iTPKlSmP4B5WK/LYDnNOBzZs3y0qlZzOAICHU28zmsCAInsrZHbZs2dJTKvmPJV+mhGE2hwRB8HTe/sbbd2wFjx6H9ToinJxkZnxjnDFDR/b09OT6V62U3gDgo8ngmv+jf0cDrlarR3le14MW1fIUwMdJKd+w0E6SMHOX1tFVAC5MaxtPNiHcD/5pPmXar3X0N2ZemdYormQi72Ipy/emacf3V6vV/T2v66bkHzXejfaalCJh2Wbb62RdR1dwbEWtVttreNj8C0CXpYWPE+FnSql7Fy9eXJ3apr+/v1IqBcs9z5xFRPEN9PMs48bfTlrr+/4XiYht26TpOh7w6LE4+iYR/zDNrIn7iahqDD9FxBNum/V2YzYfIaKFWWJN1DLjNilHIJtGY0zKUymdMlv4fCnl9c3orF1jjK5Pa7cy8xfaIcdmQnYVPEaUmSmKooeYcWSbQF4npX9a3kp2gCfQDMP4bUHRWiKknnTNxiQgwjrf90/Nc0x2gKeQiitZ61r8DuxzZwNiWh9EtM73yw1DdoDrOBxF0enG8BUAdkuD0Or9zIj/XTcE2QFOoDN6Y8C81QDHFykyPVA25Yw7AvhaZvjAyOsgMm9jJ17xMTnTEsoBtrCamd+nlDqTyPs8gI9nWDM/AdDd8fNJ409GKKXjG/lSr2rNlFYj62QH2ALwRInWetfhYRze3U0fNAYzvKPTvAx0/dPz+Bnf9/8zU/gw1GuIcFHGrkfkWZdQDnAjLjehTRiGa4i8lkN2gJsAq9EQWuurmbG6kfZjJ16p62QLwN55UpZvaCQJ1ybdgTyQbdbJFoCxQQh/5Wy/wCvdmh1HkQcyM34npX9KvbNrG8Cxk/9j5vs8jxKfBthxLG/JSLz4DNwYPBIEYtpDb1rrNcwNn3jVXSfbAm7JiDs46C+lFF+dOv48S6h662RSKtoIcNLtox3MoaVDbzrkmdbJpJQ6ByB3EtVSlvWC03VClC8kouGJimauk0c+DhGGej3RyPud3Da7DmwTwl9GRNumdpvnxIuIbvP98shNAyOAx9428zCA98/u+Dq7N2ZcEwSi7jo4H+SxnxrHLR4cHNynq6v7AQd51ibdq9u3v7184cKF06p3YgZ5IMcXQyZ9v4eZe7Su3QZw094RMWt2Faoj3mxM96crldLzNmnnuaw57QNNcYda68OYcTGAE4CRn7jc1gQHxi4W3UWE7/i+vylLyMbWydQ3I+DxjuOKVuqdPYneOQRAOUtCTjvNgUer1eoLeb7dkG2dzM8JIY5OBOwgtZ8DdpVMfcYMrahUKv0OcPsxTM0oeZ38Htw4kAOcamd7CmY+u6ZnhSivmPhMswPcnvysspoMmftGjrlTHlh3gK2sbF/R6DGZjzbGrIqPuVMz/T+B0vsOkrATPQAAAABJRU5ErkJggg=="
                                         style="width: 27px; right: 27px;">
                                </div>
                            </div>
                        </div>
                        <div data-v-1db404bd="" class="apply-amount">
                            <div data-v-1db404bd="" class="balance-text display-between-center">
                                <div data-v-1db404bd="" class="display"><img data-v-1db404bd=""
                                                                             src="{{asset('public')}}/0cd31bfa.png"><span
                                        data-v-1db404bd="">Account Balance</span></div>
                                <div data-v-1db404bd=""><span data-v-1db404bd=""
                                                              class="money">{{price(auth()->user()->balance)}}</span>
                                </div>
                            </div>
                            <div data-v-1db404bd="" class="page-title enterti"><p data-v-1db404bd="">Withdrawal amount</p></div>
                            <form action="{{route('user.withdraw.request')}}" method="post">
                                @csrf
                                <div data-v-1db404bd="" class="amount-input">
                                    <div data-v-1db404bd="" class="van-cell van-field">
                                        <div data-v-1db404bd="" class="van-cell__title van-field__label" style="width: 16%;"><img data-v-1db404bd="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFcAAABXCAYAAABxyNlsAAAAAXNSR0IArs4c6QAAC2tJREFUeF7tnX9oW9cVx7/nPtlRtyx2tkBcSU4Tli4pDSxjLUshoy5kkC4/pEHKnMVyXNqxhgaaMUYz2kFHE2hZoS1racZSZltOE+gPS7a7ZjQlHng0hQwyloJTZ8SNJcdlzmI1GXVtvXem+2S5ji1L7z29pydHfv8k1rs/zv28o/vOPffcI4IL1/mHGpZ+82u16zRVq4OggGAKMBBgwgowlgJYQaT/CzBWIPv/GbIyMEbAWKYMjzLoBohHM59RnEGDgrURElq8/9PrFx7o7U2VeqjkZIenGxo8dwaW303E94CwEeD1ADYAVOdkv7naZuaLIOoncL+m0ZlqBedWtkX/7aQctsK91NLg9arLf6BB28qEBgAbCeR1cgDFtK1rP/MZEHo1Ru/FoeQ/7NTwouF+tnvnypRHbAe4kQmbyxlmwQfBuMGEKIF7rn2RfHfDm703CtbJU8ASXKmhVdryn4K5hTIaestdDB4H0CMYRy8MJT+wotGm4H62N/TtFOMAGC25XjK3HOGpATEjDvCRyev06ppoNPMSNXAZgpto2rmOhXiamBtB5DHQ7i1ZRM7RYLSKlHrYd7x7tNAg88K9FArVVi/Ds2B+rJKhzoY4BfnQwNDYy/mmi3nhXmnauU0jagXRikJPqILvnxOkNt3e1v1xLgZz4Oq2aX3NH4josQqGZnjo8sUngAO+9tgfZ1e6Ca5cOS331nSCaIvh1hcLZl97L/jbY7+eiWMarjSvqtXa90HYvMjLGgFmvBSIRH+ZrT0NNxEOHk8vDxutNbtYa5oA835/JPaq/FuHO9y0cw8L0bGIyAYCzCmN+a76jq6LpM+zt9UMuOFMsWEo5dpEj789uoMWtdaZ58Pql/WUCIc6QQg500Xltpr2Kx+gRDg4AKK1lYvBmZET8xGpudcryQnjDMqcrfZQojl0CcDqEnZaGV0xWuW08B6ItlbGiEs5Sj5IV8LBxzWiV0rZbSX0xSl8j4Z371ihVSkDBNRWwqBLM0Y+42+P3aev0BLNwScBeq40Hd/6vaQmUz+843hPnw5Xuhm/U197etFpY8eD52nv2FdesYd+XFd9W/WHi5aDdcAEfuvC5eTu7O7ETf7cSzrgqtMAyeCNxcsEgdlgp71iM9uQLzj2COl+XHSYG4bLL3xyOfmb2ftpJOfb2R/Kz9bX1z6hgZ9b3JjMQ5gRZ03dFzjW3ZOrFF1pDK2+/UR0MNfNy+FtGxR4XqwILWYelbFkYFwEYVDTtKuCMKqxGJFsFFUdIVZkoMj0dVUdG80XlaO7HH0dXcfyfQPie3ZsJ0V5VsZ+Gf6mlHNBGZQHnCWiM5qqfjT5P6XfTLCH0aFJ30K3dOwaqTDUtHOrIPrVgtNk5lEiOqmq2l9TE6lTa978i66NTl8SLisqttQdi35gtLPh3TvWwyP2MqGlbHcwGHECd6TAb6+KdJ01OjY7y+lwwYhPjE/ca/aJ6osPX00DKbSNgV0gBOwUzmxbmYBofotYbfNFevrM1re7fAZu5jo38cXEg2YBzxQo/rPQRuHB/cxokPG5pfNXcL9gvHJ1PNlWbNinnYBnwpXtDno0Cq3s6PynHZ1Ia4M0ZaMixPfly5DBG+wMjyJGL6t82P9G7JQd8trdxmy48nxBKr1se+bCUPJ5KzGphQSUwX1VX1fXM2itIugO6GchKADmOh0889JCD0BCVRm/q++I9hbqz837c+FOSSPPEAimg76O6NtuCCgfgtc71w2qKl+mAsfei7shk9k+KdEcvJL/jc/96bnzpS9Fsm1Na+9NRrTZziqtvIT7PmDAj8CQR5FOsEonBhJjf3NiyrjV4NNwc/AXDDpiamDy3BfRSaFpJxUVp1Ye7/rMVP0KKUyZ6MaafxUTuyDnZwL1AXxWA84mx5Mfl5NJ5Naz1P25n4a3b/ZAOW2zB2wQzP0M6heEQXmikYjjyoQWrxRNnxlC+njaBCrZLjBn1vs3mKF75KaOmvb4I9HXndA0fZ+Q59kEIO73t8eet7vfm3YiEuHQI/JIkM0abExmRt+18bEHnZpOhsOh01OnOufII+1mXyT6gDFBjZea4ywfago1CEKklH4CZpwfGx+7zymwEocrcOUSdVXk3fMzn4c04Jcs49+nv7ItTmuxdLawpt0rg4WN64T5kq7AHQ4Hn/JFYodzias7YhS8ON/XyfwQ59ZgVd0x3zaJHe1n23AFbiIc/M/Edboznyc+vmfHJhLKk2lTa7udmkzgo7722M/thDhfW+7Azbgc9TDzQoOM73kwQLTkERA3FWMXy37kdCAm1TuNHPMsJJeR+27ClYPtGLg89rDRZW1Gm0WQQduJZIIKcxezti8Q6TK3MjTXxU2lXYWraxOj10upphXtPQkz47jUGFpdVaU7x+8HeHNhreaRCZFcU0pHkOtwp7+u4IMXLidfN6rFsx+EtDY8S7VNROJu0tOusEy9sv6rCHY+6ITRnk8hygJuVsBMThhxaODytWNWIc8erIzmSXlo9efjn/c7adPmglxWcL+CjDgxjpImWn1vvPOpmeminMq6AzccGjK8GmP0gbgHGkf9HV0XygleIVlcgTvcHIow0FRIuBz3BxmQbsY+aOLMQPzax3ZNHxZkKVjFFbi6SaUoMi63qEvmHSDGeYDOg/TcXRcVBYNLmQaXtXdeLapxGyq7AlfKnWgO/imdRe5RG8aQswkdPGiEmE/6IrF9VvuRbkNmiyePSOY4y33uYyqtyjkrchHxyfksH93lmEliUfue02H7xPz0fH4MIwNLhEN/TkcgthgpW7IyjFZ/JPpwrv5uDtv3VnWD6B6nBFM1/GRVRzRqtf0FB1fuoWVXSnoCy9tqX7P4givITNPwQDGBHAsOroxY9B3v7p9JJr4nuIsEXisU+VKQ5pwC/CN/u/XQo4UHtzn0hK89+vJsDpmcYvwUgP3pM2q2JLtkxsOBSLTV/EPJ1FhwcOPh4MDAUPKu+WxUecJnibf6SQYeLf50e3E+hQUHV4aQEuOQLxL9bT6NkvPxt7w1ezXSTTaL4ft81F+Ec1yaYmTRFNMKmGKCYckU43ymWDY+lzTsMhp0N9S0c61CYi+Dt5qyLpjP+iOxe61OC8XUc2URMR38LENHCftzZXbLNyi5OwGxZIvuy82ke503d4NcTEyK5PJS+nGzsrsLNysF84mJ67TP6ukW3a2oKJsVge+mQ+g3aEzrSabTnspeWqw5ZlV7ywOuLj2PMMTBQHtnm9XBzKwnz06sDSxbLQStpkktPtv0s6OPQm2UEdyMqE44zAtBcOq+W3AN5LjhEWh0xKOgw+kM9bcWXLM5HBl9DESJtZ6F5DB3RXOnjp52W9SYQcgTNUS9VcR95azVrsDNLCuD79tx5DTjF+WzRDgHpn4NfL6GxMWKdpbLuIPqav7QsaOm8vcXgEECxyGd5kBcA8Ymr+N1qyaf2W+aa5orBZXeMa1K+bB0px51c+SEPxLbbRaUlfKuws0C5irRWco0LIJ5/+1TyXytQDNax3W4UlDd1fgNvFiy7RTmlKLRVjOn5o0CnVmuLOBmBdKtCCFklhDnM5QybijgLXWR2EdWwBmpU1ZwpcBy2bpuVc0j6RjTZxx72U2TkQsVbnDKdnb9wMl8GqD7BvzLGoWgJ0y5GI2o1MwyzKMewaGVbV1/N1u1HMsb+m2emYJPhfLvZeJGR7RZPwZLTf72zlg5AjMjk2m42cb1KaN+6SaGsi2TltvGRG/MKTAd+iQ+dricQ6QKgbYMd3bDcq9N8XoaPKD70+eCN4H1xBXF/QIV86klpLaYDcYuNOhS3bcN7hzYLQ1eRV22QQD3CIh1TFgL8FqzGq4vqUEH7PItlwqs7McxuPkGIRPFqYpap5FSJ0irIxIrAfaCMz/8STm3ivjMf8eTh0sdNF3Mw/g/WS6bsbsts1YAAAAASUVORK5CYII=" style="width: 31px; height: 31px;"></div>
                                        <div data-v-1db404bd="" class="van-cell__value van-field__value display-between-center">
                                            <div data-v-1db404bd="" class="van-field__body">
                                                <uni-input data-v-1db404bd="" autocomplete="off" class="van-field__control">
                                                    <div class="uni-input-wrapper">
                                                        <div class="uni-input-placeholder input-placeholder" data-v-1db404bd="" style="display: none;">Please enter the recharge amount</div>
                                                        <input maxlength="140" step=""
                                                               name="amount"
                                                               autocomplete="off" inputmode="numeric" type="tel"
                                                               class="uni-input-input"></div>
                                                </uni-input>
                                            </div>
                                            <div data-v-1db404bd=""
                                                 onclick="allSelect()"
                                                 style="margin-right: 11px; padding: 5px 11px; background: rgb(229, 94, 80); color: rgb(255, 255, 255); font-size: 14px;">
                                                ALL
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div data-v-1db404bd="" class="amount-input"
                                     style="background-color: rgb(229, 94, 80); color: rgb(255, 255, 255); padding: 11px;">
                                    <span data-v-1db404bd="">Account Type:</span><span
                                        data-v-1db404bd="">{{auth()->user()->gateway_method}}</span></div>
                                <div data-v-1db404bd="" class="amount-input"
                                     style="background-color: rgb(229, 94, 80); color: rgb(255, 255, 255); padding: 11px;">
                                    <span data-v-1db404bd="">Account:</span><span
                                        data-v-1db404bd="">{{auth()->user()->gateway_number}}</span></div>
                                <div data-v-1db404bd="" class="page-title enterti"><p data-v-1db404bd="">Login password</p>
                                </div>
                                <div data-v-1db404bd="" class="amount-input">
                                    <div data-v-1db404bd="" class="van-cell van-field">
                                        <div data-v-1db404bd="" class="van-cell__value van-cell__value--alone van-field__value">

                                                <div data-v-1db404bd="" class="van-field__body">
                                                    <img data-v-1db404bd="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAABCCAYAAADjVADoAAAAAXNSR0IArs4c6QAACFRJREFUeF7Vm3twG9UVxr+zK8lSoLUdasvW2lATCB06JfRJgMzEpX/Q0NhakajT2F4lUJoWSmeAaQuFJDUJoZQZhrY8BlKa2pJSmFGLHg6Fpo+k08B0aBkyYdJOSx5Q6+EkEFOgsSVZe5o1NnEcy95daRVl/7TP+c53frp3tffqLqFKL/7OsprUsZolgoilTFjMjDYC6gGcp1lmcApMxwSifzHz31Twn1sW/PcV6t01ZqYlMpNkZU6qx3sVC7SWGN0g2IzV4iFi4WnRTo+6tz570Ehu1YBIBnxXAvwTAr5gpIFiscz4jYCxOzyh7f/Ro3fGQRxa0+50qHUPAbhFj2GDMTkG7pOcjQ/Qli352XLPKIjM6hWfVFn9HcCSwQaNhv8pJ9i72/oiQ8USzxiIjOJbqhLvMtqR2XhmHGRWr20NJ/bPpHFGQGS6r/+8Kqovm22qhLxhkQufbQoNHJquUXEQh7uuv3DMph4ooZmSUrWRIdrsi5t/GTk6VaiiINjvd6Sc+XeI4CqpmxKTiemF3aO25V+NRAqTUhUDwQBlAnKYga4S+yhPOvOtUij+WMVBpFd1fILt4j/L00VZVN53qMLChvCzGU2tIiOCe3uF9IE9/wDhkrK0UCYRBj3ZEox+q2IgBrtWXCzYCv8uk/+yyTCQcwj2Cxr7IkMVGRHp1fJOZrSXqYNhYghMqC2LHuNOKRR70HIQR2/s/EhuTHi3FNMEvKGCHpFqRx+jR57PalpvBfzSCOduFYi+iQ9WpaYuBu9tCcYXWQ4i0+29VBVpnymX2nKbEXpqQWxNby/UYhqpgPxHANeYrSEI40t8a690QN7IwHqTVbZKwdjX9eSmA/IuBpbqiZ0eI6i02nIQKUXeB8KlRg0S8G7a2fixz82xapzUHfT7XYIrfwTAucZr0f2WguD2dlv6/LpZl79FTauqVwonEkaaSgXkXwFYZSRHi9X2LiwFMfEpHTdqTIt32NSPNmxNvGckN9Mjt6sCdhrJmQCxy1IQb3Z9pd5msx8zakyL99RmnZPfEHrz+Xa/K/123gz4NywFccDvr3W68u/obWRqnEeoc1Ff36iR3EH/tfMFl+ttIzkTI2K/pSBKmRrOQrb2vG3PG3r+GAr4lhfAAyZAWDs1SrlZkgqfJxyLGWkqqcgJInQYyanIzVIrklS8LxLRVUbNafE5oc7VpnN6HFlzXVNerTkEsNNoLSLebOnU0AylFXkdEzYZNTcezxjwLLhcpt7eok+VWtjry5bVuBpqXiPgYjN1SMXKCoBYfj6T7U0zBie/2mrsamexr9JDa+Q6h4pXAXzcZA0WRLvbchD7/P5z61x57aZXYi36cTZfeJjHakbr64FsLl+vFvhuEH3DJIDxNAJe9gRjV5RoTp+FtOINM1G3vujKRjGrN7eEEk9UBMThmzrdYzmh6I8rlW39ZDUCCs212XO0B7eKgEgFvHcC9MCZarhYXSLa7OmPrpuYItbaG1S8dwlEP7K2iin1457a7PzJx3hLR0Ra8d3FxNUIQbtJKp5gLDyJ0DIQ1QwBjF9IodhNU8eRJSDSivwDJtxvasBancTY7wnGFhKBLQWRDHjvJtBmq/sxo68dNxKc6kLPloHTluplHRFJxXsPEd1nxqTVORoEG49c0hTa8b+ZapUNRFrx3cPEVQmBQL9OOxu6Ztv/LAuIpCKvI7MLK4uHggjqcPdHn5t+T5hetmQQyYC8noCNFvdjRv5xGi58zzNw+v2g7FOj3BBEpk/lR21pwZXX1iUPAxANEWC8Bebv27OOSGMk8r6RXNMjIqV4N4DoXiPFZosVC3xZ07b4a5MxO9vbba2t9fPnAUtU4quJsQKEC07RYNaW3y8xCz+HgKR04aLhufYuij5um2kkpfg2gHhOCKzilnNsePr4mOpmou1EdNFM9USBL2vqOwnBjKdScwyPiFRA/uGJor16CtscapP7qcRhLVY7I5E5+OrXGLRtSi7boF7uDib26tGzMsYQCCMQJkw/LgVj357awJGezovygvC6dpjaLuIzjX2xPVY2qFdbN4hUQNZGgTYajFwjUjA2b3rC4VWd7oJDaPH0x14xImZlrC4QJiFM+Ka9UjC6yMomyqE9J4iU4r0XRBtKKUbMT3hC8ZtL0bA6d1YQuiEQP3NiadsK0NVFDKvEfLsnFP+Z1Q2Z1S8KIhmQN57Y09NxwINelILRJZqBIaWjrQDxp5j+axNjDMxLpXD8JbNGrc6bEYR+COP29kjB2KcnjbLfL2ac2RuZhC3jf2OMEeiLnlB0t9XNlKJ/GggTR31yjpza1vBMIj3VyGCP3C4K2AGBv+Tpi/+lFJOVyD0FhAkIEx75r1IwfuV0w5kb/A3TD39XoikzNT4EkVTkTUQY39o2cwnAhuZgzNxvnGYKljlnHESpEDQNAuW1F9KaQ9FImT1WRI7SiryJdYwEFbhNJOxmpmsA1j75mhkcvqeO2N2tkchIRdyXsQidWD+csptbTFsKxj6cRgdXdbqddvFRBq+cEp8FeLkUjP+hjP4qJqWBSGlnt+asSKpX6j953O/va9faPSNHvjuxbZ+FSh1SOPr7OXWqNEADob3fpONswcxrhsGezm5RFI56+mM7qrRHXba0e8Q+1nkylgjrPf2xqtyp1tXtLEGUVOSdRDpfISBkhQK+3ByOVew1xVIb1JtvDMQHqsMMWtwSjFbdiyh6m54pTgMRJIKiX4RHVZV9reHEC/pzqj+SUgHfVoBv0GOVwaMiY0VzKP5bPfFnUwylA/JDDNwxl2kNAohXtvQnnpsr9mz8PyV7fIsE8BVM3DTeAJEbIBfA85jh1v4kEFpV0G0twej2s7FJPZ7/D0MI6MtYhVX7AAAAAElFTkSuQmCC" style="width: 23px; height: 23px; margin-right: 15px;">
                                                    <input data-v-1db404bd="" placeholder="Please enter your password" name="password" type="password" class="van-field__control" style="font-weight: 400; font-size: 14px; color: rgb(160, 160, 160);">
                                                    <div data-v-1db404bd="" class="van-field__right-icon" onclick="eye()"><i data-v-1db404bd="" class="van-icon  van-icon-closed-eye" style="color: rgb(229, 94, 80); width: 13px; height: 27px;"></i></div>
                                                </div>

                                        </div>
                                    </div>
                                </div>
                                <div data-v-1db404bd="" class="apply-btn" onclick="withdraw()">
                                    <uni-button data-v-1db404bd=""
                                                class="registerBtn van-button van-button--primary van-button--normal van-button--block"
                                                style="background-color: rgb(229, 94, 80);">
                                        <div data-v-1db404bd="" class="van-button__content"><span data-v-1db404bd=""
                                                                                                  class="van-button__text">Withdraw</span>
                                        </div>
                                    </uni-button>
                                </div>
                            </form>
                            <div data-v-1db404bd="" class="van-skeleton van-skeleton--animate">
                                <div data-v-1db404bd="" class="van-skeleton__content"></div>
                            </div>
                            <p data-v-1db404bd="" class="rules-text" style="margin-top: 11px;"></p>
                            <p><b>While withdrawing money, please read the following cautions carefully:
</b></p>
                            <p><b><br></b></p>
                            <p><b>Withdrawal Limit: Minimum Withdrawal Amount: {{price(300)}}
</b></p>
                            <p><b><br></b></p>
                            <p><b> Fees: For each withdrawal, 15% of the withdrawal amount will be deducted as equipment maintenance fee.
</b></p>
                            <p><b><br></b></p>
                            <p><b> Withdrawal Timings: Daily from 11:00 AM to 05:00 PM.
</b></p>
                            <p><b><br></b></p>
                            <p><b> We will process your withdrawal request as soon as possible and it will usually reach your account within 3 X4 hours!
</b></p>
                            <p><b><br></b></p>
                            <p><b>  Withdrawal Requirements:
</b></p>
                            <p><b><br></b></p>
                            <p><b> A paid device purchase is required to unlock the withdrawal function and then you are eligible for withdrawal.</b></p>

                        </div>
                        <div data-v-1db404bd="" class="van-overlay"
                             style="background: rgba(0, 0, 0, 0); display: none;">
                            <div data-v-1db404bd="" class="loading-box-h">
                                <div data-v-1db404bd="" class="van-loading van-loading--spinner van-loading--vertical">
                                    <span data-v-1db404bd="" class="van-loading__spinner van-loading__spinner--spinner"
                                          style="width: 30px; height: 30px;"><i data-v-1db404bd=""></i><i
                                            data-v-1db404bd=""></i><i data-v-1db404bd=""></i><i
                                            data-v-1db404bd=""></i><i data-v-1db404bd=""></i><i
                                            data-v-1db404bd=""></i><i data-v-1db404bd=""></i><i
                                            data-v-1db404bd=""></i><i data-v-1db404bd=""></i><i
                                            data-v-1db404bd=""></i><i data-v-1db404bd=""></i><i data-v-1db404bd=""></i></span><span
                                        data-v-1db404bd="" class="van-loading__text">Loading...</span></div>
                            </div>
                        </div>
                    </div>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
@include('alert-message')
<script>
    var minimumWithdraw = '{{setting('minimum_withdraw')}}';
    function eye() {
        var pass = document.querySelector('input[name="password"]');
        if (pass.type == 'password') {
            pass.type = 'text';
        } else {
            pass.type = 'password';
        }
    }

    function withdraw(){
        document.querySelector('.van-overlay').style.display='block';
        var amount = document.querySelector('input[name="amount"]').value;

        if(amount < 1){
            message('Minimum withdrawal amount enter please');
            document.querySelector('.van-overlay').style.display='none';
            return 0;
        }

        document.querySelector('form').submit();
    }


    var totalAmount = '{{auth()->user()->balance}}';
    function allSelect(){
        document.querySelector('input[name="amount"]').value = totalAmount;
    }

    var bank = '{{$bank}}';
    if (bank == 'nai'){
        document.querySelector('.van-overlay').style.display='block';
        window.location.href = '{{url('add-bank')}}';
    }
</script>
</body>
</html>
