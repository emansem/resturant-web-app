
<div class="header-with-logo">
    <div class="d-flex justify-content-between">
        <div>
            <img class="rng_logo" style="width: 44px !important;" src="{{view_image(setting('logo'))}}">
        </div>
        <div>
            <h4 class="to_time">{{date('Y-m-d')}}</h4>
        </div>
    </div>
</div>
