<uni-tabbar class="uni-tabbar-bottom">
    <div class="uni-tabbar" style="background-color: rgb(255, 255, 255); backdrop-filter: none;">
        <div class="uni-tabbar-border" style="background-color: rgba(0, 0, 0, 0.33);"></div>
        <div class="uni-tabbar__item" onclick="window.location.href='{{url('home')}}'">
            <div class="uni-tabbar__bd" style="height: 55px;">
                @if(\Request::route()->getName() == 'dashboard')
                <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/home_s@2x.png"></div>
                <div class="uni-tabbar__label" style="color: rgb(232, 97, 97); font-size: 12px; line-height: normal; margin-top: 0px;"> Home</div>
                @else
                <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/home.png"></div>
                <div class="uni-tabbar__label" style="color: rgb(153, 153, 153); font-size: 12px; line-height: normal; margin-top: 0px;"> Home</div>
                @endif
            </div>
        </div>
        <div class="uni-tabbar__item" onclick="window.location.href='{{route('ordered')}}'">
            <div class="uni-tabbar__bd" style="height: 55px;">
                @if(\Request::route()->getName() == 'ordered')
                    <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/device_s.png"></div>
                    <div class="uni-tabbar__label" style="color: rgb(232, 97, 97); font-size: 12px; line-height: normal; margin-top: 0px;">Device</div>
                @else
                    <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/device@2x.png"></div>
                    <div class="uni-tabbar__label" style="color: rgb(153, 153, 153); font-size: 12px; line-height: normal; margin-top: 0px;">Device</div>
                @endif
            </div>
        </div>
        <div class="uni-tabbar__item" onclick="window.location.href='{{route('user.team')}}'">
            <div class="uni-tabbar__bd" style="height: 55px;">
                @if(\Request::route()->getName() == 'user.team')
                    <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/team_s.png"></div>
                    <div class="uni-tabbar__label" style="color: rgb(232, 97, 97); font-size: 12px; line-height: normal; margin-top: 0px;"> Team</div>
                @else
                    <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/team@2x.png"></div>
                    <div class="uni-tabbar__label" style="color: rgb(153, 153, 153); font-size: 12px; line-height: normal; margin-top: 0px;"> Team</div>
                @endif
            </div>
        </div>
        <div class="uni-tabbar__item" onclick="window.location.href='{{route('task')}}'">
            <div class="uni-tabbar__bd" style="height: 55px;">
                @if(\Request::route()->getName() == 'task')
                    <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/task_s.png"></div>
                    <div class="uni-tabbar__label" style="color: rgb(232, 97, 97); font-size: 12px; line-height: normal; margin-top: 0px;"> task</div>
                @else
                    <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/task@2x.png"></div>
                    <div class="uni-tabbar__label" style="color: rgb(153, 153, 153); font-size: 12px; line-height: normal; margin-top: 0px;"> task</div>
                @endif
            </div>
        </div>
        <div class="uni-tabbar__item" onclick="window.location.href='{{url('profile')}}'">
            <div class="uni-tabbar__bd" style="height: 55px;">
                @if(\Request::route()->getName() == 'profile')
                <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/me_s.png"></div>
                <div class="uni-tabbar__label" style="color: rgb(232, 97, 97); font-size: 12px; line-height: normal; margin-top: 0px;"> Me</div>
                @else
                <div class="uni-tabbar__icon" style="width: 26px; height: 26px;"><img src="{{asset('public')}}/static/tabBar/me@2x.png"></div>
                <div class="uni-tabbar__label" style="color: rgb(153, 153, 153); font-size: 12px; line-height: normal; margin-top: 0px;"> Me</div>
                    @endif
            </div>
        </div>
    </div>
    <div class="uni-placeholder" style="height: 55px;"></div>
</uni-tabbar>
