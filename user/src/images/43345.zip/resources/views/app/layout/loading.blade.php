{{--<link rel="stylesheet" href="{{asset('public/app/css/loading.css')}}">--}}
{{--<style>--}}
{{--    .loader_boss {--}}
{{--        width: 108px;--}}
{{--        height: 110px;--}}
{{--        background-color: #00000094--}}
{{--    }--}}
{{--    .spinner {--}}
{{--        width: 35px;--}}
{{--        height: 35px;--}}
{{--    }--}}
{{--    .spinner {--}}
{{--        width: 35px;--}}
{{--        height: 35px;--}}
{{--        margin-bottom: 16px;--}}
{{--    }--}}
{{--</style>--}}
{{--<div class="loader_boss" style="display: block">--}}
{{--    <svg class="spinner">--}}
{{--        <circle>--}}
{{--            <animateTransform attributeName="transform" type="rotate" values="-90;810" keyTimes="0;1" dur="2s" repeatCount="indefinite"></animateTransform>--}}
{{--            <animate attributeName="stroke-dashoffset" values="0%;0%;-157.080%" calcMode="spline" keySplines="0.61, 1, 0.88, 1; 0.12, 0, 0.39, 0" keyTimes="0;0.5;1" dur="2s" repeatCount="indefinite"></animate>--}}
{{--            <animate attributeName="stroke-dasharray" values="0% 314.159%;157.080% 157.080%;0% 314.159%" calcMode="spline" keySplines="0.61, 1, 0.88, 1; 0.12, 0, 0.39, 0" keyTimes="0;0.5;1" dur="2s" repeatCount="indefinite"></animate>--}}
{{--        </circle>--}}
{{--    </svg>--}}
{{--    <div>--}}
{{--        <span class="l_text" style="color: #fff;">Loading...</span>--}}
{{--    </div>--}}
{{--</div>--}}

{{--<script>--}}
{{--    window.onload = function() {--}}
{{--        setTimeout(function (){--}}
{{--            document.querySelector('.loader_boss').style.display = 'none';--}}
{{--        }, 500)--}}
{{--    }--}}
{{--</script>--}}
