<html lang="zh-CN"
      style="--status-bar-height: 0px; --top-window-height: 0px; --window-left: 0px; --window-right: 0px; --window-margin: 0px; --window-top: calc(var(--top-window-height) + 0px); --window-bottom: 0px;">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login PWD</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <link rel="stylesheet" href="{{asset('public')}}/static/index.2da1efab.css">
    <link rel="stylesheet" href="{{asset('public/password.css')}}">
</head>
<body class="uni-body pages-mine-updatepwd">
<uni-app class="uni-app--maxwidth">
    <uni-page data-page="pages/mine/updatepwd">
        <uni-page-wrapper>
            <uni-page-body>
                <uni-view data-v-f7befbe6="">
                    <div data-v-f7befbe6="" class="change-pw" style="height: 914px;">
                        <uni-view data-v-67b88ecc="" data-v-f7befbe6="" style="position: fixed; bottom: 60px; right: 15px;">
                            <uni-image data-v-67b88ecc="" class="customer">
                                <div style="background-image: url({{asset('public')}}/4e640eb3.png); background-position: 0% 0%; background-size: 100% 100%; background-repeat: no-repeat;"></div>
                                <img src="{{asset('public')}}/4e640eb3.png" draggable="false"></uni-image>
                        </uni-view>
                        <div data-v-f7befbe6="" class="navboxi  van-hairline--bottom">
                            <div data-v-f7befbe6="" class=" display-center-center">
                                <div data-v-f7befbe6="" class="van-nav-bar__left" onclick="window.location.href='{{route('profile')}}'">
                                    <img style="width: 20px;height: 20px;" src="{{asset('public/icons8-up-left-48.png')}}" alt="">
                                </div>
                                <div data-v-f7befbe6="" class="van-nav-bar__center van-ellipsis">Login Password</div>
                            </div>
                        </div>
                        <div data-v-f7befbe6="" class="register-container">
                            <div data-v-f7befbe6="" class="register">
                                <form action="{{route('user.change.password.confirmation')}}" method="post">
                                    @csrf

                                    <div data-v-f7befbe6="" class="page-title"><p data-v-f7befbe6="">Enter your old password</p></div>
                                    <div data-v-f7befbe6="" class="van-cell-group van-hairline--bottom">
                                        <div data-v-f7befbe6="" class="van-cell van-cell--large van-field"><img
                                                data-v-f7befbe6=""
                                                src="{{asset('public')}}/static/lock.png"
                                                class="icon_bank">
                                            <div data-v-f7befbe6=""
                                                 class="van-cell__value van-cell__value--alone van-field__value">
                                                <div data-v-f7befbe6="" class="van-field__body">
                                                    <uni-input data-v-f7befbe6="" class="van-field__control">
                                                        <div class="uni-input-wrapper">
                                                            <input maxlength="140" step="" placeholder="Old password"
                                                                   autocomplete="off" type="password"
                                                                   name="old_password"
                                                                   class="uni-input-input"></div>
                                                    </uni-input>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-f7befbe6="" class="page-title" style="margin-top: 35px;"><p data-v-f7befbe6="">Create your new password</p></div>
                                    <div data-v-f7befbe6="" class="van-cell-group van-hairline--bottom">
                                        <div data-v-f7befbe6="" class="van-cell van-cell--large van-field"><img
                                                data-v-f7befbe6=""
                                                src="{{asset('public')}}/static/lock.png"
                                                class="icon_bank">
                                            <div data-v-f7befbe6=""
                                                 class="van-cell__value van-cell__value--alone van-field__value">
                                                <div data-v-f7befbe6="" class="van-field__body">
                                                    <uni-input data-v-f7befbe6="" class="van-field__control">
                                                        <div class="uni-input-wrapper">
                                                            <input maxlength="140" step="" placeholder="Create new password"
                                                                   autocomplete="off" type="password"
                                                                   name="new_password"
                                                                   class="uni-input-input"></div>
                                                    </uni-input>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-f7befbe6="" class="van-cell-group van-hairline--bottom">
                                        <div data-v-f7befbe6="" class="van-cell van-cell--large van-field"><img
                                                data-v-f7befbe6=""
                                                src="{{asset('public')}}/static/lock.png"
                                                class="icon_bank">
                                            <div data-v-f7befbe6=""
                                                 class="van-cell__value van-cell__value--alone van-field__value">
                                                <div data-v-f7befbe6="" class="van-field__body">
                                                    <uni-input data-v-f7befbe6="" class="van-field__control">
                                                        <div class="uni-input-wrapper">
                                                            <input maxlength="140" step="" placeholder="Confirm new password"
                                                                   autocomplete="off" type="password"
                                                                   name="confirm_password"
                                                                   class="uni-input-input"></div>
                                                    </uni-input>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <uni-button data-v-f7befbe6=""
                                                onclick="confirmPassword()"
                                                class="registerBtn van-button van-button--primary van-button--normal van-button--block"
                                                style="background-color: rgb(229, 94, 80);">
                                        <div data-v-f7befbe6="" class="van-button__content"><span data-v-f7befbe6=""
                                                                                                  class="van-button__text">Confirm</span>
                                        </div>
                                    </uni-button>

                                </form>
                            </div>
                        </div>
                    </div>

                    <uni-view data-v-5df49fe2="" class="van-overlay" style="background: rgba(0, 0, 0, 0);display: none">
                        <uni-view data-v-5df49fe2="" class="loading-box-h">
                            <uni-view data-v-5df49fe2="" class="van-loading van-loading--spinner van-loading--vertical">
                                <span data-v-5df49fe2="" class="van-loading__spinner van-loading__spinner--spinner"
                                      style="width: 30px; height: 30px;"><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i><i
                                        data-v-5df49fe2=""></i><i data-v-5df49fe2=""></i></span><span data-v-5df49fe2=""
                                                                                                      class="van-loading__text">Loading...</span>
                            </uni-view>
                        </uni-view>
                    </uni-view>
                </uni-view>
            </uni-page-body>
        </uni-page-wrapper>
    </uni-page>
</uni-app>
@include('alert-message')
<script>
    function confirmPassword(){
        document.querySelector('.van-overlay').style.display='block';
        document.querySelector('form').submit();
    }
</script>
</body>
</html>
