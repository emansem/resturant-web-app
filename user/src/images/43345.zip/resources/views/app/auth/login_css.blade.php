<style>
.register[data-v-1f33345e] {
    min-height: 100vh;
    position: relative;
    z-index: 1;
    padding: 25px 0 0;
    background: url({{asset('public')}}/static/img/bg@2x.fb3f2d29.png) no-repeat;
    background-size: 100% 100%
}
</style>

  <style type="text/css">
                        body.pages-login-login uni-page-body {
                            background-color: #fff;
                            font-family: PingFang SC
                        }

body.pages-login-login {
    background-color: #fff
}

.login[data-v-5df49fe2] {
    min-height: 100vh;
    position: relative;
    z-index: 1;
    background: url({{asset('public')}}/bg.png) no-repeat;
    background-size: 100% 100%;
    overflow-x: hidden;
    font-color: #fff
}

.login .sign-up[data-v-5df49fe2] {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between
}

.login .sign-up .isagree[data-v-5df49fe2] {
    border-color: #e55e50;
    background-color: #e55e50
}

.login .header[data-v-5df49fe2] {
    padding: 0 13px;
    margin-bottom: 15px
}

.login .header .leftimg[data-v-5df49fe2] {
    width: 180px;
    height: auto
}

.login .header .rightimg[data-v-5df49fe2] {
    width: 24px;
    height: auto
}

.login .imgonline[data-v-5df49fe2] {
    width: 100%;
    height: auto
}

.login .van-overlay[data-v-5df49fe2] {
    z-index: 9999
}

.login.van-cell-group .van-cell[data-v-5df49fe2] {
    background: none;
    color: #333
}

.login.van-cell-group[data-v-5df49fe2]:after {
    border: none
}

.login .form-box[data-v-5df49fe2] {
    padding: 33px;
    background: #fff;
    border-radius: 36px 36px 0px 0px
}

.login .login-form[data-v-5df49fe2] {
    margin-top: 66px;
    background-color: #fff;
    position: fixed;
    bottom: 0
}

.login .login-form .login-title-container[data-v-5df49fe2] {
    text-align: left;
    margin-bottom: 23px
}

.login .login-form .login-title-container h3[data-v-5df49fe2] {
    margin: 0;
    font-size: 26px;
    position: relative;
    z-index: 1;
    -webkit-transform: skew(-10deg);
    transform: skew(-10deg)
}

.login .login-form .login-title-container p[data-v-5df49fe2] {
    margin-top: 5px;
    font-size: 16px;
    -webkit-transform: skew(-10deg);
    transform: skew(-10deg);
    font-weight: 500
}

.login .login-form .phonei[data-v-5df49fe2] {
    text-align: left;
    font-weight: 600;
    font-size: 15px;
    margin-bottom: 8px
}

.login .login-form .xy[data-v-5df49fe2] {
    display: block;
    text-align: right;
    margin-top: 10
}

.login .login-form .xy .xy-link[data-v-5df49fe2] {
    color: #666
}

.login .login-form .input-group[data-v-5df49fe2] {
    width: 100%;
    border-radius: 6px;
    overflow: hidden;
    padding: 20px 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    position: relative;
    margin-top: 15px
}

.login .login-form .input-group[data-v-5481d0af][data-v-5df49fe2]:nth-of-type(2) {
    position: relative
}

.login .login-form .input-group:nth-of-type(2) .yzm-code[data-v-5df49fe2] {
    position: absolute;
    bottom: 10px;
    width: 40%;
    height: 55px;
    right: 0;
    background: none;
    font-size: 14px;
    color: #2c3e50
}

.login .sign-up a[data-v-5df49fe2] {
    color: #34495e
}

.login .registerBtn[data-v-5df49fe2] {
    width: 50%;
    margin: 50px auto 10px;
    border: none;
    border-radius: 50px;
    background: #e55e50
}

.login .registerBtn .van-button__text[data-v-5df49fe2] {
    color: #fff;
    font-weight: 700;
    font-size: 18px;
    -webkit-transform: skew(-10deg);
    transform: skew(-10deg)
}

.login .registerBtnBot[data-v-5df49fe2] {
    width: 50%;
    margin: 10px auto;
    border: 1px solid #e55e50;
    border-radius: 50px;
    background: #fff
}

.login .registerBtnBot .van-button__text[data-v-5df49fe2] {
    color: #001f20;
    font-weight: 700;
    font-size: 18px;
    -webkit-transform: skew(-10deg);
    transform: skew(-10deg)
}</style>
