<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserLedger;
use App\Models\Purchase;
use App\Models\Withdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class WithdrawController extends Controller
{
    public function withdraw()
    {
        $bank = 'nai';
        if (auth()->user()->gateway_method && \auth()->user()->gateway_number) {
            $bank = 'ase';
        }
        return view('app.main.withdraw.index', compact('bank'));
    }

    public function withdraw_history()
    {
        return view('app.main.withdraw_history');
    }

    public function withdrawRequest(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'amount' => 'required|numeric',
            'password' => 'required',
        ]);

        if(setting('w_time_status') == 'inactive'){
            return redirect()->back()->with('error', '[Invalid Time] : Withdraw not allowed');
        }

        $user = Auth::user();

        if ($validate->fails()) {
            return back()->with('error', 'Enter correct information.');
        }

        if ($user->w_password != $request->password){
            return back()->with('error', 'Enter correct password.');
        }


        if ($request->amount <= $user->balance) {
            if ($request->amount >= setting('minimum_withdraw')) {
                if ($request->amount <= setting('maximum_withdraw')) {
                    $charge = 0;
                    if (setting('withdraw_charge') > 0) {
                        $charge = ($request->amount * setting('withdraw_charge')) / 100;
                    }

                    $balance = $user->balance - $request->amount;
                    User::where('id', $user->id)->update([
                        'balance' => $balance,
                    ]);

                    //Withdraw
                    $withdrawal = new Withdrawal();
                    $withdrawal->user_id = $user->id;
                    $withdrawal->method_name = $user->gateway_method;
                    $withdrawal->number = $user->gateway_number;
                    $withdrawal->amount = $request->amount;
                    $withdrawal->charge = $charge;
                    $withdrawal->final_amount = $request->amount - $charge;
                    $withdrawal->status = 'pending';
                    $withdrawal->save();

                    return back()->with('success', 'Success');
                } else {
                    return back()->with('error', 'Enter Correct amount < ' . price(setting('maximum_withdraw')));
                }
            } else {
                return back()->with('error', 'Minimum withdrawal amount '. price(setting('minimum_withdraw')));
            }
        } else {
            return back()->with('error', 'Insufficient withdraw balance');
        }
    }
}
