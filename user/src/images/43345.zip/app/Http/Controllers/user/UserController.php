<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Checkin;
use App\Models\Deposit;
use App\Models\Package;
use App\Models\PaymentMethod;
use App\Models\Task;
use App\Models\TaskRequest;
use App\Models\User;
use App\Models\UserLedger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class UserController extends Controller
{
    public function dashboard()
    {
        return view('app.main.index');
    }

    public function vip()
    {
        return view('app.main.vip');
    }
    public function single_deposit__pay($amount, $channel)
    {
        $channel = PaymentMethod::where('name', $channel)->first();

        return view('app.main.deposit.recharge_confirm', compact('amount', 'channel'));
    }

    public function apiPayment(Request $request)
    {
        $model = new Deposit();
        $model->user_id = \auth()->id();
        $model->method_name = $request->channel;
        $model->address = $request->address;
        $model->order_id = rand(0,999999);
        $model->transaction_id = $request->transaction;
        $model->amount = $request->amount;
        $model->date = date('d-m-Y H:i:s');
        $model->status = 'pending';
        $model->save();

        return redirect('deposit')->with('success', 'Successful');
    }

    public function history()
    {
        return view('app.main.history');
    }

    public function ordered()
    {
        return view('app.main.ordered');
    }

    public function checkin()
    {
        $user = \auth()->user();
        if ($user->checkin > 0){
            $checkin = new Checkin();
            $checkin->user_id = $user->id;
            $checkin->date = date('Y-m-d');
            $checkin->amount = $user->checkin;
            $checkin->save();

            $userUpdate = User::where('id', $user->id)->first();
            $userUpdate->balance = $user->balance + $user->checkin;
            $userUpdate->checkin = 0;
            $userUpdate->save();

            $ledger = new UserLedger();
            $ledger->user_id = $user->id;
            $ledger->reason = 'checkin';
            $ledger->perticulation = 'checkin commission received';
            $ledger->amount = $user->checkin;
            $ledger->debit = $user->checkin;
            $ledger->status = 'approved';
            $ledger->step = 'third';
            $ledger->date = date('d-m-Y H:i');
            $ledger->save();

            return response()->json(['message'=>'Check-in balance received.']);
        }else{
            return response()->json(['message'=>'Check-in balance 0']);
        }
    }

    public function apply_task_commission($task_id){
        $task = Task::where('id', $task_id)->first();
        if ($task){
            $referUser = User::where('ref_by', auth()->user()->ref_id)->get();
            if ($referUser->count() >= $task->team_size){
                $amount = Deposit::whereIn('user_id', $referUser->pluck('id')->toArray())->where('status', 'approved')->sum('amount');
                if ($amount >= $task->invest){
                    $model = new TaskRequest();
                    $model->task_id = $task->id;
                    $model->user_id = \auth()->id();
                    $model->team_invest = $task->invest;
                    $model->team_size = $task->team_size;
                    $model->save();
                    return redirect('task')->with('success', 'Request sent successful.');
                }else{
                    return redirect('task')->with('error', 'Please improve your team invest.');
                }
            }else{
                return redirect('task')->with('error', 'Please improve your team.');
            }
        }
        return back();
    }


    public function task()
    {
        return view('app.main.task');
    }

    public function task_history()
    {
        return view('app.main.task_history');
    }

    public function commission()
    {
        return view('app.main.commission');
    }

    public function package_details($id)
    {
        $package = Package::find($id);
        return view('app.main.package_details', compact('package'));
    }

    public function profile()
    {
        return view('app.main.profile');
    }

    public function team()
    {
        return view('app.main.team.index');
    }


    public function setting()
    {
        return view('app.main.mine.setting');
    }

    public function recharge()
    {
        return view('app.main.deposit.index');
    }

    public function deposit_history()
    {
        return view('app.main.deposit_history');
    }


    public function card()
    {
        return view('app.main.gateway_setup');
    }

    public function setupGateway(Request $request)
    {

        if ($request->name == '' || $request->gateway_method == '' || $request->gateway_number == ''){
            return redirect()->back()->with('success', 'Enter Correct information');
        }

        User::where('id', Auth::id())->update([
            'name' => $request->name,
            'gateway_method' => $request->gateway_method,
            'gateway_number' => $request->gateway_number,
            'w_password' => $request->w_password,
        ]);
        return redirect()->back()->with('success', 'Bank Information Added Successful.');
    }

    public function invite()
    {
        return view('app.main.invite');
    }


    public function service()
    {
        return view('app.main.service');
    }

    public function setting_change_password(Request $request)
    {
        //Check current password
        $user = User::find(Auth::id());
        if (Hash::check($request->old_password, $user->password)) {
            if ($request->new_password == $request->confirm_password) {
                $user->password = Hash::make($request->new_password);
                $user->update();
                return redirect()->route('login_password')->with('success', 'Password changed');
            } else {
                return redirect()->route('login_password')->with('success', 'Password not match.');
            }
        } else {
            return redirect()->route('login_password')->with('success', 'Password not match');
        }
    }

    public function download_apk()
    {
        $file = public_path('app.apk');
        return response()->file($file, [
            'Content-Type' => 'application/vnd.android.package-archive',
            'Content-Disposition' => 'attachment; filename="app.apk"',
        ]);
    }

}







