<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Rebate;
use App\Models\Reword;
use App\Models\User;
use App\Models\Purchase;
use App\Models\UserLedger;
use Illuminate\Support\Facades\Auth;

class MiningController extends Controller
{
    public function running_mining()
    {
        return view('app.main.order.order');
    }

    public function start_mining($pack_id){
        $parchase = Purchase::where('package_id', $pack_id)->where('user_id', \auth()->id())->where('status', 'active')->orderByDesc('id')->first();
        if ($parchase){
            $parchase->running_status = 'running';
            $parchase->save();
        }
        return back();
    }


    public function received_amount($id)
    {
        $user = Auth::user();
        $purchase = Purchase::where('id', $id)->first();

        if ($purchase->streaming_amount > 0){
            $uu = User::where('id', $user->id)->first();
            $uu->balance = $user->balance + $purchase->streaming_amount;
            $uu->save();

            $rr = $purchase->streaming_amount;

            $ledger = new UserLedger();
            $ledger->user_id = $user->id;
            $ledger->reason = 'daily_income';
            $ledger->perticulation = 'Invest commission.';
            $ledger->amount = $purchase->streaming_amount;
            $ledger->credit = $purchase->streaming_amount;
            $ledger->status = 'approved';
            $ledger->date = date("Y-m-d H:i:s");
            $ledger->save();

            $purchase->streaming_amount = 0;
            $purchase->save();

            return response()->json(['status'=> true, 'message'=> 'Income added '. price($rr), 'amount'=> price(0)]);
        }else{
            return response()->json(['status'=> false, 'message'=> 'Income not added, wait until added', 'amount'=> price(0)]);
        }
    }

    public function process()
    {
        return view('app.main.order.process');
    }
}








