<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\RegistrationMail;
use App\Models\Admin;
use App\Models\Package;
use App\Models\Purchase;
use App\Models\Reword;
use App\Models\User;
use App\Models\UserLedger;
use App\Providers\RouteServiceProvider;
use Carbon\Carbon;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules;
use Illuminate\View\View;
use function GuzzleHttp\Promise\all;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(Request $request)
    {
        $captcha_code = rand(00000,99999);

        $ref_by = $request->query('invite');
        return view('app.auth.registration', compact('ref_by', 'captcha_code'));
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'phone' => ['required', 'numeric', 'unique:users,phone'],
            'password' => ['required'],
            'confirm_password' => ['required'],
            'code' => ['required'],
            ]);
        if ($validate->fails()){
            $user = User::where('phone', $request->phone)->first();
            if ($user){
                return back()->with('message', 'Phone number exist');
            }
            return back()->with('message', $validate->errors());
        }

        if ($request->password != $request->confirm_password){
            return back()->with('message', "don't match confirm password");
        }


        $getIp = \Request::ip();
//         $checkUserIp = DB::table('users')->where('ip', $getIp)->exists();
//         if ($checkUserIp){
//             return back()->with('message', 'Not Allowed Multiple Account.');
//         }

        //Refer Bonus
        if ($request->ref_by){
            $getUser = User::where('ref_id', $request->ref_by)->first();
            if ($getUser){
                $first_level_users = User::where('ref_by', $getUser->ref_id)->count();
                if ($first_level_users <= setting('total_member_register_reword')){
                    $getUser->balance = $getUser->balance + setting('total_member_register_reword_amount');
                    $getUser->save();

                    $ledger = new UserLedger();
                    $ledger->user_id = $getUser->id;
                    $ledger->reason = 'register_bonus';
                    $ledger->perticulation = 'Register bonus '.price(setting('total_member_register_reword_amount')).' received';
                    $ledger->amount = setting('total_member_register_reword_amount');
                    $ledger->debit = setting('total_member_register_reword_amount');
                    $ledger->status = 'approved';
                    $ledger->date = date('d-m-Y H:i');
                    $ledger->save();
                }
            }
        }

        //Check refer code is next time edit
        $user = User::create([
            'name' => 'User'.rand(22,99),
            'username' => 'uname'.$request->phone,
            'ref_id' => $this->ref_code(),
            'ref_by' => $request->ref_by ?? '000000001',
            'email' => 'user'.rand(11111,99999).time().'@gmail.com',
            'password' => Hash::make($request->password),
            'type' => 'user',
            'phone' => $request->phone,
            'balance' => 280,
            'phone_code' => '+880',
            'ip' => $getIp,
            'remember_token' => Str::random(30),
        ]);

        if ($user){
            Auth::login($user);
            return redirect()->route('dashboard');
        }else{
            return back()->with('message', 'Registration Fail');
        }

    }

    public function ref_code()
    {
        $str1 = rand(0,999);
        $rand = rand(000,9999);

        if (rand(111,999) % 2 == 0){
            $refCode = $str1.$rand;
        }else{
            $refCode = $rand.$str1;
        }
        return $refCode;
    }

    public function refreshCaptcha()
    {
        return response()->json(['captcha'=> captcha_img()]);
    }
}

